﻿Imports System.Data.SqlClient
Public Class Form1
    Dim conn As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            conn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\MSI\Downloads\jenral\a4\a4\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = conn
            MsgBox("Data base connect successfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub
    Sub clearcontrol()
        TextBox1.Text = " "
        TextBox2.Text = " "
        TextBox3.Text = " "
        TextBox4.Text = " "
    End Sub
    Sub displaydata()
        Try
            cmd.CommandText = "Select * from tblmedicine"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            cmd.CommandText = "insert into tblmedicine values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.SelectedItem & "','" & TextBox3.Text & "','" & TextBox4.Text & "')"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data inserted")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            cmd.CommandText = "update tblmedicine set name = '" & TextBox2.Text & "',type = '" & ComboBox1.SelectedItem & "',company = '" & TextBox3.Text & "',rate='" & TextBox4.Text & "' where mid ='" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data updated succefully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            cmd.CommandText = "delete from tblmedicine where mid = " & TextBox1.Text & ""
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data deletd successfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            cmd.CommandText = "Select * from tblmedicine where type = '" & ComboBox1.SelectedItem & "' and rate < ' 500 '"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Class
