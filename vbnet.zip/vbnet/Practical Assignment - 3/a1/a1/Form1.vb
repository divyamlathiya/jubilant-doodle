﻿Imports System.Data.SqlClient
Public Class Form1
    Dim conn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim intid As Integer
    Dim str, type As String
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            conn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\MSI\Downloads\jenral\a1\a1\student.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = conn
            MsgBox("Data base connect successfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub
    Sub clearcontrol()
        TextBox1.Text = " "
        TextBox2.Text = " "
        RichTextBox1.Text = " "
    End Sub


    Sub displaydata()
        Try
            cmd.CommandText = "Select * from stud"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If RadioButton1.Checked Then
                str = "Male"
            ElseIf RadioButton2.Checked Then
                str = "Male"
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            cmd.CommandText = "INSERT INTO stud VALUES ('" & TextBox1.Text & "', '" & TextBox2.Text & "', '" & ComboBox1.SelectedItem & "', '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "', '" & str & "', '" & RichTextBox1.Text & "')"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data inserted")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            If RadioButton1.Checked Then
                str = "Male"
            ElseIf RadioButton2.Checked Then
                str = "Female"
            Else
                MsgBox("PLese! select your gender")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            cmd.CommandText = "update stud set name = '" & TextBox2.Text & "',course = '" & ComboBox1.SelectedItem & "',dob = '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "',gender = '" & str & "',adress = '" & RichTextBox1.Text & "' where id = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data updated")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            cmd.CommandText = "select * from stud where id = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView3.DataSource = dt
            cmd.CommandText = "delete from stud where id = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data delted sussfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            cmd.CommandText = "select * from  stud where course = '" & ComboBox1.SelectedItem & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try
            cmd.CommandText = "select Count(*) from stud"
            Dim stcnt As Integer
            conn.Open()
            stcnt = Convert.ToInt32(cmd.ExecuteScalar)
            conn.Close()
            MessageBox.Show("Total student  = " + stcnt.ToString())
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
