﻿Imports System.Data.SqlClient
Public Class Form1
    Dim conn As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim s As New Form2()
        s.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            cmd.CommandText = "insert into policy_master values ('" & TextBox1.Text & "', '" & TextBox2.Text & "', '" & TextBox3.Text & "', '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "','" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "','" & TextBox4.Text & "')"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data inserted")
            displaydata()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            cmd.CommandText = "delete from policy_master where Policy_no = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data delted sussfully")
            displaydata()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            cmd.CommandText = "update policy_master set agent_code = '" & TextBox2.Text & "', Customer_name = '" & TextBox3.Text & "',Start_date = '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "',End_date = '" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "',Policy_amt = '" & TextBox4.Text & "'where Policy_no = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MsgBox("Data updated")
            displaydata()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        cmd.CommandText = "SELECT Policy_no, Agent_code, Customer_name FROM Policy_Master ORDER BY Policy_amt ASC"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        Dim dt As New DataTable
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView3.DataSource = dt
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            conn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=E:\sem 4\net\jenral\a5\a5\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = conn
            displaydata()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub displaydata()
        Try
            cmd.CommandText = "Select * from policy_master"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            cmd.CommandText = "Select * from agent_master"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        cmd.CommandText = "SELECT A.Agent_name, P.Customer_name, SUM(P.Policy_amt) AS Total_Amount FROM Agent_Master A INNER JOIN Policy_Master P ON A.Agent_code = P.Agent_code GROUP BY A.Agent_name, P.Customer_name"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        Dim dt As New DataTable
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView4.DataSource = dt
    End Sub
End Class
