﻿'13.Write a vb.net program to perform following task using Arraylist.

Public Class Form1

    Dim items As New ArrayList
    Private Sub BtnAddItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAddItem.Click
        ListBox1.Items.Clear()
        items.Add("Banana")
        items.Add("Apple")
        items.Add("Orange")
        items.Add("Mango")
        items.Add("Strawbeery")
    End Sub

    Private Sub btnViewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnViewItem.Click
        ListBox1.Items.Clear()
        For i = 0 To items.Count - 1
            ListBox1.Items.Add(i & vbTab & items.Item(i))
        Next
    End Sub

    Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
        ListBox1.Items.Clear()
        items.Insert(0, "--- Fruits ---")
        For i = 0 To items.Count - 1
            ListBox1.Items.Add(i & vbTab & items.Item(i))
        Next
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ListBox1.Items.Clear()
        items.RemoveAt(1)
        For i = 0 To items.Count - 1
            ListBox1.Items.Add(i & vbTab & items.Item(i))
        Next
    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        ListBox1.Items.Clear()
        items.Sort()
        For i = 0 To items.Count - 1
            ListBox1.Items.Add(i & vbTab & items.Item(i))
        Next
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ListBox1.Items.Clear()
    End Sub
End Class
