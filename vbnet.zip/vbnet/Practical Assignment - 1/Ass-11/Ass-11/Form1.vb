﻿'11. Write a vb.net program to find sum of given number using array.

Public Class Form1
    Private Sub btnSum_Click(sender As System.Object, e As System.EventArgs) Handles btnSum.Click

        Dim numbers As Integer() = {10, 20, 30, 40, 50}
        Dim sum As Integer = 0

        For Each number As Integer In numbers
            sum += number
        Next
        ListBox1.Items.Add(sum)
    End Sub

End Class
