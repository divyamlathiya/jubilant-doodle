﻿'9. Write a vb.net program that calculates net salary (basic+da+hra-pt) using optional argument.Consider da = 105% Of basic,Hra=25% Of basic,pt=Rs.200.

Public Class Form1

    Public Function getSalary(Optional ByVal optionalSalary As Integer = 12000) As Double

        Dim da As Double
        Dim Hra As Double
        Dim Pt As Integer = 200
        Dim netSalary As Double

        da = optionalSalary * 105 / 100
        Hra = optionalSalary * 25 / 100

        netSalary = (optionalSalary + da + Hra) -
        TextBox2.Text = netSalary

    End Function

    Private Sub BtnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        getSalary()
    End Sub
End Class
