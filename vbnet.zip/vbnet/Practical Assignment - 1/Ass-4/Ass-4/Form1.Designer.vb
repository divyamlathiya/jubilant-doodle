﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.implicit = New System.Windows.Forms.Button()
        Me.explicit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'implicit
        '
        Me.implicit.Location = New System.Drawing.Point(92, 74)
        Me.implicit.Name = "implicit"
        Me.implicit.Size = New System.Drawing.Size(75, 23)
        Me.implicit.TabIndex = 0
        Me.implicit.Text = "Implicit Convt"
        Me.implicit.UseVisualStyleBackColor = True
        '
        'explicit
        '
        Me.explicit.Location = New System.Drawing.Point(92, 127)
        Me.explicit.Name = "explicit"
        Me.explicit.Size = New System.Drawing.Size(75, 23)
        Me.explicit.TabIndex = 1
        Me.explicit.Text = "Explicit Convt"
        Me.explicit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(265, 257)
        Me.Controls.Add(Me.explicit)
        Me.Controls.Add(Me.implicit)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents implicit As System.Windows.Forms.Button
    Friend WithEvents explicit As System.Windows.Forms.Button

End Class
