﻿'4.Write a vb.net program for applying implicit and explicit conversion.

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles implicit.Click
        Dim n1 As Integer = 40
        Dim n2 As Integer = 89
        Dim total As String

        total = n1 + n2
        MsgBox("Total is :" & total)

    End Sub

    Private Sub explicit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles explicit.Click
        Dim dbl As Double = 8.75
        Dim ans As Integer
        ans = CInt(dbl)
        MsgBox("Double into Integer: " & ans)
    End Sub
End Class
