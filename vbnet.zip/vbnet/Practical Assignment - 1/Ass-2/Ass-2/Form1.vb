﻿'2. Write a vb.net program to perform the following task. using enumeration.

Public Class Form1
    Enum Color
        Black
        Red
    End Enum
    Enum TextType
        Small
        Medium
        Large
    End Enum

    Private Sub black_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackBtn.CheckedChanged
        If BlackBtn.Checked Then
            MsgBox("Index of Black Color: " & Color.Black)
        End If
    End Sub

    Private Sub RedBtn_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RedBtn.CheckedChanged
        If RedBtn.Checked Then
            MsgBox("Index of Red Color: " & Color.Red)
        End If
    End Sub

    Private Sub smallText_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles smallText.CheckedChanged
        If smallText.Checked Then
            MsgBox("Index of Small Text: " & TextType.Small)
        End If
    End Sub

    Private Sub mediumText_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mediumText.CheckedChanged
        If mediumText.Checked Then
            MsgBox("Index of Medium Text: " & TextType.Medium)
        End If
    End Sub

    Private Sub largeText_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles largeText.CheckedChanged
        If largeText.Checked Then
            MsgBox("Index of Large Text: " & TextType.Large)
        End If
    End Sub

End Class
