﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ansLable = New System.Windows.Forms.Label()
        Me.BlackBtn = New System.Windows.Forms.RadioButton()
        Me.smallText = New System.Windows.Forms.RadioButton()
        Me.mediumText = New System.Windows.Forms.RadioButton()
        Me.largeText = New System.Windows.Forms.RadioButton()
        Me.RedBtn = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'ansLable
        '
        Me.ansLable.AutoSize = True
        Me.ansLable.Font = New System.Drawing.Font("Adobe Caslon Pro", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ansLable.ForeColor = System.Drawing.Color.Black
        Me.ansLable.Location = New System.Drawing.Point(53, 49)
        Me.ansLable.Name = "ansLable"
        Me.ansLable.Size = New System.Drawing.Size(127, 36)
        Me.ansLable.TabIndex = 0
        Me.ansLable.Text = "Enumeration"
        '
        'BlackBtn
        '
        Me.BlackBtn.AutoSize = True
        Me.BlackBtn.Location = New System.Drawing.Point(44, 99)
        Me.BlackBtn.Name = "BlackBtn"
        Me.BlackBtn.Size = New System.Drawing.Size(52, 17)
        Me.BlackBtn.TabIndex = 1
        Me.BlackBtn.TabStop = True
        Me.BlackBtn.Text = "Black"
        Me.BlackBtn.UseVisualStyleBackColor = True
        '
        'smallText
        '
        Me.smallText.AutoSize = True
        Me.smallText.Location = New System.Drawing.Point(128, 99)
        Me.smallText.Name = "smallText"
        Me.smallText.Size = New System.Drawing.Size(74, 17)
        Me.smallText.TabIndex = 2
        Me.smallText.TabStop = True
        Me.smallText.Text = "Small Text"
        Me.smallText.UseVisualStyleBackColor = True
        '
        'mediumText
        '
        Me.mediumText.AutoSize = True
        Me.mediumText.Location = New System.Drawing.Point(128, 122)
        Me.mediumText.Name = "mediumText"
        Me.mediumText.Size = New System.Drawing.Size(62, 17)
        Me.mediumText.TabIndex = 3
        Me.mediumText.TabStop = True
        Me.mediumText.Text = "Medium"
        Me.mediumText.UseVisualStyleBackColor = True
        '
        'largeText
        '
        Me.largeText.AutoSize = True
        Me.largeText.Location = New System.Drawing.Point(128, 145)
        Me.largeText.Name = "largeText"
        Me.largeText.Size = New System.Drawing.Size(52, 17)
        Me.largeText.TabIndex = 4
        Me.largeText.TabStop = True
        Me.largeText.Text = "Large"
        Me.largeText.UseVisualStyleBackColor = True
        '
        'RedBtn
        '
        Me.RedBtn.AutoSize = True
        Me.RedBtn.Location = New System.Drawing.Point(44, 122)
        Me.RedBtn.Name = "RedBtn"
        Me.RedBtn.Size = New System.Drawing.Size(45, 17)
        Me.RedBtn.TabIndex = 5
        Me.RedBtn.TabStop = True
        Me.RedBtn.Text = "Red"
        Me.RedBtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(342, 242)
        Me.Controls.Add(Me.RedBtn)
        Me.Controls.Add(Me.largeText)
        Me.Controls.Add(Me.mediumText)
        Me.Controls.Add(Me.smallText)
        Me.Controls.Add(Me.BlackBtn)
        Me.Controls.Add(Me.ansLable)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ansLable As System.Windows.Forms.Label
    Friend WithEvents BlackBtn As System.Windows.Forms.RadioButton
    Friend WithEvents smallText As System.Windows.Forms.RadioButton
    Friend WithEvents mediumText As System.Windows.Forms.RadioButton
    Friend WithEvents largeText As System.Windows.Forms.RadioButton
    Friend WithEvents RedBtn As System.Windows.Forms.RadioButton

End Class
