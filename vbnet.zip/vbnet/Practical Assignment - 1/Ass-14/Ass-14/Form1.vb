﻿'14. Write a vb.net program to perform following task (using control statement (if, select case)).

'- Total marks of the student
'-Percentage of the student
'- Average of the student
'- Find result of the student (pass/fail)
'- Calculate class based on the following criteria :-
'0 Percentage >=70 Distinction , 0 >= 60 First Classo0 >= 50 Second Class , 0 >= 40 Pass Class , 0 Otherwise Fail

Public Class Form1

    Private Sub btnResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResult.Click
        Dim items As New ArrayList
        Dim name As String = txtName.Text
        Dim m1 As Integer = TextBox1.Text
        Dim m2 As Integer = TextBox2.Text
        Dim m3 As Integer = TextBox3.Text
        Dim total As Integer = m1 + m2 + m3
        Dim per As Double = ((total * 100) / 300).ToString("F2")
        Dim average As Integer = total / 3
        Dim result As String

        Select Case per
            Case 70 To 100
                result = "Distinction"
            Case 60 To 70
                result = "First Class"
            Case 50 To 60
                result = "Second Class"
            Case 40 To 50
                result = "Pass Class"
            Case Else
                result = "Fail"
        End Select


        ListBox1.Items.Clear()
        items.Add(name)
        items.Add(m1)
        items.Add(m2)
        items.Add(m3)
        items.Add(total)
        items.Add(per)
        items.Add(average)
        items.Add(result)

        ListBox1.Items.Add("Name" & vbTab & "Marks1" & vbTab & "Marks2" & vbTab & "Marks3" & vbTab & "Total" & vbTab & "Percentage" & vbTab & "Average" & vbTab & "Result")
        ListBox1.Items.Add("-------------------------------------------------------------------------------------------------------------------------------------------------------------")

        ListBox1.Items.Add(name & vbTab & m1 & vbTab & m2 & vbTab & m3 & vbTab & total & vbTab & per & "%" & vbTab & vbTab & average & vbTab & result)

    End Sub

End Class
