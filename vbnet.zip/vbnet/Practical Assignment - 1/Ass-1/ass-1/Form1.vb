﻿'1.Write a vb.net program to perform boxing and unboxing.
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBoxing.Click
        Dim i As Integer = 123
        Dim obj As Object
        obj = i
        TextBox1.Text = "Boxing : " & obj
        Dim j As Integer
        j = CInt(obj)
        TextBox1.Text = "Unboxing : " & j
    End Sub

End Class
