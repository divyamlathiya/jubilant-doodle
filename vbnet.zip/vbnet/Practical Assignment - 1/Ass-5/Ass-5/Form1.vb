﻿'5.Write a vb.net program that performs following operation on String.
'- Convert string into upper case
'- Convert string into lower case
'- Replace string with replacement string given by user.
'- Count the total number of characters in given string.
'- Extract a characters from a string
'- Remove leading And trailing spaces from a string.

Public Class Form1

    Private Sub StrFun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrFun.Click

        Dim str As String = "    Hellow,  World!     "
        ''Upper Case
        MsgBox("Uppser case : " & UCase(str))

        ''Lower Case
        MsgBox("Lower case : " & LCase(str))

        ''Replace String
        Dim orgStr As String = "Mohit Dholariya"
        Dim tBox1, tBox2 As String
        tBox1 = TextBox1.Text
        tBox2 = TextBox2.Text
        Dim replacStr As String = Replace(orgStr, tBox2, tBox1)
        MsgBox("Old String : " & orgStr & " -> Replaced String is : " & replacStr)

        ''Count Character
        MsgBox("lenght is : " & Len(str))

        ''Extract character means get a middle character
        MsgBox("Extracted Character is " & Mid(str, 3, 4))

        'Remove Whitespace 
        MsgBox("Whitespace and Leading :" & Trim(str))

    End Sub

End Class
