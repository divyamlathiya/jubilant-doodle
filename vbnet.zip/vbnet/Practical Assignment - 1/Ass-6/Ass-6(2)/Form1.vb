﻿'6.Write a vb.net program that performs following operation on Date.

Public Class Form1

    Private Sub addDays_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addDays.Click
        TextBox1.Text = "Date After 6 Days : " + Today.AddDays(6)
    End Sub


    Private Sub addYears_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addYears.Click
        TextBox1.Text = "Date After 6 Years : " + Today.AddYears(6)
    End Sub

    Private Sub addMonth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addMonth.Click
        TextBox1.Text = "Date After 6 Months : " + Today.AddMonths(6)

    End Sub


    Private Sub addHours_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addHours.Click
        TextBox1.Text = "Add Hours :" + Now.AddHours(6)
    End Sub

    Private Sub compare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles compare.Click
        Dim d1 As String = InputBox("Enter Date 1 : ")
        Dim d2 As String = InputBox("Enter Date 2 : ")

        If d1 > d2 Then
            TextBox1.Text = "First Date is Greater"

        ElseIf d2 > d1 Then

            TextBox1.Text = "Second Date is Greater"

        Else
            TextBox1.Text = "Invalid Date"


        End If


    End Sub

    Private Sub btnNow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNow.Click
        TextBox1.Text = "Now : " + Now.ToString

    End Sub

    Private Sub monthDays_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles monthDays.Click
        Dim dayInMonth As Integer = DateTime.DaysInMonth(Today.Year, Today.Month)
        TextBox1.Text = "Month Days : " + dayInMonth.ToString

    End Sub

    Private Sub btnToday_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToday.Click
        TextBox1.Text = "Today is : " + Today

    End Sub

    Private Sub addSeconds_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addSeconds.Click
        TextBox1.Text = "Time After 30 Second : " + Now.AddSeconds(30)

    End Sub

    Private Sub month_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles month.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Month : " + dt.Month.ToString()

    End Sub

    Private Sub day_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles day.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Day of Day : " + dt.Day.ToString()

    End Sub

    Private Sub longTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles longTime.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Day : " + dt.ToLongTimeString()

    End Sub

    Private Sub shortTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shortTime.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Day : " + dt.ToShortTimeString()
    End Sub

    Private Sub parse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles parse.Click

        'Check Date Format --> System Format
        Dim inDate As String = InputBox("Enter Date :")
        ' stored system date
        Dim dt As Date
        If Date.TryParse(inDate, dt) Then
            TextBox1.Text = "Parse Date : " + dt.ToString()

        Else
            TextBox1.Text = "Invalid date string"

        End If
    End Sub

    Private Sub leapYear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles leapYear.Click
        TextBox1.Text = "2025 is Leap Year or not ? : " + System.DateTime.IsLeapYear(2025).ToString()

    End Sub

    Private Sub dayOfYear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dayOfYear.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Day of Year : " + dt.DayOfYear.ToString()

    End Sub

    Private Sub dayOfWeek_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dayOfWeek.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Day of Week : " + dt.DayOfWeek.ToString()
    End Sub

    Private Sub shortDate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shortDate.Click
        TextBox1.Text = "Short Date : " + Now.ToShortDateString()

    End Sub

    Private Sub longDate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles longDate.Click
        Dim dt As Date = DateTime.Now
        TextBox1.Text = "Long Date : " + Now.ToLongDateString()

    End Sub

    Private Sub BtnSubtract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSubtract.Click
        Dim d1 As Date = InputBox("Enter Date 1 :")
        Dim d2 As Date = InputBox("Enter Date 2 :")
        Dim ts As TimeSpan
        ts = d2.Subtract(d1)
        TextBox1.Text = "Day difference d1: " + d1 + "  d2: " + d2 + ": " + ts.Days.ToString()

    End Sub
End Class
