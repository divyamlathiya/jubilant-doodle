﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.addDays = New System.Windows.Forms.Button()
        Me.month = New System.Windows.Forms.Button()
        Me.btnNow = New System.Windows.Forms.Button()
        Me.longTime = New System.Windows.Forms.Button()
        Me.BtnSubtract = New System.Windows.Forms.Button()
        Me.compare = New System.Windows.Forms.Button()
        Me.addMonth = New System.Windows.Forms.Button()
        Me.monthDays = New System.Windows.Forms.Button()
        Me.longDate = New System.Windows.Forms.Button()
        Me.shortTime = New System.Windows.Forms.Button()
        Me.dayOfYear = New System.Windows.Forms.Button()
        Me.day = New System.Windows.Forms.Button()
        Me.addYears = New System.Windows.Forms.Button()
        Me.addSeconds = New System.Windows.Forms.Button()
        Me.leapYear = New System.Windows.Forms.Button()
        Me.shortDate = New System.Windows.Forms.Button()
        Me.parse = New System.Windows.Forms.Button()
        Me.dayOfWeek = New System.Windows.Forms.Button()
        Me.addHours = New System.Windows.Forms.Button()
        Me.btnToday = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'addDays
        '
        Me.addDays.Location = New System.Drawing.Point(12, 56)
        Me.addDays.Name = "addDays"
        Me.addDays.Size = New System.Drawing.Size(75, 23)
        Me.addDays.TabIndex = 0
        Me.addDays.Text = "Add Days"
        Me.addDays.UseVisualStyleBackColor = True
        '
        'month
        '
        Me.month.Location = New System.Drawing.Point(12, 300)
        Me.month.Name = "month"
        Me.month.Size = New System.Drawing.Size(75, 23)
        Me.month.TabIndex = 2
        Me.month.Text = "Month"
        Me.month.UseVisualStyleBackColor = True
        '
        'btnNow
        '
        Me.btnNow.Location = New System.Drawing.Point(12, 257)
        Me.btnNow.Name = "btnNow"
        Me.btnNow.Size = New System.Drawing.Size(75, 23)
        Me.btnNow.TabIndex = 3
        Me.btnNow.Text = "Now"
        Me.btnNow.UseVisualStyleBackColor = True
        '
        'longTime
        '
        Me.longTime.Location = New System.Drawing.Point(12, 215)
        Me.longTime.Name = "longTime"
        Me.longTime.Size = New System.Drawing.Size(75, 23)
        Me.longTime.TabIndex = 4
        Me.longTime.Text = "Long Time"
        Me.longTime.UseVisualStyleBackColor = True
        '
        'BtnSubtract
        '
        Me.BtnSubtract.Location = New System.Drawing.Point(12, 173)
        Me.BtnSubtract.Name = "BtnSubtract"
        Me.BtnSubtract.Size = New System.Drawing.Size(75, 23)
        Me.BtnSubtract.TabIndex = 5
        Me.BtnSubtract.Text = "Subtract"
        Me.BtnSubtract.UseVisualStyleBackColor = True
        '
        'compare
        '
        Me.compare.Location = New System.Drawing.Point(12, 133)
        Me.compare.Name = "compare"
        Me.compare.Size = New System.Drawing.Size(75, 23)
        Me.compare.TabIndex = 6
        Me.compare.Text = "Compare"
        Me.compare.UseVisualStyleBackColor = True
        '
        'addMonth
        '
        Me.addMonth.Location = New System.Drawing.Point(12, 94)
        Me.addMonth.Name = "addMonth"
        Me.addMonth.Size = New System.Drawing.Size(75, 23)
        Me.addMonth.TabIndex = 7
        Me.addMonth.Text = "Add Months"
        Me.addMonth.UseVisualStyleBackColor = True
        '
        'monthDays
        '
        Me.monthDays.Location = New System.Drawing.Point(174, 94)
        Me.monthDays.Name = "monthDays"
        Me.monthDays.Size = New System.Drawing.Size(75, 23)
        Me.monthDays.TabIndex = 14
        Me.monthDays.Text = "Month Days"
        Me.monthDays.UseVisualStyleBackColor = True
        '
        'longDate
        '
        Me.longDate.AccessibleDescription = ""
        Me.longDate.Location = New System.Drawing.Point(174, 133)
        Me.longDate.Name = "longDate"
        Me.longDate.Size = New System.Drawing.Size(75, 23)
        Me.longDate.TabIndex = 13
        Me.longDate.Text = "Long Date"
        Me.longDate.UseVisualStyleBackColor = True
        '
        'shortTime
        '
        Me.shortTime.Location = New System.Drawing.Point(174, 173)
        Me.shortTime.Name = "shortTime"
        Me.shortTime.Size = New System.Drawing.Size(75, 23)
        Me.shortTime.TabIndex = 12
        Me.shortTime.Text = "Short Time"
        Me.shortTime.UseVisualStyleBackColor = True
        '
        'dayOfYear
        '
        Me.dayOfYear.Location = New System.Drawing.Point(174, 215)
        Me.dayOfYear.Name = "dayOfYear"
        Me.dayOfYear.Size = New System.Drawing.Size(75, 23)
        Me.dayOfYear.TabIndex = 11
        Me.dayOfYear.Text = "Day Of Year"
        Me.dayOfYear.UseVisualStyleBackColor = True
        '
        'day
        '
        Me.day.Location = New System.Drawing.Point(174, 257)
        Me.day.Name = "day"
        Me.day.Size = New System.Drawing.Size(75, 23)
        Me.day.TabIndex = 10
        Me.day.Text = "Day"
        Me.day.UseVisualStyleBackColor = True
        '
        'addYears
        '
        Me.addYears.Location = New System.Drawing.Point(174, 56)
        Me.addYears.Name = "addYears"
        Me.addYears.Size = New System.Drawing.Size(75, 23)
        Me.addYears.TabIndex = 8
        Me.addYears.Text = "Add Years"
        Me.addYears.UseVisualStyleBackColor = True
        '
        'addSeconds
        '
        Me.addSeconds.Location = New System.Drawing.Point(328, 95)
        Me.addSeconds.Name = "addSeconds"
        Me.addSeconds.Size = New System.Drawing.Size(89, 23)
        Me.addSeconds.TabIndex = 21
        Me.addSeconds.Text = "Add Seconds"
        Me.addSeconds.UseVisualStyleBackColor = True
        '
        'leapYear
        '
        Me.leapYear.Location = New System.Drawing.Point(335, 133)
        Me.leapYear.Name = "leapYear"
        Me.leapYear.Size = New System.Drawing.Size(75, 23)
        Me.leapYear.TabIndex = 20
        Me.leapYear.Text = "Leap Year"
        Me.leapYear.UseVisualStyleBackColor = True
        '
        'shortDate
        '
        Me.shortDate.Location = New System.Drawing.Point(335, 173)
        Me.shortDate.Name = "shortDate"
        Me.shortDate.Size = New System.Drawing.Size(75, 23)
        Me.shortDate.TabIndex = 19
        Me.shortDate.Text = "Short Date"
        Me.shortDate.UseVisualStyleBackColor = True
        '
        'parse
        '
        Me.parse.Location = New System.Drawing.Point(335, 215)
        Me.parse.Name = "parse"
        Me.parse.Size = New System.Drawing.Size(75, 23)
        Me.parse.TabIndex = 18
        Me.parse.Text = "Parse"
        Me.parse.UseVisualStyleBackColor = True
        '
        'dayOfWeek
        '
        Me.dayOfWeek.Location = New System.Drawing.Point(327, 257)
        Me.dayOfWeek.Name = "dayOfWeek"
        Me.dayOfWeek.Size = New System.Drawing.Size(89, 23)
        Me.dayOfWeek.TabIndex = 17
        Me.dayOfWeek.Text = "Day of Week"
        Me.dayOfWeek.UseVisualStyleBackColor = True
        '
        'addHours
        '
        Me.addHours.Location = New System.Drawing.Point(335, 56)
        Me.addHours.Name = "addHours"
        Me.addHours.Size = New System.Drawing.Size(75, 23)
        Me.addHours.TabIndex = 15
        Me.addHours.Text = "Add Hours"
        Me.addHours.UseVisualStyleBackColor = True
        '
        'btnToday
        '
        Me.btnToday.Location = New System.Drawing.Point(327, 300)
        Me.btnToday.Name = "btnToday"
        Me.btnToday.Size = New System.Drawing.Size(89, 23)
        Me.btnToday.TabIndex = 22
        Me.btnToday.Text = "Today"
        Me.btnToday.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(102, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(279, 20)
        Me.TextBox1.TabIndex = 23
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(49, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Answer : "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(438, 355)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnToday)
        Me.Controls.Add(Me.addSeconds)
        Me.Controls.Add(Me.leapYear)
        Me.Controls.Add(Me.shortDate)
        Me.Controls.Add(Me.parse)
        Me.Controls.Add(Me.dayOfWeek)
        Me.Controls.Add(Me.addHours)
        Me.Controls.Add(Me.monthDays)
        Me.Controls.Add(Me.longDate)
        Me.Controls.Add(Me.shortTime)
        Me.Controls.Add(Me.dayOfYear)
        Me.Controls.Add(Me.day)
        Me.Controls.Add(Me.addYears)
        Me.Controls.Add(Me.addMonth)
        Me.Controls.Add(Me.compare)
        Me.Controls.Add(Me.BtnSubtract)
        Me.Controls.Add(Me.longTime)
        Me.Controls.Add(Me.btnNow)
        Me.Controls.Add(Me.month)
        Me.Controls.Add(Me.addDays)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents addDays As System.Windows.Forms.Button
    Friend WithEvents month As System.Windows.Forms.Button
    Friend WithEvents btnNow As System.Windows.Forms.Button
    Friend WithEvents longTime As System.Windows.Forms.Button
    Friend WithEvents BtnSubtract As System.Windows.Forms.Button
    Friend WithEvents compare As System.Windows.Forms.Button
    Friend WithEvents addMonth As System.Windows.Forms.Button
    Friend WithEvents monthDays As System.Windows.Forms.Button
    Friend WithEvents longDate As System.Windows.Forms.Button
    Friend WithEvents shortTime As System.Windows.Forms.Button
    Friend WithEvents dayOfYear As System.Windows.Forms.Button
    Friend WithEvents day As System.Windows.Forms.Button
    Friend WithEvents addYears As System.Windows.Forms.Button
    Friend WithEvents addSeconds As System.Windows.Forms.Button
    Friend WithEvents leapYear As System.Windows.Forms.Button
    Friend WithEvents shortDate As System.Windows.Forms.Button
    Friend WithEvents parse As System.Windows.Forms.Button
    Friend WithEvents dayOfWeek As System.Windows.Forms.Button
    Friend WithEvents addHours As System.Windows.Forms.Button
    Friend WithEvents btnToday As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
