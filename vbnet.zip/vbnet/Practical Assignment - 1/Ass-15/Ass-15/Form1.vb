﻿'15. Write a program using loop that will generate every third integer (2, 5, 8... up to 100) beginning with i=2 And c
'    ontinuing for all integers that are less than 100. calculate the sum of those integers that are divisible by 5.

Public Class Form1

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click

        Dim items As New ArrayList
        Dim sum As Integer = 0

        Dim num As Integer = 2
        While num < 100
            ListBox1.Items.Add(num)
            If num Mod 5 = 0 Then
                sum += num
            End If
            num = num + 3
        End While

        MsgBox("Sum of Number of Divide by 5 is : " & sum)
    End Sub
End Class
