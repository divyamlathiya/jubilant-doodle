﻿'12.Write a vb.net program to print weekday in listbox using array.

Public Class Form1
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Dim daysOfWeek As String() = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

        For Each day In daysOfWeek
            ListBox1.Items.Add(day)
        Next

    End Sub
End Class
