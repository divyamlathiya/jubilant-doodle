﻿'7.Write a vb.net program that calculates net salary (basic+da+hra-pt) using procedure.Consider da = 105% Of basic,Hra=25% Of basic,pt=Rs.200

Public Class Form1

    Public Sub GetSalary(ByVal salary As Double)

        Dim da As Double
        Dim Hra As Double
        Dim pt As Integer = 200
        Dim netSalary As Double

        da = salary * 105 / 100
        Hra = salary * 25 / 100

        'MsgBox(salary & da & Hra)
        netSalary = (salary + da + Hra) - pt
        TextBox2.Text = netSalary

    End Sub

    Private Sub ButCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButCalculate.Click
        GetSalary(TextBox1.Text)
    End Sub

End Class
