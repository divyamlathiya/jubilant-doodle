﻿'10. Write a vb.net program to print table of given number.for example (5*1=5,5*2=10 and so on)

Public Class Form1
    Private Sub btnCal_Click(sender As System.Object, e As System.EventArgs) Handles btnCal.Click

        Dim i As Integer
        Dim num As Integer = TextBox1.Text

        For i = 1 To 10
            Dim ans = num * i
            ListBox1.Items.Add(num & " * " & i & " = " & ans)
        Next
    End Sub

End Class
