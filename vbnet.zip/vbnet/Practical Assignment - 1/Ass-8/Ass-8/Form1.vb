﻿'8.Write a vb.net program that calculates net salary (basic+da+hra-pt) using function.Consider da = 105% Of basic,Hra=25% Of basic,pt=Rs.200

Public Class Form1

    Public Function getSalary(ByVal salary As Double) As Double

        Dim da As Double
        Dim Hra As Double
        Dim Pt As Integer = 200
        Dim netSalary As Double

        da = salary * 105 / 100
        Hra = salary * 25 / 100

        netSalary = (salary + da + Hra) - Pt
        TextBox2.Text = netSalary

    End Function


    Private Sub BtnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCalculate.Click
        getSalary(TextBox1.Text)
    End Sub
End Class
