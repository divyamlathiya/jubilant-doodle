﻿'3.Write a vb.net program to perform data type conversion functions.

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim text As String = "17.46"
        Dim n1 As Double
        Dim n2 As Integer

        n1 = CType(text, Double) + 5.5
        n2 = CType(text, Integer)

        MsgBox("Text : " & text & " To Double " & n1)
        MsgBox("Text : " & text & " To Integer " & n2)
    End Sub
End Class
