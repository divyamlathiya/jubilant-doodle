﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Buttondot = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Buttonpst = New System.Windows.Forms.Button()
        Me.Buttonequal = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Location = New System.Drawing.Point(20, 66)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(56, 39)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "7"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.Location = New System.Drawing.Point(91, 66)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(53, 39)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "8"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.Control
        Me.Button3.Location = New System.Drawing.Point(160, 66)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(53, 39)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "9"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Control
        Me.Button4.Location = New System.Drawing.Point(20, 123)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(56, 39)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.Control
        Me.Button5.Location = New System.Drawing.Point(91, 123)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(53, 39)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.Control
        Me.Button6.Location = New System.Drawing.Point(160, 123)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(53, 39)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.Control
        Me.Button7.Location = New System.Drawing.Point(20, 184)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(56, 39)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "1"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.Control
        Me.Button8.Location = New System.Drawing.Point(91, 184)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(53, 39)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "2"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.Control
        Me.Button9.Location = New System.Drawing.Point(160, 184)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(53, 39)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "3"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.Control
        Me.Button10.Location = New System.Drawing.Point(20, 241)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(56, 39)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "0"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Buttondot
        '
        Me.Buttondot.BackColor = System.Drawing.SystemColors.Control
        Me.Buttondot.Location = New System.Drawing.Point(160, 241)
        Me.Buttondot.Name = "Buttondot"
        Me.Buttondot.Size = New System.Drawing.Size(53, 39)
        Me.Buttondot.TabIndex = 10
        Me.Buttondot.Text = "."
        Me.Buttondot.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.Control
        Me.Button12.Location = New System.Drawing.Point(302, 183)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(58, 39)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "/"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.Control
        Me.Button13.Location = New System.Drawing.Point(227, 183)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(58, 41)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "*"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.Control
        Me.Button14.Location = New System.Drawing.Point(302, 123)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(58, 39)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "-"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.Control
        Me.Button15.Location = New System.Drawing.Point(227, 123)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(58, 41)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "+"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Buttonpst
        '
        Me.Buttonpst.BackColor = System.Drawing.SystemColors.Control
        Me.Buttonpst.Location = New System.Drawing.Point(302, 242)
        Me.Buttonpst.Name = "Buttonpst"
        Me.Buttonpst.Size = New System.Drawing.Size(58, 39)
        Me.Buttonpst.TabIndex = 16
        Me.Buttonpst.Text = "√"
        Me.Buttonpst.UseVisualStyleBackColor = False
        '
        'Buttonequal
        '
        Me.Buttonequal.BackColor = System.Drawing.SystemColors.Control
        Me.Buttonequal.Location = New System.Drawing.Point(227, 242)
        Me.Buttonequal.Name = "Buttonequal"
        Me.Buttonequal.Size = New System.Drawing.Size(58, 39)
        Me.Buttonequal.TabIndex = 19
        Me.Buttonequal.Text = "="
        Me.Buttonequal.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.SystemColors.Control
        Me.Button21.Location = New System.Drawing.Point(227, 66)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(133, 39)
        Me.Button21.TabIndex = 20
        Me.Button21.Text = "Clear"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(23, 22)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(337, 20)
        Me.TextBox1.TabIndex = 21
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(91, 242)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(53, 38)
        Me.Button16.TabIndex = 22
        Me.Button16.Text = "00"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(377, 299)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Buttonequal)
        Me.Controls.Add(Me.Buttonpst)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Buttondot)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = " "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Buttondot As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Buttonpst As System.Windows.Forms.Button
    Friend WithEvents Buttonequal As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button16 As Button
End Class
