﻿'4.Write a vb.net Program to make calculator Application.

Public Class Form1
    Dim val1 As Double
    Dim val2 As Double
    Dim str As String
    Dim res As Double
    Function cal(ByVal val1 As Double, ByVal val2 As Double) As Double
        If str = "+" Then
            res = val1 + val2
        ElseIf str = "-" Then
            res = val1 - val2
        ElseIf str = "/" Then
            res = val1 / val2
        ElseIf str = "*" Then
            res = val1 * val2
        ElseIf str = "sq" Then
            res = val1 * val1
        End If
        Return res
    End Function
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TextBox1.Text &= 1
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox1.Text &= 2
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        TextBox1.Text &= 3
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TextBox1.Text &= 4
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text &= 5
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TextBox1.Text &= 6
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text &= 7
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text &= 8
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Text &= 9
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        TextBox1.Text &= 0
    End Sub
    Private Sub Buttondot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttondot.Click
        TextBox1.Text &= "."
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        val1 = TextBox1.Text
        str = "+"
        TextBox1.Clear()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        val1 = TextBox1.Text
        str = "-"
        TextBox1.Clear()
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        val1 = TextBox1.Text
        str = "*"
        TextBox1.Clear()
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        val1 = TextBox1.Text
        str = "/"
        TextBox1.Clear()
    End Sub

    Private Sub Buttonequal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonequal.Click
        val2 = TextBox1.Text
        cal(val1, val2)
        TextBox1.Text = res
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        TextBox1.Clear()
        val1 = 0
        val2 = 0
        str = ""
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonpst.Click
        val1 = TextBox1.Text
        str = "sq"
        TextBox1.Clear()
        cal(val1, val2)
        TextBox1.Text = res
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        val1 = TextBox1.Text
        str = "%"
        TextBox1.Clear()
    End Sub

    Private Sub Button16_Click_1(sender As Object, e As EventArgs) Handles Button16.Click
        TextBox1.Text &= 0
    End Sub
End Class
