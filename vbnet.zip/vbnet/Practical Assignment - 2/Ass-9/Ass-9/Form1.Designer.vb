﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbFemale = New System.Windows.Forms.RadioButton()
        Me.rbMale = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbAbove40 = New System.Windows.Forms.RadioButton()
        Me.rb19to40 = New System.Windows.Forms.RadioButton()
        Me.rbLessThan18 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkAllRight = New System.Windows.Forms.CheckBox()
        Me.chkCantDrive = New System.Windows.Forms.CheckBox()
        Me.chkDriveCar = New System.Windows.Forms.CheckBox()
        Me.rdbLess18 = New System.Windows.Forms.RadioButton()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(138, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(255, 20)
        Me.TextBox1.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.rbFemale)
        Me.GroupBox1.Controls.Add(Me.rbMale)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(138, 65)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(113, 100)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Gender"
        '
        'rbFemale
        '
        Me.rbFemale.AutoSize = True
        Me.rbFemale.Location = New System.Drawing.Point(6, 42)
        Me.rbFemale.Name = "rbFemale"
        Me.rbFemale.Size = New System.Drawing.Size(71, 20)
        Me.rbFemale.TabIndex = 1
        Me.rbFemale.TabStop = True
        Me.rbFemale.Text = "Female"
        Me.rbFemale.UseVisualStyleBackColor = True
        '
        'rbMale
        '
        Me.rbMale.AutoSize = True
        Me.rbMale.Location = New System.Drawing.Point(6, 19)
        Me.rbMale.Name = "rbMale"
        Me.rbMale.Size = New System.Drawing.Size(55, 20)
        Me.rbMale.TabIndex = 0
        Me.rbMale.TabStop = True
        Me.rbMale.Text = "Male"
        Me.rbMale.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox2.Controls.Add(Me.rbAbove40)
        Me.GroupBox2.Controls.Add(Me.rb19to40)
        Me.GroupBox2.Controls.Add(Me.rbLessThan18)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(280, 65)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(113, 100)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Age"
        '
        'rbAbove40
        '
        Me.rbAbove40.AutoSize = True
        Me.rbAbove40.Location = New System.Drawing.Point(6, 68)
        Me.rbAbove40.Name = "rbAbove40"
        Me.rbAbove40.Size = New System.Drawing.Size(82, 20)
        Me.rbAbove40.TabIndex = 2
        Me.rbAbove40.TabStop = True
        Me.rbAbove40.Text = "Above 40"
        Me.rbAbove40.UseVisualStyleBackColor = True
        '
        'rb19to40
        '
        Me.rb19to40.AutoSize = True
        Me.rb19to40.Location = New System.Drawing.Point(6, 42)
        Me.rb19to40.Name = "rb19to40"
        Me.rb19to40.Size = New System.Drawing.Size(63, 20)
        Me.rb19to40.TabIndex = 1
        Me.rb19to40.TabStop = True
        Me.rb19to40.Text = "19 - 40"
        Me.rb19to40.UseVisualStyleBackColor = True
        '
        'rbLessThan18
        '
        Me.rbLessThan18.AutoSize = True
        Me.rbLessThan18.Location = New System.Drawing.Point(6, 19)
        Me.rbLessThan18.Name = "rbLessThan18"
        Me.rbLessThan18.Size = New System.Drawing.Size(105, 20)
        Me.rbLessThan18.TabIndex = 0
        Me.rbLessThan18.TabStop = True
        Me.rbLessThan18.Text = "Less Than 18"
        Me.rbLessThan18.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox3.Controls.Add(Me.chkAllRight)
        Me.GroupBox3.Controls.Add(Me.chkCantDrive)
        Me.GroupBox3.Controls.Add(Me.chkDriveCar)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(138, 191)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(113, 100)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Right"
        '
        'chkAllRight
        '
        Me.chkAllRight.AutoSize = True
        Me.chkAllRight.Location = New System.Drawing.Point(3, 70)
        Me.chkAllRight.Name = "chkAllRight"
        Me.chkAllRight.Size = New System.Drawing.Size(75, 20)
        Me.chkAllRight.TabIndex = 2
        Me.chkAllRight.Text = "All Right"
        Me.chkAllRight.UseVisualStyleBackColor = True
        '
        'chkCantDrive
        '
        Me.chkCantDrive.AutoSize = True
        Me.chkCantDrive.Location = New System.Drawing.Point(3, 44)
        Me.chkCantDrive.Name = "chkCantDrive"
        Me.chkCantDrive.Size = New System.Drawing.Size(91, 20)
        Me.chkCantDrive.TabIndex = 1
        Me.chkCantDrive.Text = "Can't Drive"
        Me.chkCantDrive.UseVisualStyleBackColor = True
        '
        'chkDriveCar
        '
        Me.chkDriveCar.AutoSize = True
        Me.chkDriveCar.Location = New System.Drawing.Point(3, 18)
        Me.chkDriveCar.Name = "chkDriveCar"
        Me.chkDriveCar.Size = New System.Drawing.Size(82, 20)
        Me.chkDriveCar.TabIndex = 0
        Me.chkDriveCar.Text = "Drive Car"
        Me.chkDriveCar.UseVisualStyleBackColor = True
        '
        'rdbLess18
        '
        Me.rdbLess18.AutoSize = True
        Me.rdbLess18.Location = New System.Drawing.Point(6, 19)
        Me.rdbLess18.Name = "rdbLess18"
        Me.rdbLess18.Size = New System.Drawing.Size(106, 20)
        Me.rdbLess18.TabIndex = 0
        Me.rdbLess18.TabStop = True
        Me.rdbLess18.Text = "Less Than 18"
        Me.rdbLess18.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(214, 326)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(113, 44)
        Me.btnOk.TabIndex = 2
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Adobe Caslon Pro", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 22)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Name :"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 528)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbFemale As System.Windows.Forms.RadioButton
    Friend WithEvents rbMale As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbAbove40 As System.Windows.Forms.RadioButton
    Friend WithEvents rb19to40 As System.Windows.Forms.RadioButton
    Friend WithEvents rbLessThan18 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents chkDriveCar As System.Windows.Forms.CheckBox
    Friend WithEvents chkAllRight As System.Windows.Forms.CheckBox
    Friend WithEvents chkCantDrive As System.Windows.Forms.CheckBox
    Friend WithEvents rdbLess18 As System.Windows.Forms.RadioButton
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents Label1 As Label
End Class
