﻿'9.Write a Vb.net program to design the following form, allow the user To Select radio buttons from Gender And Age Panel.
'After Selection appropriate Checkbox from Right Panel should be selected automatically. Display appropriate message into the Messagebox by clicking On Ok button.

Public Class Form1
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs)
        ' Set initial state if needed
    End Sub

    Private Sub RadioButton_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rb19to40.CheckedChanged, rbAbove40.CheckedChanged
        ' Auto-select checkboxes based on age selection
        If rbLessThan18.Checked Then
            chkDriveCar.Checked = False
            chkCantDrive.Checked = True
            chkAllRight.Checked = False
        ElseIf rb19to40.Checked Then
            chkDriveCar.Checked = True
            chkCantDrive.Checked = False
            chkAllRight.Checked = False
        ElseIf rbAbove40.Checked Then
            chkDriveCar.Checked = True
            chkCantDrive.Checked = False
            chkAllRight.Checked = True
        End If
    End Sub

    Private Sub btnOk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOk.Click
        ' Get selected gender
        Dim gender As String = ""
        If rbMale.Checked Then
            gender = "Male"
        ElseIf rbFemale.Checked Then
            gender = "Female"
        End If

        ' Get selected age
        Dim age As String = ""
        If rbLessThan18.Checked Then
            age = "Less than 18"
        ElseIf rb19to40.Checked Then
            age = "19 - 40"
        ElseIf rbAbove40.Checked Then
            age = "Above 40"
        End If

        ' Get selected rights
        Dim rights As String = ""
        If rb19to40.Checked Or rbAbove40.Checked Then
            rights &= "Drive Car, "
            'rights &= chkDriveCar.Checked
        End If
        If rbLessThan18.Checked Then
            rights &= "Can't Drive, "
            'rights &= chkCantDrive.Checked
        End If
        If rb19to40.Checked AndAlso rbAbove40.Checked Then
            rights &= "All Right, "
            'rights &= chkAllRight.Checked
        End If


        ' Trim last comma and space
        If rights.Length > 0 Then
            rights = rights.Substring(0, rights.Length - 2)
        End If

        ' Display message box
        MessageBox.Show("Name: " & TextBox1.Text & vbCrLf & "Gender: " & gender & vbCrLf & "Age: " & age & vbCrLf & "Rights: " & rights, "User Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
