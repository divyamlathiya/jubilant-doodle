﻿'12.Write vb.net program will ask the user what timetable they want to learn, it will then calculate the timestables for that number.
'It makes use Of the counter (x) In the Loop To calculate the answer.

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        lstTimesTable.Items.Clear()

        ' Get the user input
        Dim number As Integer
        If Integer.TryParse(txtNumber.Text, number) AndAlso number >= 1 AndAlso number <= 12 Then
            ' Generate the times table
            For x As Integer = 0 To 12
                Dim result As String = number & " x " & x & " = " & (number * x)
                lstTimesTable.Items.Add(result)
            Next
        Else
            MessageBox.Show("Please enter a number between 1 and 12.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNumber.Clear()
            txtNumber.Focus()

        End If
    End Sub
End Class


