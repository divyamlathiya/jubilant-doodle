﻿'8.Write a Vb.net program to Check Type of Data and display appropriate message For data.
'(Use Type Checking Function For Number, Date, Array, IsNothing)

Public Class Form1

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        Dim input As Object = txtInput.Text

        ' Check for Nothing
        If String.IsNullOrEmpty(input) Then
            lblResult.Text = "The data is Nothing (empty)."
        ElseIf IsNumeric(input) Then
            lblResult.Text = "The data is a Number."
        ElseIf IsDate(input) Then
            lblResult.Text = "The data is a Date."
        ElseIf TypeOf input Is Array Then
            lblResult.Text = "The data is an Array."
        Else
            lblResult.Text = "The data type is not specifically checked."
        End If
    End Sub
End Class
