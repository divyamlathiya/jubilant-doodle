﻿'11. Write a Vb.net program to design following screen, accept the details from the user. Clicking On Submit button Net Salary should be calculated And displayed into the Textbox.
'Display the Messagebox informing the Name And Net Salary of employee


Public Class Form1
    Private Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        ' Variables to store user inputs
        Try

            Dim name As String = txtName.Text
            Dim basicSalary, da, hra, ma, pf, pt, it, netSalary As Double

            basicSalary = txtBasicSalary.Text
            da = txtDA.Text
            hra = txtHRA.Text
            ma = txtMA.Text
            pf = txtPF.Text
            it = txtIT.Text

            ' Calculate Net Salary
            netSalary = (basicSalary + da + hra + ma) - (pf + pt + it)

            ' Display Net Salary in TextBox
            txtNetSalary.Text = netSalary.ToString("F2")

            ' Show message with Name and Net Salary
            MessageBox.Show("Employee Name: " & name & vbCrLf & "Net Salary: " & netSalary.ToString("F2"),
                            "Salary Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class
