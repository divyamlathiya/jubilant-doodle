﻿'13. Write vb.net program to fill up a list box with items, retrieve the total number Of items In the list box, sort the list box, remove some items And clear the entire list box.

Public Class Form1
    ' Add item to the ListBox
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click
        If txtItem.Text.Trim() <> "" Then
            lstItems.Items.Add(txtItem.Text)
            txtItem.Clear()
        Else
            MessageBox.Show("Please enter an item!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Display total number of items
    Private Sub btnCount_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCount.Click
        lblCount.Text = "Total Items: " & lstItems.Items.Count
    End Sub

    ' Sort the ListBox items
    Private Sub btnSort_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSort.Click
        lstItems.Sorted = True
    End Sub

    ' Remove the selected item
    Private Sub btnRemove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRemove.Click
        If lstItems.SelectedIndex <> -1 Then
            lstItems.Items.RemoveAt(lstItems.SelectedIndex)
        Else
            MessageBox.Show("Please select an item to remove!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Clear all items from ListBox
    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        lstItems.Items.Clear()
        lblCount.Text = "Total Items: 0"
    End Sub
End Class
