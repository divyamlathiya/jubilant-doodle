﻿'2.Write a vb.net Program to Accept two value from the input box And add these number And display addition in messagebox

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim n1 As Double = InputBox("Enter First Number:")
        Dim n2 As Double = InputBox("Enter Secound Number:")
        Dim sum As Double = n1 + n2
        MessageBox.Show("your sum is : " & sum)
    End Sub
End Class
