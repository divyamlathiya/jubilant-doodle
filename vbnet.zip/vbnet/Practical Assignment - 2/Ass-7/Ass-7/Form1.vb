﻿'7. Write a Vb.net program to accept number from user into the Textbox.Calculate the square root, of that number, Check that it Is number Or Not And display result into the Message Box.

Public Class Form1
    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim input As String = TextBox1.Text

        Dim sqrtResult As Double = Math.Sqrt(input)
        MessageBox.Show("The square root of " & input.ToString() & " is: " & sqrtResult.ToString(), "Square Root Result", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
