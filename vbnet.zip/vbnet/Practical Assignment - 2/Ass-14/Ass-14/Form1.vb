﻿'14. Write vb.net program to fill a combo box with various items, Get the selected items In the combo box And show them In a list box And sort the items.

Public Class Form1
    ' Fill ComboBox on Form Load
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        cmbItems.Items.Add("Cricket")
        cmbItems.Items.Add("Hockey")
        cmbItems.Items.Add("Football")
        cmbItems.Items.Add("Golf")
        cmbItems.Items.Add("Table Tenis")
    End Sub

    ' Move selected ComboBox item to ListBox
    Private Sub btnAddToList_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddToList.Click
        If cmbItems.SelectedItem IsNot Nothing Then
            lstSelectedItems.Items.Add(cmbItems.SelectedItem)
        Else
            MessageBox.Show("Please select an item!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Sort the ListBox items
    Private Sub btnSort_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSort.Click
        Dim sortedList As New List(Of String)

        For Each item In lstSelectedItems.Items
            sortedList.Add(item.ToString())
        Next

        sortedList.Sort()

        lstSelectedItems.Items.Clear()
        For Each item In sortedList
            lstSelectedItems.Items.Add(item)
        Next
    End Sub

    ' Clear all items from ListBox
    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        lstSelectedItems.Items.Clear()
    End Sub

    Private Sub Button1btnAddToList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddToList.Click

    End Sub

    Private Sub cmbItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbItems.SelectedIndexChanged

    End Sub
End Class
