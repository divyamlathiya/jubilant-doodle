﻿'6.Write a Vb.net program to accept a character from keyboard And check whether it Is vowel Or Not. Also display the case of that character.(Use Select Case)

Public Class Form1
    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        Dim ch As Char
        ch = TextBox1.Text

        'Check the character is Vovel or Not.
        Select Case Char.ToLower(ch)
            Case "a", "e", "i", "o", "u"
                Label5.Text = "The character is a vowel."
            Case Else
                Label5.Text = "The character is not a vowel."
        End Select

        ' Check the case of the character (uppercase or lowercase)
        Select Case ch
            Case "A" To "Z"
                Label4.Text = "The character is uppercase."
            Case "a" To "z"
                Label4.Text = "The character is lowercase."
            Case Else
                Label4.Text = "The character is neither uppercase nor lowercase."
        End Select

    End Sub

End Class
