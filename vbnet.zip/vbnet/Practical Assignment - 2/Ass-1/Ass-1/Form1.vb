﻿'1.Write a vb.net program to concatenate three strings (FN, MN,LN) And display in the messagebox.

Public Class Form1

    Private Sub btnConcate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConcate.Click
        Dim str1 As String = "FN"
        Dim str2 As String = "MN"
        Dim str3 As String = "LN"

        MessageBox.Show("Concated String is: " & str1 & str2 & str3)
    End Sub
End Class
