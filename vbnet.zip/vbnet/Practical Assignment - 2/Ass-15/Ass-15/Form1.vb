﻿'15.Write vb.net code to create MDI form. Put all Child Form inMDI form.
'Set MDI form Text (Visual Basic .Net Programming Language)

Public Class Form1

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim name As String = "Patel"
        Dim pass As String = "12345"


        If txtName.Text = name Then

            If txtPass.Text = pass Then
                MsgBox("Successfully Login")
                Dim f1 As New Form1
                Dim f2 As New Form2

                f1.Close()
                f2.Show()

            Else
                MsgBox("Password is incorrect")
                txtName.Clear()
                txtPass.Focus()
            End If
        Else
            MsgBox("Invalid ! UserName")
            txtName.Clear()
            txtPass.Focus()

        End If
    End Sub
End Class
