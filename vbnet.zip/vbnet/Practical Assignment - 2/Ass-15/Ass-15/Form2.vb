﻿'Child Form :-

Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MessageBox.Show("This is Child Page", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
    End Sub
End Class