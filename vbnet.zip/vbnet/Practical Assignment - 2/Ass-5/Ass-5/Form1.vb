﻿'5. Write a vb.net Program that will ask the user to enter a score On a test And then decide what grade they got.
'Entering a test score you could say that it must be between 0 And 100(Use Logical Operator for this.)
'Note: If score Is >= 70 Then A,>=60 Then B,>=50 Then C,>=40 then D, else C). (Use IF ...ElseIf...)

Public Class Form1

    Private Sub btnGrade_Click(sender As System.Object, e As System.EventArgs) Handles btnGrade.Click

        Dim marks As Integer = TextBox1.Text

        If (marks <= 100 AndAlso marks >= 0) Then
            Label3.Text = "Your Marks Is : " & marks

            If marks >= 70 Then
                Label2.Text = "Your Grade is : A "
            ElseIf marks >= 60 Then
                Label2.Text = "Your Grade is : B "
            ElseIf marks >= 50 Then
                Label2.Text = "Your Grade is : C "
            ElseIf marks >= 40 Then
                Label2.Text = "Your Grade is : D "
            Else
                Label2.Text = "Your Are Fail "
            End If

        Else
            MessageBox.Show("Please enter marks between 0 ans 100")
            TextBox1.Clear()
            TextBox1.Focus()

        End If

    End Sub

End Class
