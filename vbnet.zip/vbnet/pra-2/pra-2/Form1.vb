﻿'(1) Create a VB.Net MDI Application that has following functionalities for a Grocery Store.
'(1) Insert Grocery Items in Grocery Master table (Item No, Name, MRP, Sell Price, Quantity)
'(2) Display data in DataGridView and ability to Search for Specific Item Name.
'(3) Update, Delete operations for Updating Stock Quantity.
'----point this----(4) Listing of Out of Stock Grocery Items in New Form.

Imports System.Data.SqlClient

Public Class Form1

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bca sem-4\@final practical all subject\vbnet\vbnet\pra-2\pra-2\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con

            MsgBox("Connection SucsessFull !")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata()
        clear()
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from gromst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView1.DataSource = dt

            ' it is optional for mack better program using search in combobox 
            ComboBox1.Items.Clear()

            For Each row In dt.Rows
                ComboBox1.Items.Add(row("name"))
            Next

            ' it's optional for add one blank column in combo box

            ComboBox1.Items.Add("")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            'this comand use for count effected rows acording condition
            cmd.CommandText = "select count(*) from gromst where name = '" & TextBox2.Text & "'"
            con.Open()
            Dim row As Integer = cmd.ExecuteScalar()
            con.Close()

            'it's optional i print how much row is effected using this quary
            MsgBox("Total row effected is :" & row)

            If row = 0 Then

                'it's optional this is basic validation using blank and type of data
                If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then

                    'it's optional for clear input fields
                    clear()

                    Exit Sub
                End If

                If Not IsNumeric(TextBox3.Text) Or Not IsNumeric(TextBox4.Text) Or Not IsNumeric(TextBox4.Text) Then

                    'it's optional for clear input fields
                    clear()

                    Exit Sub
                End If
                cmd.CommandText = "insert into gromst values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"

                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                MsgBox("data is inserted !")

                alldata()
                clear()
            Else
                MsgBox("this record is alredy in the table.")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

            'it's optional but you need after get error from catch block
            con.Close()
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            'this comand use for count effected rows acording condition
            cmd.CommandText = "select count(*) from gromst where name = '" & TextBox2.Text & "' "
            con.Open()
            Dim row As Integer = CInt(cmd.ExecuteScalar()) 'when check using name or string so need to convert row in integer using Cint()
            con.Close()

            'it's optional
            MsgBox("Total Effected Row is :" & row)

            If row = 1 Then
                cmd.CommandText = "update gromst set itemno = '" & TextBox1.Text & "',name = '" & TextBox2.Text & "',mrp = '" & TextBox3.Text & "',sellprice = '" & TextBox4.Text & "',qty = '" & TextBox5.Text & "' where itemno = '" & TextBox1.Text & "'"

                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                MsgBox("record is updated !")

                alldata()

                clear()
            Else
                cmd.CommandText = "insert into gromst values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"

                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                MsgBox("data is inserted !")

                alldata()
                clear()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

            'it's optional but you need after get error from catch block
            con.Close()
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "delete from gromst where itemno = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is deleted !")

            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)

            'it's optional but you need after get error from catch block
            con.Close()
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            cmd.CommandText = "select * from gromst where name = '" & ComboBox1.Text & "'"

            con.Open()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt

            con.Close()

            clear()

            'it's optional for if not search any data so display all
            If ComboBox1.Text = "" Then
                alldata()
                clear()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)

            'it's optional but you need after get error from catch block
            con.Close()
        End Try
    End Sub

    Private Sub btnoutofstock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnoutofstock.Click
        Dim f2 As New Form2()
        f2.Show()
        Me.Hide()
    End Sub

    'it's fully optional part in program
    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        If e.RowIndex >= 0 Then

            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

            TextBox1.Text = row.Cells("itemno").Value.ToString()
            TextBox2.Text = row.Cells("name").Value.ToString()
            TextBox3.Text = row.Cells("mrp").Value.ToString()
            TextBox4.Text = row.Cells("sellprice").Value.ToString()
            TextBox5.Text = row.Cells("qty").Value.ToString()

            'this is not in table only for example practice

            ' ComboBox1.Text = row.Cells ("prducttype").Value.ToString()
            ' DateTimePicker1.value = Convert.ToDateTime(row.Cells("selldate").Value)

        End If

    End Sub
End Class
