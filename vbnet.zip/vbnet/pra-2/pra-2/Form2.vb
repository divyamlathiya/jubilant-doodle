﻿Imports System.Data.SqlClient
Public Class Form2
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bca sem-4\@final practical all subject\vbnet\vbnet\pra-2\pra-2\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con

            MsgBox("Connection sucsessfull !")
        Catch ex As Exception
            MsgBox (ex.Message)
        End Try

        'this is for show out of stock data in new form
        Try
            cmd.CommandText = "select * from gromst where qty = 0"

            con.Open()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView1.DataSource = dt

            con.Close()

            MsgBox("This Data Out of stock !")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim f1 As New Form1()
        f1.Show()
        Me.Close()
    End Sub
End Class