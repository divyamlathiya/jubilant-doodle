﻿'--- 4 time comes in exam ---(1) create a table empmst with following fields:
'empmst (empno [pk], ename, city)
'create employee master form to accept the above information. 
'it must have add new, save, update, delete, search & exit buttons.

Imports System.Data.SqlClient

Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bca sem-4\@final practical all subject\vbnet\vbnet\pra-1\pra-1\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con

            MsgBox("connection sucsesful !")

        Catch ex As Exception
            MsgBox(ex)
        End Try

        clear()
        alldata()

    End Sub

    Sub clear()

        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""

    End Sub

    Sub alldata()

        Try

            cmd.CommandText = "select * from empmst "

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView1.DataSource = dt

        Catch ex As Exception
            MsgBox(ex)
        End Try

    End Sub

    'it is only clear field
    Private Sub addnewbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addnewbtn.Click
        clear()
    End Sub

    'it is only insert field
    Private Sub savebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles savebtn.Click
        Try
            cmd.CommandText = "insert into empmst values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "')"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("data is inserted")

            alldata()

            'clear()'it is optionl for this program because clear(add new) field is available

        Catch ex As Exception
            MsgBox(ex)
        End Try
    End Sub

    'update acording empno
    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            cmd.CommandText = "update empmst set empno = '" & TextBox1.Text & "',ename = '" & TextBox2.Text & "',city = '" & ComboBox1.Text & "' where empno = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("update sucsessfull !")

            alldata()

            'clear()'it is optionl for this program because clear(add new) field is available

        Catch ex As Exception
            MsgBox(ex)
        End Try
    End Sub

    'delete acording empno
    Private Sub deletebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deletebtn.Click
        Try
            cmd.CommandText = "delete from empmst where empno = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("delete sucsessfull !")

            alldata()

            'clear()'it is optionl for this program because clear(add new) field is available
        Catch ex As Exception
            MsgBox(ex)
        End Try
    End Sub

    'search city wise
    Private Sub searchbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchbtn.Click
        Try
            cmd.CommandText = "select * from empmst where city = '" & ComboBox1.Text & "'"

            con.Open()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt

            con.Close()

        Catch ex As Exception
            MsgBox(ex)
        End Try  
    End Sub

    'this is exit field
    Private Sub exitbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitbtn.Click
        End
    End Sub

    ' it's fully optional part of program
    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        If e.RowIndex >= 0 Then

            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

            TextBox1.Text = row.Cells("empno").Value.ToString()
            TextBox2.Text = row.Cells("ename").Value.ToString()
            ComboBox1.Text = row.Cells("city").Value.ToString()

            ' it is not in this program but write for practice purpose

            ' DateTimePicker1.Value = Convert.ToDateTime(row.Cells("joiningdate").Value)

        End If

    End Sub
End Class
