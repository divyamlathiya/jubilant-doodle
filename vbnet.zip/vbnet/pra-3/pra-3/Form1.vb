﻿'(1) Create a VB.Net application to manage insurance information.
'Agent_Master: (Agent_code, Agent_name, City)
'Policy_Master: (Policy_no, Agent_code, Customer_name, Start_date, End_date, Policy_amt)
'Perform following operations:
'(a) Provide Insert, Update, Delete and Display facilities.
'----point this----(b) Display policy no., agent no. and policy holder name in ascending order based on policy amount.
'----point this----(c) Display Agent name, his clients' name and total policy amount agent-wise.
' add below query for mack all in one project
'----point this----1. display agent details with total amount of policies sold by him only highest(maximum) amounted agent no another.
'----point this----2. display name of customer whose buy policy in this month.
'----point this----3. display name of costomer along with his plicy agent's name.
'----point this----4. increace policy amt by 5%
'----point this----5. display number of customer under each agent.
'----point this----6. remove all expiry policies.

Imports System.Data.SqlClient

Public Class Form1

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bca sem-4\@final practical all subject\vbnet\vbnet\pra-3\pra-3\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con

            MsgBox("connection Sucsessfull !")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata()
        clear()
    End Sub

    Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
    End Sub

    'it is hear not needed display data of agentmst table so optional
    Sub alldata()
        Try
            cmd.CommandText = "select * from agentmst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            cmd.CommandText = "insert into agentmst values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "')"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is inserted !")

            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            cmd.CommandText = "update agentmst set agentcode = '" & TextBox1.Text & "',agentname = '" & TextBox2.Text & "',city = '" & ComboBox1.Text & "' where agentcode = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is updated !")

            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "delete from agentmst where agentcode = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is delete !")

            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Dim f2 As New Form2()
        Me.Hide()
        f2.Show()
    End Sub

    ' it is fully optional auto fillup system

    'step 1 :- right click on DataGridView2.
    'step 2 :- click on  ⚡  button , which set on properties toolbar.
    'step 3 :- double click on CellClick. 
    'step 4 :- write below if bolck, inside of created Private Sub DataGridView2_CellClick ok.

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 Then

            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

            TextBox1.Text = row.Cells("agentcode").Value.ToString()
            TextBox2.Text = row.Cells("agentname").Value.ToString()
            ComboBox1.Text = row.Cells("city").Value.ToString()

        End If
    End Sub
End Class
