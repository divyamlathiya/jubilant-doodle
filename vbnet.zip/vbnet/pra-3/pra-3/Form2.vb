﻿'(1) Create a VB.Net application to manage insurance information.
'Agent_Master: (Agent_code, Agent_name, City)
'Policy_Master: (Policy_no, Agent_code, Customer_name, Start_date, End_date, Policy_amt)
'Perform following operations:
'(a) Provide Insert, Update, Delete and Display facilities.
'----point this----(b) Display policy no., agent no. and policy holder name in ascending order based on policy amount.
'----point this----(c) Display Agent name, his clients' name and total policy amount agent-wise.
' add below query for mack all in one project
'----point this----1. display agent details with total amount of policies sold by him only highest(maximum) amounted agent no another.
'----point this----2. display name of customer whose buy policy in this month.
'----point this----3. display name of costomer along with his plicy agent's name.
'----point this----4. increace policy amt by 5%.
'----point this----5. display number of customer under each agent.
'----point this----6. remove all expiry policies.

Imports System.Data.SqlClient

Public Class Form2
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bca sem-4\@final practical all subject\vbnet\vbnet\pra-3\pra-3\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con

            MsgBox("Welcome !")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata()
        clear()
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from agentmst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView1.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            cmd.CommandText = "select * from polimst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        DateTimePicker1.Value = Date.Now
        DateTimePicker2.Value = Date.Now
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            cmd.CommandText = "insert into polimst values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "','" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "','" & TextBox4.Text & "')"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is inserted !")

            alldata()
            clear()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            cmd.CommandText = "update polimst set polino = '" & TextBox1.Text & "',agentcode ='" & TextBox2.Text & "',custname = '" & TextBox3.Text & "',startdate = '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "',enddate = '" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "',poliamt ='" & TextBox4.Text & "'where  polino = '" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is updated !")

            alldata()
            clear()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "delete from polimst where polino ='" & TextBox1.Text & "'"

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MsgBox("record is deleted !")

            alldata()
            clear()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '(b) Display policy no., agent no. and policy holder name in ascending order based on policy amount.
    Private Sub qm1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles qm1.Click
        Try
            cmd.CommandText = "select polino,agentcode,custname from polimst order by poliamt asc"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '(c) Display Agent name, his clients' name and total policy amount agent-wise.
    Private Sub qm2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles qm2.Click
        Try
            cmd.CommandText = "select a.agentname,p.custname,(select sum(p.poliamt) from polimst p where a.agentcode = p.agentcode) as total_amount from agentmst a join polimst p on a.agentcode = p.agentcode "

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '1. display agent details with total amount of policies sold by him only highest(maximum) amounted agent no another.
    Private Sub q1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q1.Click
        Try
            cmd.CommandText = "select top 1 a.agentcode, a.agentname, a.city, sum(p.poliamt) As total_amt from agentmst a join polimst p on a.agentcode = p.agentcode group by a.agentcode,a.agentname,a.city order by total_amt desc"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    'display name of customer whose buy policy in this month.
    Private Sub q2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q2.Click
        Try
            cmd.CommandText = "select custname from polimst where month(startdate) = month(getdate()) and year(startdate) = year(getdate())"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '3. display name of costomer along with his plicy agent's name.
    Private Sub q3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q3.Click
        Try
            cmd.CommandText = "select p.custname,a.agentname from agentmst a join polimst p on a.agentcode = p.agentcode"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '4. increace policy amt by 5%.
    Private Sub q4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q4.Click
        Try
            cmd.CommandText = "update polimst set poliamt = poliamt * 1.05"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try

        'it's optional
        Try
            cmd.CommandText = "select * from polimst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '5. display number of customer under each agent.
    Private Sub q5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q5.Click
        Try
            'extra practice
            '(quary). display number of customer under each agent with agentname.
            'cmd.CommandText = "select a.agentname,count(p.agentcode) as total_num_policy from agentmst a join polimst p on a.agentcode = p.agentcode group by a.agentname"

            cmd.CommandText = "select count(*) as total_num_policy from polimst group by agentcode"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    '6. remove all expiry policies.
    Private Sub q6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles q6.Click
        Try
            cmd.CommandText = "delete from polimst where enddate < getdate()"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
        'it's optional
        Try
            cmd.CommandText = "select * from polimst"

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)

            da.Fill(dt)

            DataGridView3.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Dim f1 As New Form1()
        Me.Hide()
        f1.Show()
    End Sub

    ' it is fully optional auto fillup system

    'step 1 :- right click on DataGridView2.
    'step 2 :- click on  ⚡  button , which set on properties toolbar.
    'step 3 :- double click on CellClick. 
    'step 4 :- write below if bolck, inside of created Private Sub DataGridView2_CellClick ok.

    Private Sub DataGridView2_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView2.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView2.Rows(e.RowIndex)

            TextBox1.Text = row.Cells("polino").Value.ToString()
            TextBox2.Text = row.Cells("agentcode").Value.ToString()
            TextBox3.Text = row.Cells("custname").Value.ToString()
            TextBox4.Text = row.Cells("poliamt").Value.ToString()

            DateTimePicker1.Value = Convert.ToDateTime(row.Cells("startdate").Value)
            DateTimePicker2.Value = Convert.ToDateTime(row.Cells("enddate").Value)
        End If
    End Sub
End Class