﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btninsert = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.btngo = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.qm2 = New System.Windows.Forms.Button()
        Me.qm1 = New System.Windows.Forms.Button()
        Me.q3 = New System.Windows.Forms.Button()
        Me.q2 = New System.Windows.Forms.Button()
        Me.q1 = New System.Windows.Forms.Button()
        Me.q6 = New System.Windows.Forms.Button()
        Me.q5 = New System.Windows.Forms.Button()
        Me.q4 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btninsert
        '
        Me.btninsert.Location = New System.Drawing.Point(35, 301)
        Me.btninsert.Name = "btninsert"
        Me.btninsert.Size = New System.Drawing.Size(113, 57)
        Me.btninsert.TabIndex = 0
        Me.btninsert.Text = "Insert"
        Me.btninsert.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(175, 82)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(217, 30)
        Me.TextBox1.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(175, 116)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(217, 30)
        Me.TextBox2.TabIndex = 2
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(175, 150)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(217, 30)
        Me.TextBox3.TabIndex = 3
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(175, 183)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(216, 30)
        Me.DateTimePicker1.TabIndex = 4
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(175, 217)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(216, 30)
        Me.DateTimePicker2.TabIndex = 5
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(175, 251)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(217, 30)
        Me.TextBox4.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 27)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Policy No :-"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 119)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(147, 27)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Agent Code :-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(24, 187)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 27)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Satrt Date :-"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(24, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(139, 27)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Cust Name :-"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(24, 257)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(140, 27)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Policy Amt :-"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(24, 223)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(123, 27)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "End Date :-"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(285, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(153, 22)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Policy Table Data"
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(154, 301)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(113, 57)
        Me.btnupdate.TabIndex = 14
        Me.btnupdate.Text = "Update"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btndelete
        '
        Me.btndelete.Location = New System.Drawing.Point(273, 301)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(113, 57)
        Me.btndelete.TabIndex = 15
        Me.btndelete.Text = "Delete"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'btngo
        '
        Me.btngo.Location = New System.Drawing.Point(608, 12)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(351, 53)
        Me.btngo.TabIndex = 16
        Me.btngo.Text = "Go On Agent Page"
        Me.btngo.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(412, 240)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(277, 22)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Display Data (i,u,d) Policy Mst :-"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(412, 399)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(217, 22)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Processed Data(quarys) :-"
        '
        'qm2
        '
        Me.qm2.Location = New System.Drawing.Point(216, 364)
        Me.qm2.Name = "qm2"
        Me.qm2.Size = New System.Drawing.Size(170, 57)
        Me.qm2.TabIndex = 23
        Me.qm2.Text = "Poli Total Amt"
        Me.qm2.UseVisualStyleBackColor = True
        '
        'qm1
        '
        Me.qm1.Location = New System.Drawing.Point(35, 364)
        Me.qm1.Name = "qm1"
        Me.qm1.Size = New System.Drawing.Size(175, 57)
        Me.qm1.TabIndex = 22
        Me.qm1.Text = "Asc Order"
        Me.qm1.UseVisualStyleBackColor = True
        '
        'q3
        '
        Me.q3.Location = New System.Drawing.Point(273, 427)
        Me.q3.Name = "q3"
        Me.q3.Size = New System.Drawing.Size(113, 57)
        Me.q3.TabIndex = 27
        Me.q3.Text = "Cust , Agent Name"
        Me.q3.UseVisualStyleBackColor = True
        '
        'q2
        '
        Me.q2.Location = New System.Drawing.Point(154, 427)
        Me.q2.Name = "q2"
        Me.q2.Size = New System.Drawing.Size(113, 57)
        Me.q2.TabIndex = 26
        Me.q2.Text = "Current month poli"
        Me.q2.UseVisualStyleBackColor = True
        '
        'q1
        '
        Me.q1.Location = New System.Drawing.Point(35, 427)
        Me.q1.Name = "q1"
        Me.q1.Size = New System.Drawing.Size(113, 57)
        Me.q1.TabIndex = 25
        Me.q1.Text = "Max Amt Solder"
        Me.q1.UseVisualStyleBackColor = True
        '
        'q6
        '
        Me.q6.Location = New System.Drawing.Point(273, 490)
        Me.q6.Name = "q6"
        Me.q6.Size = New System.Drawing.Size(113, 57)
        Me.q6.TabIndex = 30
        Me.q6.Text = "Remove Exp. Poli"
        Me.q6.UseVisualStyleBackColor = True
        '
        'q5
        '
        Me.q5.Location = New System.Drawing.Point(154, 490)
        Me.q5.Name = "q5"
        Me.q5.Size = New System.Drawing.Size(113, 57)
        Me.q5.TabIndex = 29
        Me.q5.Text = "Num. Of Cust Agent"
        Me.q5.UseVisualStyleBackColor = True
        '
        'q4
        '
        Me.q4.Location = New System.Drawing.Point(35, 490)
        Me.q4.Name = "q4"
        Me.q4.Size = New System.Drawing.Size(113, 57)
        Me.q4.TabIndex = 28
        Me.q4.Text = "Increase Amt 5%"
        Me.q4.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(416, 107)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(543, 130)
        Me.DataGridView1.TabIndex = 33
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(412, 82)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(271, 22)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Display Data (i,u,d) Agent Mst :-"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(416, 424)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 24
        Me.DataGridView3.Size = New System.Drawing.Size(543, 130)
        Me.DataGridView3.TabIndex = 34
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(416, 266)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.Size = New System.Drawing.Size(543, 130)
        Me.DataGridView2.TabIndex = 35
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(971, 572)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.q6)
        Me.Controls.Add(Me.q5)
        Me.Controls.Add(Me.q4)
        Me.Controls.Add(Me.q3)
        Me.Controls.Add(Me.q2)
        Me.Controls.Add(Me.q1)
        Me.Controls.Add(Me.qm2)
        Me.Controls.Add(Me.qm1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btngo)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btninsert)
        Me.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btninsert As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btngo As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents qm2 As System.Windows.Forms.Button
    Friend WithEvents qm1 As System.Windows.Forms.Button
    Friend WithEvents q3 As System.Windows.Forms.Button
    Friend WithEvents q2 As System.Windows.Forms.Button
    Friend WithEvents q1 As System.Windows.Forms.Button
    Friend WithEvents q6 As System.Windows.Forms.Button
    Friend WithEvents q5 As System.Windows.Forms.Button
    Friend WithEvents q4 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
End Class
