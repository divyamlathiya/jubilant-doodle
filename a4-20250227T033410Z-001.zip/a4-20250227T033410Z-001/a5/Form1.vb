﻿Imports System.Data.SqlClient
Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\suhani\Desktop\a4-20250227T033410Z-001\a5\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("Connection Done")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        disdata1()
        disdata2()
    End Sub

    Sub clearcontrol()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ComboBox1.SelectedItem = Nothing
    End Sub

    Sub disdata1()
        Try
            cmd.CommandText = "select * from agent"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub disdata2()
        Try
            cmd.CommandText = "select * from policy"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView2_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView2.CellClick
        Try
            TextBox3.Text = DataGridView2.Rows(e.RowIndex).Cells(0).Value
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If TextBox3.Text = "" Then
                cmd.CommandText = "insert into agent values(" & TextBox1.Text & ", '" & TextBox2.Text & "', '" & ComboBox1.SelectedItem & "')"
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Data Inserted in Agent table.")
                disdata1()
                clearcontrol()
            Else
                cmd.CommandText = "insert into policy values(" & TextBox3.Text & ", " & TextBox1.Text & ", '" & TextBox4.Text & "', '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "',  '" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "', '" & TextBox5.Text & "')"
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Data Inserted in Policy table.")
                disdata2()
                clearcontrol()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            If TextBox3.Text = "" Then
                cmd.CommandText = "update agent set a_name = '" & TextBox2.Text & "', city = '" & ComboBox1.SelectedItem & "' where a_code = " & TextBox1.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Record is updated in agent table")
                disdata1()
                clearcontrol()
            Else
                cmd.CommandText = "update policy set a_code = " & TextBox1.Text & ", customer_name = '" & TextBox4.Text & "', s_date = '" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "', e_date = '" & DateTimePicker2.Value.ToString("yyyy-MM-dd") & "', p_amt = " & TextBox5.Text & " where p_no = " & TextBox3.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Record is updated in agent table")
                disdata2()
                clearcontrol()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            If TextBox3.Text = "" Then
                cmd.CommandText = "delete from agent where a_name = '" & TextBox2.Text & "'"
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Record is deleted from agent table.")
                disdata1()
                clearcontrol()
            Else
                cmd.CommandText = "delete from policy where p_no = " & TextBox3.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Record is deleted from policy table.")
                disdata2()
                clearcontrol()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            cmd.CommandText = "select p.p_no,a.a_code,p.customer_name from policy p join agent a on p.a_code = a.a_code order by p.customer_name ASC"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd) 'To fetch data
            da.Fill(dt)
            DataGridView3.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try
            cmd.CommandText = "select a.a_name,p.customer_name,p.p_amt from policy p join agent a on p.a_code = a.a_code order by a.a_name"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd) 'To fetch data
            da.Fill(dt)
            DataGridView4.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
