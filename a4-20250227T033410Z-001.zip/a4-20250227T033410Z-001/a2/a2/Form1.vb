﻿Imports System.Data.SqlClient

Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\suhani\Desktop\a4-20250227T033410Z-001\a2\a2\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("Database connected successfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
    End Sub

    Sub clearcontrol()
        TextBox1.Text = " "
        TextBox2.Text = " "
        TextBox3.Text = " "
        TextBox4.Text = " "
    End Sub

    Sub displaydata()
        Try
            cmd.CommandText = "Select * from item"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Open()
        cmd.Connection = con
        cmd.CommandText = "SELECT * FROM item where item_no = '" & TextBox1.Text & "'"

        Dim reader As SqlDataReader = cmd.ExecuteReader()

        If reader.Read() Then
            reader.Close()
            cmd.CommandText = "UPDATE item SET cost = '" & TextBox3.Text & "', qty = '" & TextBox4.Text & "', name = '" & TextBox2.Text & "' WHERE item_no = '" & TextBox1.Text & "'"
            cmd.ExecuteNonQuery()
            MessageBox.Show("Item updated successfully.")
        Else
            reader.Close()
            cmd.CommandText = "INSERT INTO item VALUES ('" & TextBox1.Text & "', '" & TextBox2.Text & "', '" & TextBox3.Text & "', '" & TextBox4.Text & "')"
            cmd.ExecuteNonQuery()
            MessageBox.Show("New item added successfully.")
        End If
        displaydata()
        con.Close()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "select * from item where qty = 0"
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim dt As New DataTable
            dt.Load(reader)
            DataGridView2.DataSource = dt
            reader.Close()
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            cmd.CommandText = "insert into item values ('" & TextBox1.Text & "', '" & TextBox2.Text & "', '" & TextBox3.Text & "', '" & TextBox4.Text & "') "
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("Data inserted")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            cmd.CommandText = "select * from item where name = '" & TextBox2.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView3.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        displaydata()
        clearcontrol()
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub
End Class
