import java.util.*;
public class p1
{
    public static void main(String[] args) 
	{
        Scanner s = new Scanner(System.in);
        int x,sum;
        System.out.print("enter x :");
        x = s.nextInt();
        System.out.print("enter y :");
        int y = s.nextInt();
        sum=x+y;
        System.out.println("sum is :"+sum);     
    }
}