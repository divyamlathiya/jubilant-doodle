interface direction 
{
    void setdirection(String direction);
}

interface drivecar 
{
    void drive();
    void stop();
}

class directionboard implements direction 
{
    private String currentdir;

    public void setdirection(String direction) 
    {
        currentdir = direction;
        System.out.println("directionBoard: direction set to " + direction);
    }
    
    public String getdirection() 
    {
        return currentdir;
    }
}

class Car implements direction, drivecar 
{
    private String direction;

    public void setdirection(String direction) 
    {
        this.direction = direction;
        System.out.println("Car: direction set to " + direction);
    }

    public void drive() 
    {
        System.out.println("Car is driving in the " + direction + " direction.");
    }

    public void stop() 
    {
        System.out.println("Car has stopped.");
    }
}

public class p19
{
    public static void main(String[] args) 
    {
        directionboard board = new directionboard();
        board.setdirection("North");

        Car car = new Car();
        car.setdirection("East");
        car.drive();
        car.stop();
    }
}
