import java.util.Scanner;

public class p14
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word = s.nextLine();
        String reversedWord = "";
        for (int i = word.length() - 1; i >= 0; i--) 
        {
            reversedWord = reversedWord + word.charAt(i);
        }
        System.out.println("Reversed Word: " + reversedWord);
    }
}


// import java.util.*;

// public class p14 
// {
//     public static void main(String[] args) 
//     {
//         Scanner scanner = new Scanner(System.in);
//         System.out.print("Enter a word: ");
//         String word = scanner.nextLine();
//         StringBuffer buffer = new StringBuffer(word);
//         buffer.reverse();
//         System.out.println("Reversed Word: " + buffer);
//         scanner.close();
//     }
// }
