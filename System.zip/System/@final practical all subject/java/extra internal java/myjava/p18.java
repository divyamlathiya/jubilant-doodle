import java.util.*;

class recangle 
{
    double hight;
    double weidth;
    
    recangle(double hight, double weidth)
    {
        this.hight = hight;
        this.weidth = weidth;
    }
    
    void area() 
    {
        double area = hight * weidth;
        System.out.println("recangale area is :"+area+"\n");
    }
}

class triangle 
{
    double base;
    double height;
    
    triangle(double base, double height) 
    {
        this.base = base;
        this.height = height;
    }
    
    void area() 
    {
        double area = 0.5 * base * height;
        System.out.println("triangle area is :"+area+"\n");
    }
}

public class p18 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        System.out.println("enter height :");
        double hight = s.nextDouble();

        System.out.println("enter weidth :");
        double weidth = s.nextDouble();

        recangle rec = new recangle(hight, weidth);

        rec.area();
        
        System.out.println("enter base :");
        double base = s.nextDouble();

        System.out.println("enter height :");
        double height = s.nextDouble();

        triangle tri = new triangle(base, height);
        
        tri.area();
      
    }
}
