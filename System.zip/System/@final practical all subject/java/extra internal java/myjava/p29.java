import java.util.*;

public class p29 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        String[] names = new String[10];
        
        System.out.println("Enter the names of 10 students:");
        for (int i = 0; i < 10; i++) 
        {
            names[i] = s.nextLine();
        }
        
        Arrays.sort(names);
        
        DisplayThread dt = new DisplayThread(names);
        dt.start();
        
    }
}

class DisplayThread extends Thread 
{
    String[] names;
    
    DisplayThread(String[] names) 
    {
        this.names = names;
    }
    
    public void run() 
    {
        for (String name : names) 
        {
            System.out.println(name);
            try 
            {
                Thread.sleep(1000);
            } 
            catch (InterruptedException e) 
            {
                System.out.println("Thread interrupted.");
            }
        }
    }
}
