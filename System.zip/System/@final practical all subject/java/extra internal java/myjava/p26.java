import java.util.*;

public class p26 {
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        System.out.print("first string: ");
        String s1 = s.nextLine();
        System.out.print("second string: ");
        String s2 = s.nextLine();

        StringBuffer merged = new StringBuffer();

        int maxlen = Math.max(s1.length(), s2.length());

        for (int i = 0; i < maxlen; i++) 
        {
            if (i < s1.length()) 
            {
                merged.append(s1.charAt(i));
            }
            if (i < s2.length()) 
            {
                merged.append(s2.charAt(i));
            }
        }

        System.out.println("merged string: " + merged);
    }
}
