public class p24 {
    public static void main(String[] args)
    {
        for (String arg : args) 
        {
            if (arg.startsWith("A") || arg.startsWith("a"))
                System.out.println(arg);
        }
    }
}

