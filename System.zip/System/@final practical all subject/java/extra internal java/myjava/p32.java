import java.util.*;

class Student 
{
    String name;
    int age;
    
    Student(String name, int age) 
    {
        this.name = name;
        this.age = age;
    }
}

class DisThread extends Thread 
{
    Student[] stud;

    DisThread(Student[] stud) 
    {
        this.stud = stud;
    }
    
    public void run() 
    {
        for (int i = 0; i < stud.length; i++) 
        {
            System.out.println("Name: " + stud[i].name + ", Age: " + stud[i].age);
            try 
            {
                Thread.sleep(1000);
            } catch (InterruptedException e) 
            {
               
            }
        }
    }
}

public class p32 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        Student[] stud = new Student[10];
        
        for (int i = 0; i < 10; i++) 
        {
            System.out.print("Enter student " + (i + 1) + " name: ");
            String name = s.nextLine();
            System.out.print("Enter student " + (i + 1) + " age: ");
            int age = s.nextInt();
            s.nextLine(); 
            stud[i] = new Student(name, age);
        }
        
        for (int i = 0; i < stud.length - 1; i++) 
        {
            for (int j = 0; j < stud.length - i - 1; j++) 
            {
                if (stud[j].name.compareTo(stud[j + 1].name) < 0 || (stud[j].name.compareTo(stud[j + 1].name) == 0 && stud[j].age < stud[j + 1].age)) 
                {
                    Student temp = stud[j];
                    stud[j] = stud[j + 1];
                    stud[j + 1] = temp;
                }
            }
        }
        
        DisThread dt = new DisThread(stud);
        dt.start();
    }
}
