import java.util.*;

public class p9 {
    public static void main(String [] args)
    {
        Scanner s = new Scanner(System.in);
        System.out.println("enter charecter : ");
        
        String ch = s.nextLine();
        char ch1 = ch.charAt(0);

        // char ch1=s.next().charAt(0);

        int p1 = (int) ch1;

        System.out.println("This is ascii value of charector : "+p1);
    } 
}

// import java.util.*;

// public class p9 {
//     public static void main(String [] args)
//     {
//         Scanner s = new Scanner(System.in);
//         System.out.println("enter String : ");

//         String ch1 = s.nextLine();
        
//         char[] arr1 = ch1.toCharArray();

//         for(int i=0;i<arr1.length;i++)
//         {
//             int p1 = (int) arr1[i];
//             System.out.println("This is ascii value of charector "+arr1[i]+":"+p1);
//         }   
//     } 
// }