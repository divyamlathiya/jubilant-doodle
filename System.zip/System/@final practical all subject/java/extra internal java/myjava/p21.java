class ie extends Exception 
{
    public ie(String message) 
    {
        super(message);
    }
}

public class p21 {
    public static void main(String[] args) 
    {
        String[] cource = {"BCA", "MCA", "BBA", "MBA", "OTHER"};

        if (args.length != 5) 
        {
            System.out.println("Please provide exactly 5 arguments.");
            return;
        }

        for (int j = 0; j < args.length; j++) 
        {
            String arg = args[j];
            boolean isValid = false;
            
            for (int i = 0; i < cource.length; i++) 
            {
                if (arg.equals(cource[i])) 
                {
                    isValid = true;
                    break;
                }
            }

            if (!isValid) 
            {
                try 
                {
                    throw new ie("Invalid argument: " + arg);
                } 
                catch (ie e) 
                {
                    System.out.println(e.getMessage());
                    return;
                }
            }
        }

        System.out.println("All arguments are valid.");
    }
}

