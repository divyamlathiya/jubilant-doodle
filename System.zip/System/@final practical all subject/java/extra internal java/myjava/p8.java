import java.util.*;
public class p8 
{
    public static void main(String [] args)
    {
        Scanner s = new Scanner(System.in);
        
        System.out.println("Enter the string : ");
        String str = s.nextLine();

        int null_counter=0,Number_counter=0,latter_counter=0,special_char=0;

        for(int i=0;i<str.length();i++)
        {
            char p = str.charAt(i);
            
            if (p >= '0' && p<='9') 
            {
                Number_counter++;
            }

            else if(p==' ')
            {
                null_counter++;
            }
            else if(p>='A' && p<='Z' || p>='a' && p<='z')
            {
                latter_counter++;
            }
            else if(!(p >= '0' && p<='9' || p>='A' && p<='Z' || p>='a' && p<='z'))
            {
                special_char++;
            }
               
            // if (Character.isDigit(p)) 
            // {
            //     Number_counter++;
            // }
            // else if(Character.isWhitespace(p))
            // {
            //     null_counter++;
            // }
            // else if(Character.isLetter(p))
            // {
            //     latter_counter++;
            // }
            // else if(!(Character.isWhitespace(p) || Character.isLetterOrDigit(p)))
            // {
            //     special_char++;
            // }
        }
        if(null_counter >0)
        {
            System.out.println("Null : "+null_counter);  
        }
        if(Number_counter >0)
        {
            System.out.println("Number : "+Number_counter);
        }
        if(latter_counter >0)
        {
            System.out.println("Latter : "+latter_counter);  
        }
        if(special_char >0)
        {
            System.out.println("Special char : "+special_char);
        }      
    }     
}     

