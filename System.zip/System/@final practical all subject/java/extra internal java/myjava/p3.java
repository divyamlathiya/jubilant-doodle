import java.util.Scanner;
public class p3 
{
    public static void main(String[] args) 
	{
        Scanner s =new Scanner(System.in);
        int c,n1,n2,result;
        System.out.println("1.sum");
        System.out.println("2.sub");
        System.out.println("3.mul");
        System.out.println("4.div");
        System.out.println("5.rem");
        System.out.println("enter choice:");
        c=s.nextInt();
        switch (c) 
		{
            case 1:
                System.out.println("enter number 1:");
                n1=s.nextInt();
                System.out.println("enter number 2:");
                n2=s.nextInt();
                result=n1+n2;
                System.out.println("the sum is : "+result);
                break;
            case 2:
                System.out.println("enter number 1:");
                n1=s.nextInt();
                System.out.println("enter number 2:");
                n2=s.nextInt();
                result=n1-n2;
                System.out.println("the sub is : "+result);
                break;
            case 3:
                System.out.println("enter number 1:");
                n1=s.nextInt();
                System.out.println("enter number 2:");
                n2=s.nextInt();
                result=n1*n2;
                System.out.println("the mul is : "+result);
                break;
            case 4:
                System.out.println("enter number 1:");
                n1=s.nextInt();
                System.out.println("enter number 2:");
                n2=s.nextInt();
                result=n1/n2;
                System.out.println("the div is : "+result);
                break;
            case 5:
                System.out.println("enter number 1:");
                n1=s.nextInt();
                System.out.println("enter number 2:");
                n2=s.nextInt();
                result=n1%n2;
                System.out.println("the remainder is : "+result);
                break;
            default:
                System.out.println("invalid choice.");
                break;
        }
    }
}
