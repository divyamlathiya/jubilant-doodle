class print implements Runnable 
{
    private String message;
    private int interval;

    public print(String message, int interval) 
    {
        this.message = message;
        this.interval = interval;
    }

    public void run() 
    {
        while (true) 
        {
            System.out.println(message);
            try 
            {
                Thread.sleep(interval);
            } 
            catch (InterruptedException e) 
            {
                System.out.println("thread is: " + message);
                break;
            }
        }
    }
}

public class p28
{
    public static void main(String[] args) 
    {
        Thread thread1 = new Thread(new print("JAVA", 1000));
        Thread thread2 = new Thread(new print("PAPER", 2000));
        Thread thread3 = new Thread(new print("COLLEGE", 3000));

        thread1.start();
        thread2.start();
        thread3.start();
    }
}
