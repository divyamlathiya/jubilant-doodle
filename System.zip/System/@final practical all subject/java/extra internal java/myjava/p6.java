import java.util.*;

public class p6 
{
    public static void main(String [] args)
    {
        Scanner s = new Scanner(System.in);
        System.out.println("enter string :");   
        String str1 = s.nextLine();
        StringBuffer str = new StringBuffer(str1);
        System.out.println("Before Reverse : "+str);
        str.reverse();
        System.out.println("After Reverse : "+str);

    }
}
