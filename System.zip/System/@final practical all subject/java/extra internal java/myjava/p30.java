class p30 extends Thread {
    public void run() {
        System.out.println("Thread: " + getName());
        System.out.println("Priority: " + getPriority());
    }

    public static void main(String[] args) 
    {
        p30 t1 = new p30();
        p30 t2 = new p30();
        p30 t3 = new p30();

        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.NORM_PRIORITY);
        t3.setPriority(Thread.MAX_PRIORITY);

        t1.start();
        t2.start();
        t3.start();
    }
}
