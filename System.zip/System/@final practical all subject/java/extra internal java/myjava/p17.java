public class p17 
{
    
    public static int add(int a, int b) 
    {
        return a + b;
    }
    
    public static double add(double a, double b) 
    {
        return a + b;
    }
    
    public static void main(String[] args) 
    {
        int sum1 = add(10, 20);
        double sum2 = add(12.5, 7.3);
        
        System.out.println("Sum of integers: " + sum1);
        System.out.println("Sum of doubles: " + sum2);
    }
}
