import java.time.LocalDateTime;
public class p11 
{
    public static void main(String[] args){
        System.out.println("Time Is :"+ LocalDateTime.now());
    }    
}
