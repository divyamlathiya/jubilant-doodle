import stores.stock;

public class p27 extends stock {
    public int qtySold;

    public p27(int itemNo, String itemName, int stockAvailable, double cost, int qtySold) {
        super(itemNo, itemName, stockAvailable, cost);
        this.qtySold = qtySold;
    }

    public void displaySales() {
        int currentStock = stockAvailable - qtySold;
        System.out.println("Current stock for item " + itemNo + " (" + itemName + ") is: " + currentStock);
    }

    public static void main(String[] args) {
        p27 s1 = new p27(101, "Pen", 100, 10.0, 30);
        p27 s2 = new p27(102, "Notebook", 50, 20.0, 10);

        s1.displaySales();
        s2.displaySales();

        int totalCurrentStock = (s1.stockAvailable - s1.qtySold) + (s2.stockAvailable - s2.qtySold);
        System.out.println("Total current stock of all items: " + totalCurrentStock);
    }
}
