package stores;

public class stock {
    public int itemNo;
    public String itemName;
    public int stockAvailable;
    public double cost;

    public stock(int itemNo, String itemName, int stockAvailable, double cost) {
        this.itemNo = itemNo;
        this.itemName = itemName;
        this.stockAvailable = stockAvailable;
        this.cost = cost;
    }

    public void displayStock() {
        System.out.println("Item No: " + itemNo);
        System.out.println("Item Name: " + itemName);
        System.out.println("Stock Available: " + stockAvailable);
        System.out.println("Cost: " + cost);
    }
}
