import java.text.SimpleDateFormat;
import java.util.Date;

public class p31 extends Thread 
{
    public void run() 
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int i=0;
        while (i<=10) 
        {
            Date now = new Date();
            System.out.println("Date and Time: " + sdf.format(now));
            try 
            {
                Thread.sleep(1000);
            } 
            catch (InterruptedException e) 
            {
                break;
            }
            i++;
        }
    }
    
    public static void main(String[] args) 
    {
        p31 dt = new p31();
        dt.start();
    }
}
