import java.util.*;

class bankacc 
{
    String accholder;
    String accnumber;
    double balance;

    public bankacc(String accholder, String accnumber, double balance) 
    {
        this.accholder = accholder;
        this.accnumber = accnumber;
        this.balance = balance;
    }

    public void deposit(double amount) 
    {
        balance += amount;
    }

    public void display() 
    {
        System.out.println("Name: " + accholder);
        System.out.println("Account Number: " + accnumber);
        System.out.println("Balance: " + balance);
    }
}

class savingacc extends bankacc 
{
    double interestrate;

    public savingacc(String accholder, String accnumber, double balance, double interestrate) 
    {
        super(accholder, accnumber, balance);
        this.interestrate = interestrate;
    }

    public void display() 
    {
        super.display();
        System.out.println("Account Type: Saving Account");
        System.out.println("Interest Rate: " + interestrate + "%");
    }

    public void addInterest() 
    {
        double interest = balance * interestrate / 100;
        balance += interest;
        System.out.println("Interest of " + interest + " added to balance.");
    }
}

class currentacc extends bankacc 
{
    double overdraftlimit;

    public currentacc(String accholder, String accnumber, double balance, double overdraftlimit) 
    {
        super(accholder, accnumber, balance);
        this.overdraftlimit = overdraftlimit;
    }

    public void display() 
    {
        super.display();
        System.out.println("Account Type: Current Account");
        System.out.println("Overdraft Limit: " + overdraftlimit);
    }
}

public class p16 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter account holder name: ");
        String name = s.nextLine();

        System.out.print("Enter account number: ");
        String number = s.nextLine();

        System.out.print("Enter initial balance: ");
        double balance = s.nextDouble();

        System.out.println("Select account type:");
        System.out.println("1. Saving Account");
        System.out.println("2. Current Account");
        int choice = s.nextInt();

        if (choice == 1) 
        {
            System.out.print("Enter interest rate: ");
            double rate = s.nextDouble();
            savingacc sa = new savingacc(name, number, balance, rate);
            sa.display();
            sa.addInterest();
            System.out.println("After adding interest:");
            sa.display();
        } 
        else if (choice == 2) 
        {
            System.out.print("Enter overdraft limit: ");
            double limit = s.nextDouble();
            currentacc ca = new currentacc(name, number, balance, limit);
            ca.display();
        } 
        else 
        {
            System.out.println("Invalid option.");
        }
    }
}
