import java.util.*;

class NAE extends Exception 
{
    public NAE(String message) 
    {
        super(message);
    }
}

public class p23 
{
    public static void no(int num) throws NAE 
    {
        if (num < 0) 
        {
            throw new NAE("Error: Negative number provided - " + num);
        }
        System.out.println("Number is valid: " + num);
    }

    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = s.nextInt();

        try 
        {
            no(num);
        } 
        catch (NAE e) 
        {
            System.out.println("error: " + e.getMessage());
        }
    }
}
