interface A 
{
    void method1();
    void method2();
}

interface B extends A 
{
    void method3();
}

abstract class PartialImpl implements B 
{
    public void method1() 
    {
        System.out.println("Method1 implemented in PartialImpl");
    }
}

class ConcreteImpl extends PartialImpl 
{
    public void method2() 
    {
        System.out.println("Method2 implemented in ConcreteImpl");
    }
    
    public void method3() 
    {
        System.out.println("Method3 implemented in ConcreteImpl");
    }
}

public class p20
 {
    public static void main(String[] args) 
    {
        ConcreteImpl obj = new ConcreteImpl();
        obj.method1();
        obj.method2();
        obj.method3();
    }
}
