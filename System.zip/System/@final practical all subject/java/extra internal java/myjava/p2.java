import java.util.*;

public class p2 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n1;
        System.out.println("Enter number:");
        n1=s.nextInt();
        if(n1 % 2 == 0)
        {
            System.out.println(1);
        }
        else{
            System.out.println(0);
        }
    }
}
