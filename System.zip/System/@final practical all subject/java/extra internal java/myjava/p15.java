import java.util.*;

public class p15 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        System.out.print("string: ");
        String str = s.nextLine();
        
        System.out.println("\nChoose an option:");
        System.out.println("1. UPPERCASE");
        System.out.println("2. lowercase");
        System.out.println("3. Sentence case");
        System.out.println("4. Toggle CASE");
        System.out.print("choice : ");

        int choice = s.nextInt();
        s.nextLine();

        String result = "";
        if (choice == 1) 
        {
            result = str.toUpperCase();
        }
        else if (choice == 2) 
        {
            result = str.toLowerCase();
        } 
        else if (choice == 3) 
        {
            if (str.length() > 0) 
            {
                result = str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
            } 
            else 
            {
                result = str;
            }

        } 
        else if (choice == 4) 
        {
            StringBuffer toggled = new StringBuffer();
            for (int i = 0; i < str.length(); i++)
            {
                char c = str.charAt(i);
                if (Character.isUpperCase(c)) 
                {
                    toggled.append(Character.toLowerCase(c));
                } 
                else if (Character.isLowerCase(c)) 
                {
                    toggled.append(Character.toUpperCase(c));
                }
                else 
                {
                    toggled.append(c);
                }
            }
            result = toggled.toString();
        } 
        else 
        {
            System.out.println("Invalid choice.");
            
        }
        System.out.println("\nResult: " + result);
    }
}
