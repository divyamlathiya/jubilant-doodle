import java.util.*;

public class p22 
{

    public static void no() throws Exception 
    {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = s.nextInt();

        if (num >= 0) 
        {
            System.out.println("Number is valid: " + num);
        } 
        else 
        {
            throw new Exception("Error: Negative number provided - " + num);
        }
    }

    public static void main(String[] args) 
    {
        try 
        {
            no();
        } 
        catch (Exception e) 
        {
            System.out.println("eroor: " + e.getMessage());
        }
    }
}
