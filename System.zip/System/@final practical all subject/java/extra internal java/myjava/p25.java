import java.util.*;

public class p25
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        System.out.print("first string: ");
        String s1 = s.nextLine();
        System.out.print("second string: ");
        String s2 = s.nextLine();

        char[] arr1 = s1.toCharArray();
        char[] arr2 = s2.toCharArray();

        for (int i = 0; i < arr1.length; i++) 
        {
            for (int j = 0; j < arr2.length; j++) 
            {
                if (arr1[i] == arr2[j]) 
                {
                    arr1[i] = '*';
                    arr2[j] = '*';
                }
            }
        }

        System.out.println("Modified first string: " + new String(arr1));
        System.out.println("Modified second string: " + new String(arr2));
    }
}
