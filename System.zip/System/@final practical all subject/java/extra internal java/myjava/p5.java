import java.util.*;
public class p5 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter number : ");
        int n1 = s.nextInt();
        int sum=0;
        while(n1!=0)
        {       
        sum=sum+n1%10;
        n1=n1/10;}
        if(sum==7)
        {
            System.out.println("yes sum is :"+sum);
        }
        else
        {
            System.out.println("no this isn't");
        }
    }
}
