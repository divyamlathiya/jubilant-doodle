import java.util.*;

public class p13
{
    public static void main(String[] args)
     {
        int[] numbers = {20, 30, 40};

        System.out.println("Array: " + Arrays.toString(numbers));

        int first = numbers[0];
        int last = numbers[numbers.length - 1];
        int larger = (first > last) ? first : last;
        System.out.println("Larger element: " + larger);
    }
}
