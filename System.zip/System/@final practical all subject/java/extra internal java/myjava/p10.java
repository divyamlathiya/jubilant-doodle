import java.util.*;
public class p10 {
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        System.out.println("enter the string : ");

        String s1=s.nextLine();

        String[] arr1 = s1.split(" ");  

        StringBuffer n1 = new StringBuffer();

        for(int i=0; i<arr1.length;i++)
        {
            StringBuffer p1 = new StringBuffer(arr1[i]);
            char c1 = p1.charAt(0);
            char c2 = Character.toUpperCase(c1);
            p1.setCharAt(0, c2);
            
            n1.append(p1).append(" ");
            
        }
        System.out.println(n1); 
    }
}
