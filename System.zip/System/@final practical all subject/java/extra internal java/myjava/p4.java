import java.util.*;
public class p4 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n1,i,total=0;
        System.out.println("Enter number foe sum :");
        n1 = s.nextInt();
        String str = Integer.toString(n1);
        for(i=0;i<str.length();i++)
        {
            total+=str.charAt(i)-'0';
        }
        System.out.println("the total is :"+total);
    }
}
// import java.util.*;

// public class p4{
//     public static void main(String[] args) {
//         Scanner sc = new Scanner(System.in);

//         System.out.print("Input an integer: ");
//         int num = sc.nextInt();

//         // Convert number to string to process digits as an array
//         String numStr = Integer.toString(num);
//         char[] digits = numStr.toCharArray();  // Convert number to char array
//         System.out.println(Arrays.toString(digits));
//         int sum = 0;
//         int digit;
        
//         // Convert char to int by subtracting '0' outside of the loop
//         for (int i = 0; i < digits.length; i+=1) {
//              digit = digits[i] - '0';  // Convert char to int by subtracting '0'
//             sum += digit;  // Add the digit to sum
//         }
    
//         System.out.println("The sum of the digits is: " + sum);

//         sc.close();
//     }
// }
