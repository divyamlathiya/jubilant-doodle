import java.util.*;

public class p12 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);

        System.out.print("Total number of employees: ");
        int n = s.nextInt();
        s.nextLine(); 

        String[] empId = new String[n];
        String[] empName = new String[n];
        double[] salary = new double[n];
        String[] department = new String[n];

        for (int i = 0; i < n; i++) 
        {
            System.out.println("\ndetails for employee " + (i + 1) + ":");
            
            System.out.print("ID: ");
            empId[i] = s.nextLine();
            
            System.out.print("Name: ");
            empName[i] = s.nextLine();
            
            System.out.print("Salary: ");
            salary[i] = s.nextDouble();
            s.nextLine();
            
            System.out.print("Department: ");
            department[i] = s.nextLine();
        }
        
        System.out.println("\nEmployee Details:");
        System.out.println("--------------------------------------------------------------");
        System.out.println("Employee ID\tEmployee Name\tSalary\t\tDepartment");
        System.out.println("-----------------------------------------------------------");

        for (int i = 0; i < n; i++) 
        {
            System.out.println(empId[i] + "\t\t" + empName[i] + "\t\t" + salary[i] + "\t\t" + department[i]);
        }
    }
}
