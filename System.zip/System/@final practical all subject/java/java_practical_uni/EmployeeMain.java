//1. employee
/* (A) Create class EMPLOYEE in java with id, name and salary as data- members. 
	Again create 5 different employee objects by taking input from user. 
	Display all the information of an employee which is having maximum salary.
 */
import java.util.Scanner;

class Employee {
    int id;
    String name;
    double salary;
}

public class EmployeeMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Employee[] emp = new Employee[5];

        // Taking input for 5 employees
        for (int i = 0; i < 5; i++) {
            emp[i] = new Employee();
            System.out.println("Enter Employee " + (i + 1) + " details:");
            System.out.print("ID: ");
            emp[i].id = sc.nextInt();
            sc.nextLine(); // Consume newline
            System.out.print("Name: ");
            emp[i].name = sc.nextLine();
            System.out.print("Salary: ");
            emp[i].salary = sc.nextDouble();
        }

        // Finding maximum salary
        double maxSalary = emp[0].salary;
        for (int i = 1; i < 5; i++) {
            if (emp[i].salary > maxSalary) {
                maxSalary = emp[i].salary;
            }
        }

        // Displaying employees with the maximum salary
        System.out.println("\nEmployees with the Highest Salary:");
        for (int i = 0; i < 5; i++) {
            if (emp[i].salary == maxSalary) {
                System.out.println("ID: " + emp[i].id);
                System.out.println("Name: " + emp[i].name);
                System.out.println("Salary: " + emp[i].salary);
                System.out.println("----------------------");
            }
        }

        sc.close();
    }
}



