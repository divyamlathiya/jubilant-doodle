//2. student
/* (A) Create STUDENT class having data members roll no and name. Create 5 objects of 
	STUDENT class and take input from the user and print all students' data in ascending 
	order of name with interval of 1 second.
 */
import java.util.Scanner;

class STUDENT {
    int rollNo;
    String name;
}

public class StudentMain {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        STUDENT[] students = new STUDENT[5];

        // Taking input for 5 students
        for (int i = 0; i < 5; i++) {
            students[i] = new STUDENT();
            System.out.print("Enter Roll No: ");
            students[i].rollNo = sc.nextInt();
            sc.nextLine(); // Consume newline
            System.out.print("Enter Name: ");
            students[i].name = sc.nextLine();
        }

        // Bubble Sort (simplified)
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4 - i; j++) {
                if (students[j].name.compareTo(students[j + 1].name) > 0) {
                    STUDENT temp = students[j];
                    students[j] = students[j + 1];
                    students[j + 1] = temp;
                }
            }
        }

        // Display sorted students with delay
        System.out.println("\nSorted Student List:");
        for (int i = 0; i < 5; i++) {
            System.out.println("Roll No: " + students[i].rollNo);
            System.out.println("Name: " + students[i].name);
            Thread.sleep(1000); // 1-second delay
        }

        sc.close();
    }
}