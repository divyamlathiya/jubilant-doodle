//6. userexception
/* (A) Write a Java code that handles the custom exception like when a user gives input 
	as Floating point number then it raises exception with appropriate message.
 */
import java.util.Scanner;

// Custom Exception Class
class FloatingPointException extends Exception {
    public FloatingPointException(String message) {
        super(message);
    }
}

public class userexception {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            System.out.print("Enter an integer: ");
            String input = sc.next(); // Read input as string
            
            // Check if input contains a decimal point
            if (input.contains(".")) {
                throw new FloatingPointException("Error: Floating point number is not allowed!");
            }

            int number = Integer.parseInt(input); // Convert to integer
            System.out.println("Valid integer entered: " + number);

        } catch (FloatingPointException e) {
            System.out.println(e.getMessage()); // Print custom error message
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid input! Please enter an integer.");
        } finally {
            sc.close(); // Close Scanner
        }
    }
}
