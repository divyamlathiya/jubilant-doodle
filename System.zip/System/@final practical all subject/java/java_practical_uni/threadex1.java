//14. thread
/* (A) Write an application that execute two Threads. One thread display "BCA" every 1000 
	milliseconds and the order displays "MCA" every 3000 milliseconds. 
	Create the threads by extending the thread class.
 */
class BCAThread extends Thread {
    public void run() {
        try {
            while (true) {
                System.out.println("BCA");
                Thread.sleep(1000); // Sleep for 1 second
            }
        } catch (InterruptedException e) {
            System.out.println("BCA Thread Interrupted");
        }
    }
}

class MCAThread extends Thread {
    public void run() {
        try {
            while (true) {
                System.out.println("MCA");
                Thread.sleep(3000); // Sleep for 3 seconds
            }
        } catch (InterruptedException e) {
            System.out.println("MCA Thread Interrupted");
        }
    }
}

public class threadex1 {
    public static void main(String[] args) {
        BCAThread t1 = new BCAThread();
        MCAThread t2 = new MCAThread();

        t1.start();
        t2.start();
    }
}
