//13.string
/* (A) Write a java program to enter strings at command line input and then sort strings 
	into ascending order.
 */
import java.util.Arrays;

public class sstring {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please enter strings as command-line arguments.");
            return;
        }

        // Sort the strings in ascending order
        Arrays.sort(args);

        // Display sorted strings
        System.out.println("Sorted Strings:");
        for (String str : args) {
            System.out.println(str);
        }
    }
}
