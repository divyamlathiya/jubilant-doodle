//5. thread
/* (A) Write an application that creates and start three threads, each thread is 
	instantiated from the same class. It executes a loop with 5 iterations. 
	First thread display "BEST", second thread display "OF" and last thread display "LUCK".
	All threads sleep for 1000 ms. The application waits for all threads to complete and 
	display a message..
 */
class MyThread extends Thread {
    private String word;

    // Constructor to assign word
    public MyThread(String word) {
        this.word = word;
    }

    public void run() {
        for (int i = 0; i < 5; i++) { // Loop 5 times
            System.out.println(word);
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class threadex {
    public static void main(String[] args) {
        // Creating threads
        MyThread t1 = new MyThread("BEST");
        MyThread t2 = new MyThread("OF");
        MyThread t3 = new MyThread("LUCK");

        // Starting threads
        t1.start();
        t2.start();
        t3.start();

        // Waiting for threads to complete
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        // Final message after all threads finish
        System.out.println("All threads finished execution!");
    }
}
