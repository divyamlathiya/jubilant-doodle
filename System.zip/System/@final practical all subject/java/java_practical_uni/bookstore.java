//17. thread interval
/* (A) Write a program that accept Book information like Title, Author, Publication and 
	Price for the N book from the user and display books in descending order 
	with interval of 1 second using thread. */

import java.util.*;

class Book 
{
    String title, author, publication;
    double price;

    public Book(String t, String a, String p, double pr) 
	{
        title = t;
        author = a;
        publication = p;
        price = pr;
    }

    public void show() 
	{
        System.out.println("Title: " + title + ", Author: " + author + ", Publication: " + publication + ", Price: " + price);
    }
}

class BookThread extends Thread 
{
    Book books[];
    int n;

    public BookThread(Book b[], int size) 
	{
        books = b;
        n = size;
    }

    public void run() 
	{
        for (int i = 0; i < n; i++) 
		{
            books[i].show();
            try 
			{
                Thread.sleep(1000); // Pause for 1 second
            } 
			catch (InterruptedException e) 
			{
                System.out.println("Error!");
            }
        }
    }
}

class bookstore 
{
    public static void main(String args[]) 
	{
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of books: ");
        int n = sc.nextInt();
        sc.nextLine(); // Consume newline

        Book books[] = new Book[n];

        for (int i = 0; i < n; i++) 
		{
            System.out.println("Enter book " + (i + 1) + " details:");
			
            System.out.print("Title: ");
            String title = sc.nextLine();
			
            System.out.print("Author: ");
            String author = sc.nextLine();
			
            System.out.print("Publication: ");
            String publication = sc.nextLine();
			
            System.out.print("Price: ");
            double price = sc.nextDouble();
			
            sc.nextLine(); // Consume newline

            books[i] = new Book(title, author, publication, price);
        }

        // Sorting books in descending order of price
        for (int i = 0; i < n - 1; i++) 
		{
            for (int j = i + 1; j < n; j++) 
			{
                if (books[i].price < books[j].price) 
				{
                    Book temp = books[i];
                    books[i] = books[j];
                    books[j] = temp;
                }
            }
        }

        // Start thread to display books one by one
        BookThread bt = new BookThread(books, n);
        bt.start();
    }
}