//17. thread interval
/* (A) Write a program that accept Book information like Title, Author, Publication
	and Price for the N book from the user and display books in descending order 
	with interval of 1 second using thread. */

import java.util.*;

class book
{
	String title,author,publication;
	double price;
	
	public book(String t, String a, String p, double pr)
	{
		title = t;
		author= a;
		publication = p;
		price = pr;
	}
	
	public void show()
	{
		System.out.println(" Title : " + title + "\n Author : "+author+"\n Publication : "+publication+"\n Price : "+price);
		System.out.println();
	}
}

class bookthread extends Thread
{
	book books[];//book is class name and books is array name
	int n;
	
	public bookthread(book b[],int size)
	{
		books = b;
		n=size;
	}
	
	public void run()
	{
		for(int i=0;i<n;i++)
		{
			books[i].show();
			try
			{
				Thread.sleep(1000);//puse for 1 second
			}
			catch(InterruptedException e)
			{
				System.out.println("Error : ");
			}
		}
	}
}

public class p17
{
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter how many book data store hear : ");
		int n = s.nextInt();
		s.nextLine(); //it's important for new line
		
		book[] books = new book[n];//array size is n 
		
		for (int i = 0; i < n; i++)
		{
			System.out.println("book"+(i+1)+"details is : ");
			
			System.out.println("Enter Title : ");
			String title = s.nextLine();
			
			System.out.println("Enter Author : ");
			String author = s.nextLine();
			
			System.out.println("Enter Publication : ");
			String publication = s.nextLine();
			
			System.out.println("Enter Price : ");
			double price = s.nextDouble();
			
			s.nextLine();//important for proper get input asking
			System.out.println();//new line
			
			books[i] = new book(title,author,publication,price); // in sigle slot call cunstructor with add data in array
			
			book b = new book(title,author,publication,price);//call custroctur with parameter
			books[i] = b;//add data in array
		}
		
		System.out.println();
		
		//sort data desending
		for(int i=0;i<n-1;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(books[i].price < books[i].price)
				{
					book temp = books[i];
					books[i] = books[j];
					books[j] = temp;
				}
			}
		}
		
		//display thread with interval of 1 second
		bookthread b = new bookthread(books, n);
		b.start();
		
		//display data
		for(int i=0;i<n;i++)
		{
			System.out.println("Book no. "+(i+1)+" : ");
			System.out.println("Title : " + books[i].title);
			System.out.println("Author : " + books[i].author);
			System.out.println("Publication : " + books[i].publication);
			System.out.println("Price : " + books[i].price);
			System.out.println();
		}
		
		//display data call show methods
		for(int i=0;i<n;i++)
		{
			books[i].show();
		}
		
	}
}