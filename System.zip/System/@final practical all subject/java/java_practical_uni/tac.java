//8. triangle
/* (A) Write a Java program that prompts the user to input the base and height of a 
	triangle. Accordingly calculates and displays the area of a triangle using the 
	formula (base* height)/2, and handles any input errors such as non-numeric inputs 
	or negative values for base or height. Additionally, include error messages for 
	invalid input and provide the user with the option to input another set of values or 
	exit the program.
 */
import java.util.Scanner;

public class tac {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        while (true) {
            try {
                // Input base
                System.out.print("Enter base of the triangle: ");
                double base = sc.nextDouble();
                
                // Input height
                System.out.print("Enter height of the triangle: ");
                double height = sc.nextDouble();
                
                // Check for negative values
                if (base <= 0 || height <= 0) {
                    System.out.println("Error: Base and height must be positive numbers!");
                    continue; // Ask again
                }

                // Calculate area
                double area = (base * height) / 2;
                System.out.println("Area of the triangle: " + area);
                
            } catch (Exception e) {
                System.out.println("Error: Invalid input! Please enter numeric values.");
                sc.next(); // Clear the invalid input
                continue; // Ask again
            }

            // Ask user if they want to try again
            System.out.print("Do you want to calculate again? (yes/no): ");
            String choice = sc.next().toLowerCase();
            if (!choice.equals("yes")) {
                System.out.println("Program exited.");
                break; // Exit loop
            }
        }
        
        sc.close();
    }
}
