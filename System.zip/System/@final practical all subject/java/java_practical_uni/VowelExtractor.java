//3. vowel
/* (A) Write a Java Program that accepts string data. Extract either All Vowels or All 
	Non-Vowels from given Data According to Options Selection. Also Provide an Option to 
	Display Output in Uppercase or Lowercase.
 */
import java.util.Scanner;

public class VowelExtractor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input: String data
        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        // Option: Extract vowels or non-vowels
        System.out.println("1 - Extract Vowels");
        System.out.println("2 - Extract Non-Vowels");
        int choice = sc.nextInt();
        sc.nextLine(); // Consume newline

        // Option: Output format (Uppercase or Lowercase)
        System.out.println("1 - Uppercase");
        System.out.println("2 - Lowercase");
        int format = sc.nextInt();
        sc.nextLine(); // Consume newline

        String result = "";

        // Extract Vowels or Non-Vowels
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            boolean isVowel = "AEIOUaeiou".indexOf(ch) != -1;

            if ((choice == 1 && isVowel) || (choice == 2 && !isVowel)) {
                result += ch;
            }
        }

        // Convert output to uppercase or lowercase
         if (format == 1) {
            result = result.toUpperCase();
        } else {
            result = result.toLowerCase();
        }

        // Output result
        System.out.println("Result: " + result);
        sc.close();
    }
}
