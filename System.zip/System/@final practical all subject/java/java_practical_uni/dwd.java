//7. dwd cmdargs
/* (A) Write a java program that accepts string from command line and display each 
	character in capital at the delay of one second.
 */
public class dwd{
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please enter a string as a command-line argument.");
            return;
        }

        String input = args[0].toUpperCase(); // Convert to uppercase

        for (char ch : input.toCharArray()) {
            System.out.print(ch + " "); // Print character with space
            try {
                Thread.sleep(1000); // Delay of 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}
