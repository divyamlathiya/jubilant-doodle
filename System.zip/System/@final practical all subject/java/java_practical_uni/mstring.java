/* 11. string
(A) Write a java application which accepts two strings. 
	Merge both the strings using alternate characters of each one.
	For example: If String1 is: "Very", and String2 is: "Good",
	Then result should be: "VGeoroyd".
 */
import java.util.Scanner;

public class mstring {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input two strings
        System.out.print("Enter first string: ");
        String str1 = sc.next();
        System.out.print("Enter second string: ");
        String str2 = sc.next();

        // Merge strings using StringBuffer
        StringBuffer result = new StringBuffer();
        int len1 = str1.length(), len2 = str2.length();
        int i = 0, j = 0;

        while (i < len1 || j < len2) {
            if (i < len1) {
				result.append(str1.charAt(i++));
			}
            if (j < len2) {
				result.append(str2.charAt(j++));
			}
        }

        // Output the merged string
        System.out.println("Merged String: " + result);

        sc.close();
    }
}
