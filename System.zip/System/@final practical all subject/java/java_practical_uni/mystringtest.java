/* 9. string
(A) Write a java program to design a class Mystring having data member of type String add 
	member function to achieve following task.
	i. Reverse String
	11. String in tOGGLECASE
	111. Sentence case
	iv. Extract N-Characters from right-end of the string
	Write a menu driven program to call these methods Mystring Class. 
	The program must use Exception handling.

(A) Write a Java Program that Accepts String Data from User and then Provide options 
	for Changing case into Any of the Following. (UPPERCASE, lowercase, Sentence case, 
	tOGGLE CASE).
 */
import java.util.Scanner;

class MyString {
    StringBuffer str;

    MyString(String input) {
        str = new StringBuffer(input);
    }

    void reverseString() {
        System.out.println("Reversed: " + str.reverse());
    }

    void toggleCase() {
        StringBuffer result = new StringBuffer();
        for (char ch : str.toString().toCharArray()) {
            if (Character.isUpperCase(ch))
                result.append(Character.toLowerCase(ch));
            else
                result.append(Character.toUpperCase(ch));
        }
        System.out.println("Toggle Case: " + result);
    }

    void sentenceCase() {
        String s = str.toString().toLowerCase();
        System.out.println("Sentence Case: " + Character.toUpperCase(s.charAt(0)) + s.substring(1));
    }

    void extractRight(int n) {
        if (n > str.length() || n < 0)
            System.out.println("Invalid input!");
        else
            System.out.println("Extracted: " + str.substring(str.length() - n));
    }
}

public class mystringtest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        MyString myStr = new MyString(sc.nextLine());

        while (true) {
            System.out.println("\n1. Reverse\n2. Toggle Case\n3. Sentence Case\n4. Extract Right\n5. Exit");
            System.out.print("Choice: ");
            int choice = sc.nextInt();
            if (choice == 5) break;

            switch (choice) {
                case 1:
                    myStr.reverseString();
                    break;
                case 2:
                    myStr.toggleCase();
                    break;
                case 3:
                    myStr.sentenceCase();
                    break;
                case 4:
                    System.out.print("Enter number of characters: ");
                    myStr.extractRight(sc.nextInt());
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
        sc.close();
    }
}
