//4. cmdargs
/* (A) Write a Java program to display string with capital letters which are inputted 
	through command line. Display those string(s) which starts with "B". */

public class cmdargs {
    public static void main(String[] args) {
        // Check if no arguments are provided
        if (args.length == 0) {
            System.out.println("Please enter strings as command-line arguments.");
        } else {
            System.out.println("Strings starting with 'B':");

            // Loop through command-line arguments
            for (String str : args) {
                if (str.toUpperCase().startsWith("B")) { // Check if it starts with 'B'
                    System.out.println(str.toUpperCase()); // Convert to uppercase and print
                }
            }
        }
    }
}


// using input user also add functionality

import java.util.scanner;

public class cmdargs {
    public static void main(String[] args) {
        String[] words; // Array to store strings

        // If no command-line arguments are given
        if (args.length == 0) {
            Scanner sc = new Scanner(System.in);
            System.out.print("No command-line arguments found.\nHow many strings do you want to enter? ");
            int n = sc.nextInt(); // Read number of strings
            sc.nextLine(); // To ignore leftover newline

            words = new String[n]; // Create array

            // Read strings from user
            for (int i = 0; i < n; i++) {
                System.out.print("Enter string " + (i + 1) + ": ");
                words[i] = sc.nextLine();
            }

            sc.close(); // Close scanner
        } else {
            // Use command-line arguments
            words = args;
        }

        // Print strings that start with 'B' or 'b'
        System.out.println("\nStrings starting with 'B':");
        for (int i = 0; i < words.length; i++) {
            String s = words[i];
            if (s.toUpperCase().startsWith("B")) {
                System.out.println(s.toUpperCase()); // Print in uppercase
            }
        }
    }
}
