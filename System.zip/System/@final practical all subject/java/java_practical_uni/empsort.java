/* 16. employee
(A) Write a java program to create EMPLOYEE class with name, age and salary data members.
	Take input (data) from user and create minimum 5 objects of employee class.
	Display all employees' data in ascending order of salary.
 */
import java.util.*;

class Employee {
    String name;
    int age;
    double salary;

    public Employee(String n, int a, double s) {
        name = n;
        age = a;
        salary = s;
    }

    public void show() {
        System.out.println("Name: " + name + ", Age: " + age + ", Salary: " + salary);
    }
}

public class empsort {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        List<Employee> empList = new ArrayList<>();

        System.out.print("Enter number of employees: ");
        int n = sc.nextInt();
        sc.nextLine(); // Consume newline

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details of Employee " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Age: ");
            int age = sc.nextInt();
            System.out.print("Salary: ");
            double salary = sc.nextDouble();
            sc.nextLine(); // Consume newline

            empList.add(new Employee(name, age, salary));
        }

        // Sort employees by salary in ascending order
        Collections.sort(empList, (e1, e2) -> Double.compare(e1.salary, e2.salary));

        // Display employees after sorting
        System.out.println("\nEmployees sorted by salary:");
        for (Employee e : empList) {
            e.show();
        }
    }
}
