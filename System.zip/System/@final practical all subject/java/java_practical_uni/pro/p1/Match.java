/* 12. package
(A) Write a java program to create a player history that can be display in the following 
	form. Player name and team name is stored in Player class. Score of test match and 
	One Day match in the other class say Run class number of One Day match and number of 
	test match must be in Match class and finally calculate the average. The packagel 
	contains Player, Run and Match classes, Where package2 contain main() class.
 */


package p1;

public class Match {
    public int testMatches, oneDayMatches;

    public Match(int testMatches, int oneDayMatches) {
        this.testMatches = testMatches;
        this.oneDayMatches = oneDayMatches;
    }

    public double calculateAverage(Run run) {
        int totalMatches = testMatches + oneDayMatches;
        int totalRuns = run.testRuns + run.oneDayRuns;
        return totalMatches > 0 ? (double) totalRuns / totalMatches : 0;
    }

    public void display() {
        System.out.println("Test Matches Played: " + testMatches);
        System.out.println("One Day Matches Played: " + oneDayMatches);
    }
}