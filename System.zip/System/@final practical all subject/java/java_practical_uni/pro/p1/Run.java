/* 12. package
(A) Write a java program to create a player history that can be display in the following 
	form. Player name and team name is stored in Player class. Score of test match and 
	One Day match in the other class say Run class number of One Day match and number of 
	test match must be in Match class and finally calculate the average. The packagel 
	contains Player, Run and Match classes, Where package2 contain main() class.
 */


package p1;

public class Run {
    public int testRuns, oneDayRuns;

    public Run(int testRuns, int oneDayRuns) {
        this.testRuns = testRuns;
        this.oneDayRuns = oneDayRuns;
    }

    public void display() {
        System.out.println("Test Match Runs: " + testRuns);
        System.out.println("One Day Match Runs: " + oneDayRuns);
    }
}