/* 12. package
(A) Write a java program to create a player history that can be display in the following 
	form. Player name and team name is stored in Player class. Score of test match and 
	One Day match in the other class say Run class number of One Day match and number of 
	test match must be in Match class and finally calculate the average. The packagel 
	contains Player, Run and Match classes, Where package2 contain main() class.
 */

package p2;
import p1.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking Player Details
        System.out.print("Enter Player Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Team Name: ");
        String team = sc.nextLine();

        // Taking Run Details
        System.out.print("Enter Runs in Test Matches: ");
        int testRuns = sc.nextInt();
        System.out.print("Enter Runs in One Day Matches: ");
        int oneDayRuns = sc.nextInt();

        // Taking Match Details
        System.out.print("Enter Number of Test Matches Played: ");
        int testMatches = sc.nextInt();
        System.out.print("Enter Number of One Day Matches Played: ");
        int oneDayMatches = sc.nextInt();

        // Creating Objects
        Player player = new Player(name, team);
        Run run = new Run(testRuns, oneDayRuns);
        Match match = new Match(testMatches, oneDayMatches);

        // Displaying Player History
        System.out.println("\n--- Player History ---");
        player.display();
        run.display();
        match.display();
        System.out.println("Batting Average: " + match.calculateAverage(run));

        sc.close();
    }
}