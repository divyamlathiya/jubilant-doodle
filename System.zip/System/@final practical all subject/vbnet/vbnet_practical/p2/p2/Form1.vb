﻿Imports System.Data.SqlClient

Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-3\p2\p2\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("database connected successfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata() 'write after alldata() mack
        clear() 'write after clear() mack
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from item"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        txtitemno.Text = ""
        txtname.Text = ""
        txtcost.Text = ""
        txtquantity.Text = ""
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        con.Open()
        cmd.CommandText = "update item set cost ='" & txtcost.Text & "',quantity ='" & txtquantity.Text & "' where item_no='" & txtitemno.Text & "'"
        Dim row As Integer = cmd.ExecuteNonQuery

        If row = 0 Then
            cmd.CommandText = "INSERT INTO item VALUES ('" & txtitemno.Text & "', '" & txtname.Text & "', '" & txtcost.Text & "', '" & txtquantity.Text & "')"
            cmd.ExecuteNonQuery()
            MessageBox.Show("item added")
        Else
            MessageBox.Show("item updated")
        End If

        con.Close()
        alldata()
        clear()

    End Sub

    'Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
    '    cmd.CommandText = "select * from item where item_no = '" & txtitemno.Text & "'"
    '    con.Open()
    '    'cmd.Connection = con

    '    Dim reader As SqlDataReader = cmd.ExecuteReader()

    '    If reader.Read() Then
    '        reader.Close()
    '        cmd.CommandText = "update item set cost ='" & txtcost.Text & "',quantity ='" & txtquantity.Text & "' where item_no='" & txtitemno.Text & "'"
    '        cmd.ExecuteNonQuery()
    '        MessageBox.Show("item updated")
    '    Else
    '        reader.Close()
    '        cmd.CommandText = "INSERT INTO item VALUES ('" & txtitemno.Text & "', '" & txtname.Text & "', '" & txtcost.Text & "', '" & txtquantity.Text & "')"
    '        cmd.ExecuteNonQuery()
    '        MessageBox.Show("item added")
    '    End If

    '    con.Close()
    '    alldata()
    '    clear()

    'End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreport.Click
        Try
            cmd.CommandText = "select * from item where quantity = 0 "
            con.Open()
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    
    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "select * from item where item_no = '" & txtitemno.Text & "'"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView4.DataSource = dt

            'main code of delete
            cmd.CommandText = "delete from item where item_no='" & txtitemno.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            cmd.CommandText = "select * from item where name = '" & txtname.Text & "'"

            'optional
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView3.DataSource = dt
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
