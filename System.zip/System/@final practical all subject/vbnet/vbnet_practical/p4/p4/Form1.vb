﻿Imports System.Data.SqlClient
Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim str As String
    'Dim intid As Integer
    'Dim type As string

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-3\p4\p4\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("connection done")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata() 'write after alldata() mack
        clear() 'write after clear() mack
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from medicine"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        txtmid.Text = ""
        txtname.Text = ""
        ComboBox1.Text = ""
        txtcompany.Text = ""
        txtrate.Text = ""
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            cmd.CommandText = "insert into medicine values('" & txtmid.Text & "','" & txtname.Text & "','" & ComboBox1.Text & "','" & txtcompany.Text & "','" & txtrate.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record insert")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            cmd.CommandText = "update medicine set name='" & txtname.Text & "',type ='" & ComboBox1.Text & "',company ='" & txtcompany.Text & "',rate = '" & txtrate.Text & "' where id='" & txtmid.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record updated")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "delete from medicine where mid='" & txtmid.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreport.Click
        Try
            cmd.CommandText = "select * from medicine where type = 'syrup' and rate < 500 "

            'optional
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
