﻿Imports System.Data.SqlClient
Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-3\p3\p3\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("connected database")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata()
        clear()
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from polydetails"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try      
    End Sub

    Sub clear()
        txtpolyno.Text = ""
        txtholdername.Text = ""
        ComboBox1.Text = ""
        txtamount.Text = ""
        txtnoofyears.Text = ""
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            cmd.CommandText = "insert into polydetails values('" & txtpolyno.Text & "','" & txtholdername.Text & "','" & ComboBox1.Text & "','" & txtamount.Text & "','" & txtnoofyears.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record insert")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            cmd.CommandText = "update polydetails set holdername='" & txtholdername.Text & "',polytype ='" & ComboBox1.Text & "',amount ='" & txtamount.Text & "',no_of_years = '" & txtnoofyears.Text & "' where polyno='" & txtpolyno.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record updated")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            cmd.CommandText = "delete from polydetails where polyno='" & txtpolyno.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreport.Click
        Try
            cmd.CommandText = "select * from polydetails where polytype = '" & ComboBox1.Text & "'"

            'optional
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
