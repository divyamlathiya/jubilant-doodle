﻿Imports System.Data.SqlClient
Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    'Dim str As String
    'Dim intid As Integer
    'Dim type As string
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-3\p5\p5\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("connection done")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'alldata1() 'write after alldata1() mack
        'clear1() 'write after clear1() mack

        'alldata2() 'write after alldata2() mack
        'clear2() 'write after clear2() mack

        'alldata() 'write after alldata() mack
        'clear() 'write after clear() mack
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select a.*,p.* from agent a left join policy p on a.agent_code = p.agent_code"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView3.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        txtagentcode_a.Text = ""
        txtagentname.Text = ""
        txtcity.Text = ""
        txtpolicyno.Text = ""
        txtagentcode_p.Text = ""
        txtcustname.Text = ""
        txtpolicyamt.Text = ""
    End Sub

    Sub alldata1()
        Try
            cmd.CommandText = "select * from agent"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear1()
        txtagentcode_a.Text = ""
        txtagentname.Text = ""
        txtcity.Text = ""
    End Sub

    Sub alldata2()
        Try
            cmd.CommandText = "select * from policy"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear2()
        txtpolicyno.Text = ""
        txtagentcode_p.Text = ""
        txtcustname.Text = ""
        txtpolicyamt.Text = ""
    End Sub
    
    Private Sub btninsert_a_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert_a.Click
        Try
            cmd.CommandText = "insert into agent values('" & txtagentcode_a.Text & "','" & txtagentname.Text & "','" & txtcity.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record insert")
            'alldata1()
            clear1()

            ''option
            'alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btninsert_p_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert_p.Click
        Try
            cmd.CommandText = "insert into policy values('" & txtpolicyno.Text & "','" & txtagentcode_p.Text & "','" & txtcustname.Text & "','" & DateTimePickerstart.Value.ToString("yyyy-MM-dd") & "','" & DateTimePickerend.Value.ToString("yyyy-MM-dd") & "','" & txtpolicyamt.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record insert")
            'alldata2()
            clear2()

            ''option
            'alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnupdate_a_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate_a.Click
        Try
            cmd.CommandText = "update agent set agent_name ='" & txtagentname.Text & "',city = '" & txtcity.Text & "' where agent_code = '" & txtagentcode_a.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record updated")
            'alldata1()
            clear1()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
        
    Private Sub btnupdate_p_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate_p.Click
        Try
            cmd.CommandText = "update policy set agent_code = '" & txtagentcode_p.Text & "',cust_name='" & txtcustname.Text & "',start_date = '" & DateTimePickerstart.Value.ToString("yyyy-MM-dd") & "',end_date = '" & DateTimePickerend.Value.ToString("yyyy-MM-dd") & "',policy_amt = '" & txtpolicyamt.Text & "' where policy_no = '" & txtpolicyno.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record updated")
            'alldata2()
            clear2()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndelete_a_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete_a.Click
        Try
            cmd.CommandText = "delete from agent where agent_code='" & txtagentcode_a.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            'alldata1()
            clear1()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndelete_p_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete_p.Click
        Try
            cmd.CommandText = "delete from policy where policy_no='" & txtpolicyno.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            'alldata2()
            clear2()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndisplay_a_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay_a.Click
        alldata1()

        'option
        alldata()
    End Sub

    Private Sub btndisplay_p_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay_p.Click
        alldata2()

        'option
        alldata()
    End Sub

    Private Sub qury1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles qury1.Click
        Try
            cmd.CommandText = "select policy_no,agent_code,cust_name from policy order by policy_amt asc"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView4.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub qury2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles qury2.Click
        Try
            cmd.CommandText = "(SELECT SUM(p2.policy_amt) FROM policy_master1 p2 WHERE p2.agent_code = a.agent_code) AS total FROM agent_master a JOIN policy_master1 p ON a.agent_code = p.agent_code"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView4.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
