﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btndisplay_p = New System.Windows.Forms.Button()
        Me.btndelete_p = New System.Windows.Forms.Button()
        Me.btnupdate_p = New System.Windows.Forms.Button()
        Me.btninsert_p = New System.Windows.Forms.Button()
        Me.txtpolicyamt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtcustname = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtagentcode_p = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtpolicyno = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btndisplay_a = New System.Windows.Forms.Button()
        Me.btndelete_a = New System.Windows.Forms.Button()
        Me.btnupdate_a = New System.Windows.Forms.Button()
        Me.btninsert_a = New System.Windows.Forms.Button()
        Me.txtcity = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtagentname = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtagentcode_a = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.DateTimePickerstart = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePickerend = New System.Windows.Forms.DateTimePicker()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.qury1 = New System.Windows.Forms.Button()
        Me.qury2 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(216, 316)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 20)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "policy "
        '
        'btndisplay_p
        '
        Me.btndisplay_p.Location = New System.Drawing.Point(373, 538)
        Me.btndisplay_p.Name = "btndisplay_p"
        Me.btndisplay_p.Size = New System.Drawing.Size(155, 42)
        Me.btndisplay_p.TabIndex = 54
        Me.btndisplay_p.Text = "display"
        Me.btndisplay_p.UseVisualStyleBackColor = True
        '
        'btndelete_p
        '
        Me.btndelete_p.Location = New System.Drawing.Point(373, 482)
        Me.btndelete_p.Name = "btndelete_p"
        Me.btndelete_p.Size = New System.Drawing.Size(155, 42)
        Me.btndelete_p.TabIndex = 53
        Me.btndelete_p.Text = "delete"
        Me.btndelete_p.UseVisualStyleBackColor = True
        '
        'btnupdate_p
        '
        Me.btnupdate_p.Location = New System.Drawing.Point(373, 424)
        Me.btnupdate_p.Name = "btnupdate_p"
        Me.btnupdate_p.Size = New System.Drawing.Size(155, 42)
        Me.btnupdate_p.TabIndex = 52
        Me.btnupdate_p.Text = "update"
        Me.btnupdate_p.UseVisualStyleBackColor = True
        '
        'btninsert_p
        '
        Me.btninsert_p.Location = New System.Drawing.Point(373, 361)
        Me.btninsert_p.Name = "btninsert_p"
        Me.btninsert_p.Size = New System.Drawing.Size(155, 42)
        Me.btninsert_p.TabIndex = 51
        Me.btninsert_p.Text = "insert"
        Me.btninsert_p.UseVisualStyleBackColor = True
        '
        'txtpolicyamt
        '
        Me.txtpolicyamt.Location = New System.Drawing.Point(137, 577)
        Me.txtpolicyamt.Name = "txtpolicyamt"
        Me.txtpolicyamt.Size = New System.Drawing.Size(199, 26)
        Me.txtpolicyamt.TabIndex = 50
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(26, 581)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 20)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "policy_amt"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 538)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 20)
        Me.Label8.TabIndex = 47
        Me.Label8.Text = "end_date"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 494)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 20)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "start_date"
        '
        'txtcustname
        '
        Me.txtcustname.Location = New System.Drawing.Point(137, 445)
        Me.txtcustname.Name = "txtcustname"
        Me.txtcustname.Size = New System.Drawing.Size(199, 26)
        Me.txtcustname.TabIndex = 44
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 449)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 20)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "cust_name"
        '
        'txtagentcode_p
        '
        Me.txtagentcode_p.Location = New System.Drawing.Point(137, 400)
        Me.txtagentcode_p.Name = "txtagentcode_p"
        Me.txtagentcode_p.Size = New System.Drawing.Size(199, 26)
        Me.txtagentcode_p.TabIndex = 42
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 404)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 20)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "agent_code"
        '
        'txtpolicyno
        '
        Me.txtpolicyno.Location = New System.Drawing.Point(137, 357)
        Me.txtpolicyno.Name = "txtpolicyno"
        Me.txtpolicyno.Size = New System.Drawing.Size(199, 26)
        Me.txtpolicyno.TabIndex = 40
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 361)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 20)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "policy_no"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(239, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(50, 20)
        Me.Label11.TabIndex = 66
        Me.Label11.Text = "agent"
        '
        'btndisplay_a
        '
        Me.btndisplay_a.Location = New System.Drawing.Point(373, 230)
        Me.btndisplay_a.Name = "btndisplay_a"
        Me.btndisplay_a.Size = New System.Drawing.Size(155, 42)
        Me.btndisplay_a.TabIndex = 65
        Me.btndisplay_a.Text = "display"
        Me.btndisplay_a.UseVisualStyleBackColor = True
        '
        'btndelete_a
        '
        Me.btndelete_a.Location = New System.Drawing.Point(373, 174)
        Me.btndelete_a.Name = "btndelete_a"
        Me.btndelete_a.Size = New System.Drawing.Size(155, 42)
        Me.btndelete_a.TabIndex = 64
        Me.btndelete_a.Text = "delete"
        Me.btndelete_a.UseVisualStyleBackColor = True
        '
        'btnupdate_a
        '
        Me.btnupdate_a.Location = New System.Drawing.Point(373, 116)
        Me.btnupdate_a.Name = "btnupdate_a"
        Me.btnupdate_a.Size = New System.Drawing.Size(155, 42)
        Me.btnupdate_a.TabIndex = 63
        Me.btnupdate_a.Text = "update"
        Me.btnupdate_a.UseVisualStyleBackColor = True
        '
        'btninsert_a
        '
        Me.btninsert_a.Location = New System.Drawing.Point(373, 53)
        Me.btninsert_a.Name = "btninsert_a"
        Me.btninsert_a.Size = New System.Drawing.Size(155, 42)
        Me.btninsert_a.TabIndex = 62
        Me.btninsert_a.Text = "insert"
        Me.btninsert_a.UseVisualStyleBackColor = True
        '
        'txtcity
        '
        Me.txtcity.Location = New System.Drawing.Point(138, 183)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(199, 26)
        Me.txtcity.TabIndex = 61
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 187)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 20)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "city"
        '
        'txtagentname
        '
        Me.txtagentname.Location = New System.Drawing.Point(138, 139)
        Me.txtagentname.Name = "txtagentname"
        Me.txtagentname.Size = New System.Drawing.Size(199, 26)
        Me.txtagentname.TabIndex = 59
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(99, 20)
        Me.Label6.TabIndex = 58
        Me.Label6.Text = "agent_name"
        '
        'txtagentcode_a
        '
        Me.txtagentcode_a.Location = New System.Drawing.Point(138, 96)
        Me.txtagentcode_a.Name = "txtagentcode_a"
        Me.txtagentcode_a.Size = New System.Drawing.Size(199, 26)
        Me.txtagentcode_a.TabIndex = 57
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(27, 100)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(94, 20)
        Me.Label9.TabIndex = 56
        Me.Label9.Text = "agent_code"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(574, 36)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(1134, 173)
        Me.DataGridView1.TabIndex = 67
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(1101, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(91, 20)
        Me.Label12.TabIndex = 68
        Me.Label12.Text = "agent_data"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(1101, 218)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(89, 20)
        Me.Label13.TabIndex = 70
        Me.Label13.Text = "policy_data"
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(574, 241)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowTemplate.Height = 28
        Me.DataGridView2.Size = New System.Drawing.Size(1134, 182)
        Me.DataGridView2.TabIndex = 69
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(1089, 430)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(126, 20)
        Me.Label14.TabIndex = 72
        Me.Label14.Text = "both_table_data"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(574, 453)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 28
        Me.DataGridView3.Size = New System.Drawing.Size(1134, 174)
        Me.DataGridView3.TabIndex = 71
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(-3, 289)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(564, 20)
        Me.Label15.TabIndex = 73
        Me.Label15.Text = "---------------------------------------------------------------------------------" & _
            "------------------------------"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(547, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(14, 20)
        Me.Label16.TabIndex = 74
        Me.Label16.Text = "|"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(547, 21)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(14, 20)
        Me.Label17.TabIndex = 75
        Me.Label17.Text = "|"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(547, 41)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(14, 20)
        Me.Label18.TabIndex = 76
        Me.Label18.Text = "|"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(547, 99)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(14, 20)
        Me.Label19.TabIndex = 79
        Me.Label19.Text = "|"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(547, 79)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(14, 20)
        Me.Label20.TabIndex = 78
        Me.Label20.Text = "|"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(547, 59)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(14, 20)
        Me.Label21.TabIndex = 77
        Me.Label21.Text = "|"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(547, 206)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(14, 20)
        Me.Label22.TabIndex = 85
        Me.Label22.Text = "|"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(547, 186)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(14, 20)
        Me.Label23.TabIndex = 84
        Me.Label23.Text = "|"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(547, 166)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(14, 20)
        Me.Label24.TabIndex = 83
        Me.Label24.Text = "|"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(547, 148)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 20)
        Me.Label25.TabIndex = 82
        Me.Label25.Text = "|"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(547, 128)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(14, 20)
        Me.Label26.TabIndex = 81
        Me.Label26.Text = "|"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(547, 108)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(14, 20)
        Me.Label27.TabIndex = 80
        Me.Label27.Text = "|"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(547, 429)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(14, 20)
        Me.Label28.TabIndex = 97
        Me.Label28.Text = "|"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(547, 409)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(14, 20)
        Me.Label29.TabIndex = 96
        Me.Label29.Text = "|"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(547, 389)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(14, 20)
        Me.Label30.TabIndex = 95
        Me.Label30.Text = "|"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(547, 371)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(14, 20)
        Me.Label31.TabIndex = 94
        Me.Label31.Text = "|"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(547, 351)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(14, 20)
        Me.Label32.TabIndex = 93
        Me.Label32.Text = "|"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(547, 331)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(14, 20)
        Me.Label33.TabIndex = 92
        Me.Label33.Text = "|"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(547, 322)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(14, 20)
        Me.Label34.TabIndex = 91
        Me.Label34.Text = "|"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(547, 302)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(14, 20)
        Me.Label35.TabIndex = 90
        Me.Label35.Text = "|"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(547, 282)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(14, 20)
        Me.Label36.TabIndex = 89
        Me.Label36.Text = "|"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(547, 264)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(14, 20)
        Me.Label37.TabIndex = 88
        Me.Label37.Text = "|"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(547, 244)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(14, 20)
        Me.Label38.TabIndex = 87
        Me.Label38.Text = "|"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(547, 224)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(14, 20)
        Me.Label39.TabIndex = 86
        Me.Label39.Text = "|"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(547, 610)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(14, 20)
        Me.Label42.TabIndex = 107
        Me.Label42.Text = "|"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(547, 592)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(14, 20)
        Me.Label43.TabIndex = 106
        Me.Label43.Text = "|"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(547, 572)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(14, 20)
        Me.Label44.TabIndex = 105
        Me.Label44.Text = "|"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(547, 552)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(14, 20)
        Me.Label45.TabIndex = 104
        Me.Label45.Text = "|"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(547, 543)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(14, 20)
        Me.Label46.TabIndex = 103
        Me.Label46.Text = "|"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(547, 523)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(14, 20)
        Me.Label47.TabIndex = 102
        Me.Label47.Text = "|"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(547, 503)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(14, 20)
        Me.Label48.TabIndex = 101
        Me.Label48.Text = "|"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(547, 485)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(14, 20)
        Me.Label49.TabIndex = 100
        Me.Label49.Text = "|"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(547, 465)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(14, 20)
        Me.Label50.TabIndex = 99
        Me.Label50.Text = "|"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(547, 445)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(14, 20)
        Me.Label51.TabIndex = 98
        Me.Label51.Text = "|"
        '
        'DateTimePickerstart
        '
        Me.DateTimePickerstart.Location = New System.Drawing.Point(137, 493)
        Me.DateTimePickerstart.Name = "DateTimePickerstart"
        Me.DateTimePickerstart.Size = New System.Drawing.Size(199, 26)
        Me.DateTimePickerstart.TabIndex = 108
        '
        'DateTimePickerend
        '
        Me.DateTimePickerend.Location = New System.Drawing.Point(137, 533)
        Me.DateTimePickerend.Name = "DateTimePickerend"
        Me.DateTimePickerend.Size = New System.Drawing.Size(199, 26)
        Me.DateTimePickerend.TabIndex = 109
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(1089, 641)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(114, 20)
        Me.Label40.TabIndex = 111
        Me.Label40.Text = "proccess_data"
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(574, 664)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowTemplate.Height = 28
        Me.DataGridView4.Size = New System.Drawing.Size(1134, 196)
        Me.DataGridView4.TabIndex = 110
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(547, 811)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(14, 20)
        Me.Label41.TabIndex = 122
        Me.Label41.Text = "|"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(547, 793)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(14, 20)
        Me.Label52.TabIndex = 121
        Me.Label52.Text = "|"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(547, 773)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(14, 20)
        Me.Label53.TabIndex = 120
        Me.Label53.Text = "|"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(547, 753)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(14, 20)
        Me.Label54.TabIndex = 119
        Me.Label54.Text = "|"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(547, 744)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(14, 20)
        Me.Label55.TabIndex = 118
        Me.Label55.Text = "|"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(547, 724)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(14, 20)
        Me.Label56.TabIndex = 117
        Me.Label56.Text = "|"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(547, 704)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(14, 20)
        Me.Label57.TabIndex = 116
        Me.Label57.Text = "|"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(547, 686)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(14, 20)
        Me.Label58.TabIndex = 115
        Me.Label58.Text = "|"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(547, 666)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(14, 20)
        Me.Label59.TabIndex = 114
        Me.Label59.Text = "|"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(547, 646)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(14, 20)
        Me.Label60.TabIndex = 113
        Me.Label60.Text = "|"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(547, 630)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(14, 20)
        Me.Label61.TabIndex = 112
        Me.Label61.Text = "|"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(547, 861)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(14, 20)
        Me.Label64.TabIndex = 125
        Me.Label64.Text = "|"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(547, 857)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(14, 20)
        Me.Label65.TabIndex = 124
        Me.Label65.Text = "|"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(547, 835)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(14, 20)
        Me.Label66.TabIndex = 123
        Me.Label66.Text = "|"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(-3, 626)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(554, 20)
        Me.Label62.TabIndex = 126
        Me.Label62.Text = "---------------------------------------------------------------------------------" & _
            "----------------------------"
        '
        'qury1
        '
        Me.qury1.Location = New System.Drawing.Point(38, 721)
        Me.qury1.Name = "qury1"
        Me.qury1.Size = New System.Drawing.Size(164, 73)
        Me.qury1.TabIndex = 127
        Me.qury1.Text = "asending_order"
        Me.qury1.UseVisualStyleBackColor = True
        '
        'qury2
        '
        Me.qury2.Location = New System.Drawing.Point(343, 720)
        Me.qury2.Name = "qury2"
        Me.qury2.Size = New System.Drawing.Size(164, 73)
        Me.qury2.TabIndex = 128
        Me.qury2.Text = "agent-wise_amt"
        Me.qury2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1720, 890)
        Me.Controls.Add(Me.qury2)
        Me.Controls.Add(Me.qury1)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.DataGridView4)
        Me.Controls.Add(Me.DateTimePickerend)
        Me.Controls.Add(Me.DateTimePickerstart)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btndisplay_a)
        Me.Controls.Add(Me.btndelete_a)
        Me.Controls.Add(Me.btnupdate_a)
        Me.Controls.Add(Me.btninsert_a)
        Me.Controls.Add(Me.txtcity)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtagentname)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtagentcode_a)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.btndisplay_p)
        Me.Controls.Add(Me.btndelete_p)
        Me.Controls.Add(Me.btnupdate_p)
        Me.Controls.Add(Me.btninsert_p)
        Me.Controls.Add(Me.txtpolicyamt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtcustname)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtagentcode_p)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtpolicyno)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btndisplay_p As System.Windows.Forms.Button
    Friend WithEvents btndelete_p As System.Windows.Forms.Button
    Friend WithEvents btnupdate_p As System.Windows.Forms.Button
    Friend WithEvents btninsert_p As System.Windows.Forms.Button
    Friend WithEvents txtpolicyamt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtcustname As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtagentcode_p As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtpolicyno As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btndisplay_a As System.Windows.Forms.Button
    Friend WithEvents btndelete_a As System.Windows.Forms.Button
    Friend WithEvents btnupdate_a As System.Windows.Forms.Button
    Friend WithEvents btninsert_a As System.Windows.Forms.Button
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtagentname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtagentcode_a As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerstart As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePickerend As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents qury1 As System.Windows.Forms.Button
    Friend WithEvents qury2 As System.Windows.Forms.Button

End Class
