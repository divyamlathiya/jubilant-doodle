﻿Imports System.Data.SqlClient

Public Class Form1

    Dim conn As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            conn.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-2\p-5\p-5\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = conn
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            cmd.CommandText = "insert into agent_master values ('" & TextBox1.Text & "', '" & TextBox2.Text & "', '" & ComboBox1.SelectedItem & "')"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            clear() 'optional
            MsgBox("Data inserted")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            cmd.CommandText = "update agent_master set agent_name = '" & TextBox2.Text & "',city = '" & ComboBox1.SelectedItem & "' where agent_code = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            clear() 'optional
            MsgBox("Data updated")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            cmd.CommandText = "delete from agent_master where agent_code = '" & TextBox1.Text & "'"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            clear() 'optional
            MsgBox("Data delted sussfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim f2 As New Form2()
        Dim f1 As New Form1()
        f2.Show()
        f1.close()
    End Sub
End Class
