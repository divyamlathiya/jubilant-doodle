﻿Imports System.Data.SqlClient

Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim str As String
    'Dim intid As Integer
    'Dim type As string

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=F:\B.c.a Sem - 4\exam-uni\vb.net\practical-3\p1\p1\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
            MsgBox("connection done")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        alldata() 'write after alldata() mack
        clear() 'write after clear() mack
    End Sub

    Sub alldata()
        Try
            cmd.CommandText = "select * from student1"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub clear()
        txtid.Text = ""
        txtname.Text = ""
        ComboBox1.Text = ""
        txtaddress.Text = ""
    End Sub

    Private Sub insert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Try
            If radiomale.Checked Then
                str = "male"
            ElseIf radiofemale.Checked Then
                str = "female"
            Else
                MsgBox("plz! select gender")
            End If
        Catch ex As Exception

        End Try
        Try
            cmd.CommandText = "insert into student1 values('" & txtid.Text & "','" & txtname.Text & "','" & ComboBox1.Text & "','" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "','" & str & "','" & txtaddress.Text & "')"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record insert")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            If radiomale.Checked Then
                str = "male"
            ElseIf radiofemale.Checked Then
                str = "female"
            Else
                MsgBox("plz! select gender")
            End If
        Catch ex As Exception

        End Try
        Try
            cmd.CommandText = "update student1 set name='" & txtname.Text & "',course ='" & ComboBox1.Text & "',dob ='" & DateTimePicker1.Value.ToString("yyyy-MM-dd") & "',gender ='" & str & "',address = '" & txtaddress.Text & "' where id='" & txtid.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record updated")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Try
            'if need data show deleted
            cmd.CommandText = "select * from student1 where id = '" & txtid.Text & "'"
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView3.DataSource = dt

            'main code of delete
            cmd.CommandText = "delete from student1 where id='" & txtid.Text & "'"
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            MsgBox("record deleted")
            alldata()
            clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Try
            cmd.CommandText = "select * from student1 where course = '" & ComboBox1.Text & "'"

            'optional
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            Dim dt As New DataTable
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btncount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncount.Click
        Try
            'cmd.Connection = con
            cmd.CommandText = "select count(*) from student1 where course ='" & ComboBox1.Text & "' "

            con.Open()
            Dim no As Integer = Convert.ToInt32(cmd.ExecuteScalar)
            con.Close()
            MessageBox.Show("total student =" + no.ToString())

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
