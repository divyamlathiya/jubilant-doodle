// Loading content via AJAX (JSON)
$(document).ready(function () {
  // Fetch feature data using JSON
  $.ajax({
    url: "features.json", // JSON file with feature data
    method: "GET",
    success: function (data) {
      let featureHTML = "<ul>";
      data.features.forEach(function (feature) {
        featureHTML += `
                    <li>
                        <h3>${feature.title}</h3>
                        <p>${feature.description}</p>
                        <img src="${feature.image}" alt="${feature.title}">
                    </li>
                `;
      });
      featureHTML += "</ul>";
      $("#feature-list").html(featureHTML);
    },
    error: function () {
      $("#feature-list").html(
        "<p>Sorry, we couldn't load the features at the moment.</p>"
      );
    },
  });

  // Form validation using jQuery
  $("#contact-form").submit(function (event) {
    event.preventDefault();

    let isValid = true;

    // Validate name
    if ($("#name").val().trim() === "") {
      isValid = false;
      alert("Name is required");
    }

    // Validate email
    if ($("#email").val().trim() === "") {
      isValid = false;
      alert("Email is required");
    }

    // Validate message
    if ($("#message").val().trim() === "") {
      isValid = false;
      alert("Message is required");
    }

    // If form is valid, display a success message
    if (isValid) {
      alert("Form submitted successfully!");
      $("#contact-form")[0].reset();
    }
  });
});
