$(document).ready(function () {
    // Hamburger Menu Toggle
    $("#hamburger").click(function () {
        $("#hamburger-content").toggle();
    });

    // Fetch Movies for About Page
    $.ajax({
        url: "data/movies.json",
        method: "GET",
        success: function (data) {
            let movies = data.movies;
            let movieList = "";
            movies.forEach(movie => {
                movieList += `<li>${movie.name}</li>`;
            });
            $("#movie-list").html(movieList);
        }
    });

    // Fetch Movies and Theaters for Booking Page
    $.ajax({
        url: "data/movies.json",
        method: "GET",
        success: function (data) {
            let movies = data.movies;
            let movieOptions = "";
            movies.forEach(movie => {
                movieOptions += `<option value="${movie.id}">${movie.name}</option>`;
            });
            $("#movie").html(movieOptions);
        }
    });

    $.ajax({
        url: "data/theaters.xml",
        method: "GET",
        dataType: "xml",
        success: function (data) {
            let theaterOptions = "";
            $(data).find("theater").each(function () {
                theaterOptions += `<option value="${$(this).find("id").text()}">${$(this).find("name").text()}</option>`;
            });
            $("#theater").html(theaterOptions);
        }
    });

    // Form Validation
    $("#bookingForm").submit(function (e) {
        e.preventDefault();
        let movie = $("#movie").val();
        let theater = $("#theater").val();
        let date = $("#date").val();
        let time = $("#time").val();

        if (movie && theater && date && time) {
            alert("Booking Successful!");
        } else {
            alert("Please fill all fields.");
        }
    });
});

$(document).ready(function () {
    // Highlight Active Page Link
    const currentPage = window.location.pathname.split("/").pop();
    $("nav a").each(function () {
        if ($(this).attr("href") === currentPage) {
            $(this).addClass("active");
        }
    });
});