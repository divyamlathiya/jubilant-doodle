$(document).ready(function () {
  // Load JSON for About and Services
  $.getJSON("data.json", function (data) {
    $("#about h1").text(data.about.heading);
    $("#about p").text(data.about.paragraph);

    $("#services h1").text(data.services.heading);
    $("#services p").text(data.services.paragraph);
  });

  // Load XML for Portfolio
  $.ajax({
    type: "GET",
    url: "data.xml",
    dataType: "xml",
    success: function (xml) {
      const heading = $(xml).find("portfolio heading").text();
      const paragraph = $(xml).find("portfolio paragraph").text();

      $("#portfolio h1").text(heading);
      $("#portfolio p").text(paragraph);
    },
  });
});
