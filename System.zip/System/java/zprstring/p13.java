//13.string
/* (A) Write a java program to enter strings at command line input and then sort strings 
	into ascending order.
 */
/*  
 import java.util.*;
 
 class p13
 {
	 public  static void main(String [] args)
	 {
		 if(args.length < 1)
		 {
			 System.out.println("plz! enter args in commandline...");
			 return;
		 }
		 
		 //this is a functionality of array lib. for sort data asending.
		 //Arrays.sort(args);
		 
		 //sort data using swap method
		 for(int i=0;i<args.length-1;i++)
		 {
			 for(int j=i+1;j<args.length;j++)
			 {
				 if(args[i].compareToIgnoreCase(args[j])>0)
				 {
					 String temp = args[i];
					 args[i] = args[j];
					 args[j] = temp;
				 }
			 }
		 }
		 
		 for(String str : args)
		 {
			 System.out.println(str);
		 }
	 }
 } */
 
 // user argument
 
 import java.util.*;
 
 class p13
 {
	 public  static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 String [] arr1;
		 
		 if(args.length < 1)
		 {
			 System.out.print("Enter how much string enter in array : ");
			 int n = s.nextInt();

			 s.nextLine();
		 
			 arr1 = new String[n];
		 
			 for(int i=0; i<n ; i++)
			 {
				 System.out.print("String"+(i+1)+(" : "));
				 arr1[i]=s.nextLine();
			 }
		 }
		 else
		 {
			 arr1 = args;
		 }
		 
		 //this is a functionality of array lib. for sort data asending.
		 //Arrays.sort(arr1);
		 
		 //sort data using swap method
		 for(int i=0;i<arr1.length-1;i++)
		 {
			 for(int j=i+1;j<arr1.length;j++)
			 {
				 if(arr1[i].compareToIgnoreCase(arr1[j])>0)
				 {
					 String temp = arr1[i];
					 arr1[i] = arr1[j];
					 arr1[j] = temp;
				 }
			 }
		 }
		 
		 for(String str : arr1)
		 {
			 System.out.println(str);
		 }
	 }
 }