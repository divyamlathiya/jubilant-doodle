//extra
/*  we have 1 string form user now first convert it in character array and add that
 characters one by one by in arr1 array */
 
 import java.util.*;

class demo {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = s.nextLine();

        // Convert to character array
        char[] ch = str.toCharArray();

        // Create new array to store characters one by one
        char[] arr1 = new char[ch.length];

        // Add characters to arr1 using loop
        for(int i = 0; i < ch.length; i++) {
            arr1[i] = ch[i];  // copy each character
        }

        // Print arr1 content
        System.out.println("Characters in arr1:");
        for(int i = 0; i < arr1.length; i++) {
            System.out.print(arr1[i] + " ");
        }

        s.close();
    }
}

// string to array and charArray

import java.util.*;

class StringSplitter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input string
        System.out.print("Enter a string: ");
        String str = sc.nextLine();

        // 1. Convert to character array
        char[] charArray = str.toCharArray();
        System.out.println("\nCharacters in string:");
        for (char c : charArray) {
            System.out.print(c + " ");
        }

        // 2. Split using split(" ")
        String[] splitBySpace = str.split(" ");
        System.out.println("\n\nSplit using split(\" \"):");
        for (String word : splitBySpace) {
            System.out.println(word);
        }

        // 3. Split using split("\\s+")
        String[] splitByWhitespace = str.split("\\s+");
        System.out.println("\nSplit using split(\"\\\\s+\"):");
        for (String word : splitByWhitespace) {
            System.out.println(word);
        }

        sc.close();
    }
}
