/* 11. string
(A) Write a java application which accepts two strings. 
	Merge both the strings using alternate characters of each one.
	For example: If String1 is: "Very", and String2 is: "Good",
	Then result should be: "VGeoroyd".
 */
 
 import java.util.*;
 
 class p11
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 System.out.print("Enter String 1 : ");
		 String str1 = s.nextLine();
		 
		 System.out.print("Enter String 2 : ");
		 String str2 = s.nextLine();
		 
		 int str1len = str1.length();
		 int str2len = str2.length();
		 int totallen = str1len + str2len;
		 
		 int i = 0 , s1 = 0 , s2 = 0;
		 
		 StringBuffer result = new StringBuffer();
		 
		 //using while loop
		 while(i<totallen)
		 {
			 
			if (s1<str1len)
			{
				 result.append(str1.charAt(s1));
				 s1++;
			}	
			
			if(s2 < str2len)
			{
				result.append(str2.charAt(s2));
				s2++;
			}
			
			i++;
		 }
		 
		 //using for loop
		 
		 /* for(i=0;i<totallen;i++)
		 {
			 
			if (s1<str1len)
			{
				 result.append(str1.charAt(s1));
				 s1++;
			}	
			
			if(s2 < str2len)
			{
				result.append(str2.charAt(s2));
				s2++;
			}
			
		 } */
		 
		 System.out.println("result string is : "+ result);
	 }
 }