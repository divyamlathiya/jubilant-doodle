//3. vowel
/* (A) Write a Java Program that accepts string data. Extract either All Vowels or All 
	Non-Vowels from given Data According to Options Selection. Also Provide an Option to 
	Display Output in Uppercase or Lowercase.
 */
 
 import java.util.*;
 
 class p03
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 System.out.print("Enter the String for process : ");
		 String str = s.nextLine();
		 
		 System.out.println("1. extract vowels ");
		 System.out.println("2. extract non-vovels ");
		 
		 System.out.print("Enter your choice : ");
		 int choice = s.nextInt();
		 
		 System.out.println("1. Uppercase ");
		 System.out.println("2. Lowercase ");
		 
		 System.out.print("Enter your choice : ");
		 int choice1 = s.nextInt();
		 
		 StringBuffer strv = new StringBuffer();
		 
		 char [] arr1 = str.toCharArray();
		 
		 if(choice == 1)
		 {
			for(int i=0; i<arr1.length ;i++)
			{
				// if capare charactor then use single ' ' and string " "
				if(arr1[i] == 'A' || arr1[i] == 'a' || arr1[i] == 'E' || arr1[i] == 'e' ||arr1[i] == 'I' || arr1[i] == 'i' || arr1[i] == 'O' || arr1[i] == 'o' || arr1[i] == 'U' || arr1[i] == 'u')
				{
					strv.append(arr1[i]);
				}
			}
			 
		 }
		 
		 if(choice == 2)
		 {
			for(int i=0; i<arr1.length ;i++)
			{
				if(!(arr1[i] == 'A' || arr1[i] == 'a' || arr1[i] == 'E' || arr1[i] == 'e' ||arr1[i] == 'I' || arr1[i] == 'i' || arr1[i] == 'O' || arr1[i] == 'o' || arr1[i] == 'U' || arr1[i] == 'u'))
				{
					strv.append(arr1[i]);
				}
			} 
		 }
		 
		 String result = strv.toString(); //convert stringbuffer to string
		 
		 //convert string to stringbuffer
		 // Stringbuffer strb = new StringBuffer(result); 
		 
		 if(choice1 == 1)
		 {
			 System.out.println(result.toUpperCase());
		 }
		 
		 if(choice1 == 2)
		 {
			 System.out.println(result.toLowerCase());
		 }
	 }
 }
 
// another methods
 
/* import java.util.*;

class p03
{
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);

		System.out.print("Enter the String for process : ");
		String str = s.nextLine();

		System.out.println("1. extract vowels ");
		System.out.println("2. extract non-vovels ");
		System.out.print("Enter your choice : ");
		int choice = s.nextInt();

		System.out.println("1. Uppercase ");
		System.out.println("2. Lowercase ");
		System.out.print("Enter your choice : ");
		int choice1 = s.nextInt();

		StringBuffer strv = new StringBuffer();

		for(int i = 0; i < str.length(); i++)
		{
			char c = str.charAt(i);

			if(choice == 1) // extract vowels
			{
				if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U'||c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
				{
					if(choice1 == 1)
					{
						strv.append(Character.toUpperCase(c));
					}
					else
					{
						strv.append(Character.toLowerCase(c));
					}
				}
			}
			else if(choice == 2) // extract non-vowels
			{
				if(!(c=='A'||c=='E'||c=='I'||c=='O'||c=='U'||c=='a'||c=='e'||c=='i'||c=='o'||c=='u'))
				{
					if(choice1 == 1)
					{
						strv.append(Character.toUpperCase(c));
					}
					else
					{
						strv.append(Character.toLowerCase(c));
					}
				}
			}
		}

		System.out.println("Result : " + strv.toString());
		s.close();
	}
}
*/

// extra informations

/* What is Character in Java?
Character is a special class in Java, which means it's like a blueprint for working with characters (like 'a', 'b', 'A', '1', etc.).

A class is a collection of things (in this case, methods) that help you do specific tasks.

Why do we need the Character class?
Normally, in Java, a character is represented by the primitive data type called char. A char is just a single character like 'a' or '1'.

The Character class is like a helper for working with characters. It provides special methods to do things that a char by itself cannot do.

For example, it can help you:

Change a character to uppercase: 'a' becomes 'A'.

Change a character to lowercase: 'A' becomes 'a'.

Check if a character is a letter or a number: It can tell you if '1' is a digit or if 'A' is a letter. */ 