/* 9. string
(A) Write a java program to design a class Mystring having data member of type String add 
	member function to achieve following task.
	1. Reverse String
	2. Upprecase String
	3. Lowercase String
	4. String in tOGGLECASE
	5. Sentence case
	6. Extract N-Characters from right-end of the string
	Write a menu driven program to call these methods Mystring Class. 
	The program must use Exception handling.

(A) Write a Java Program that Accepts String Data from User and then Provide options 
	for Changing case into Any of the Following. (UPPERCASE, lowercase, Sentence case, 
	tOGGLE CASE).
 */
 
 import java.util.*;
 
 class mystr
 {
	 StringBuffer str;
	 
	 public mystr(String s1)
	 {
		 str = new StringBuffer(s1);
	 }
	 
	 public void rev()
	 {
		 System.out.println("Reversed String is : "+str.reverse());
		 
		 str=str.reverse();//for mack reversed-string in normal-string. 
	 }
	 
	 public void upper()
	 {
		 System.out.println("String in uppercase : "+str.toString().toUpperCase());// toString() function is use for convert StringBuffer to string
	 }
	 
	 public void lower()
	 {
		 System.out.println("String in lowercase : "+str.toString().toLowerCase());
	 }
	 
	 public void toggle()
	 {
		 char [] str3 = str.toString().toCharArray();//str transfer in character array and store in str3
		 
		 StringBuffer result = new StringBuffer();
		 
		 for(int i=0;i<str3.length;i++)
		 {
			 if(Character.isUpperCase(str3[i]))// using character class check uppercase or not Str3[i]
			 {
				 result.append(Character.toLowerCase(str3[i]));// using character class convert char in lowercase Str3[i]
			 }
			 else if(Character.isLowerCase(str3[i]))// using character class check lowercase or not Str3[i]
			 {
				 result.append(Character.toUpperCase(str3[i]));// using character class convert char in uppercase Str3[i]
			 }
			 else
			 {
				 result.append(str3[i]);//another words like space or apecial number or number
			 }
		 }
		 System.out.println("Toggled String is : "+result);
	 }
	 
	 // this is another style of toggling string without macking array str3[].
	 
	 /* public void toggle() 
	 {
        StringBuffer result = new StringBuffer();
		
        for (char ch : str.toString().toCharArray()) 
		{
            if (Character.isUpperCase(ch))
			{
                result.append(Character.toLowerCase(ch));
			}
            else
			{
                result.append(Character.toUpperCase(ch));
			}
        }
        System.out.println("Toggle Case: " + result);
    } */
	
	 public void sentans()
	 {
		 String s = str.toString();
		 System.out.println("Sentence String is : "+Character.toUpperCase(s.charAt(0))+s.substring(1).toLowerCase());
	 }
	 
	 public void extract(int i)
	 {
		 if(i<0 || i>str.length())
		 {
			 System.out.println("Plz! enter valid value.....");	 
		 }
		 else
		 {
		 System.out.println("Extracted string is : "+str.substring(str.length()-i));
		 }
	 }
 }
 class p09
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 System.out.print("Enter string : ");
		 String str1 = s.nextLine();
		 
		 System.out.println();
		 
		 mystr obj = new mystr(str1);// call class cunstructor mystr...
		 while(true)
		 {
		 System.out.println("1. reverse string \n2. uppercase string \n3. lowercase string \n4. Togglecase \n5. Sentence case \n6. Extract characters from string \n7. Exit");
		 
		 System.out.print("choice process : ");
		 int choice = s.nextInt();
		 
		 System.out.println();
		 
		 //this is for exit into while loop
		 
		 if(choice == 7)
		 {
			 break;
		 }
		 
		 switch(choice)
		 {
			 case 1:
				obj.rev();
				break;
				
			 case 2:
				obj.upper();
				break;
				
			 case 3:
				obj.lower();
				break;
				
			 case 4:
				obj.toggle();
				break;
			
			 case 5:
				obj.sentans();
				break;
				
			 case 6:
				System.out.print("Enter how many character extract from right of string : ");
				int num = s.nextInt();
				obj.extract(num);
				
			 default:
				System.out.println("invalid input!");
		 }
		
		 }
	 }
 }
 
 // extra

/* What is Character in Java?
Character is a special class in Java, which means it's like a blueprint for working with characters (like 'a', 'b', 'A', '1', etc.).

A class is a collection of things (in this case, methods) that help you do specific tasks.

Why do we need the Character class?
Normally, in Java, a character is represented by the primitive data type called char. A char is just a single character like 'a' or '1'.

The Character class is like a helper for working with characters. It provides special methods to do things that a char by itself cannot do.

For example, it can help you:

Change a character to uppercase: 'a' becomes 'A'.

Change a character to lowercase: 'A' becomes 'a'.

Check if a character is a letter or a number: It can tell you if '1' is a digit or if 'A' is a letter. 

For example:

Character.toUpperCase(c) — Converts a character c to uppercase.

Character.toLowerCase(c) — Converts a character c to lowercase.

Character.isLetter(c) — Checks if a character c is a letter.

Character.isDigit(c) — Checks if a character c is a digit.*/