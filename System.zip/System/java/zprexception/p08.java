//8. triangle
/* (A) Write a Java program that prompts the user to input the base and height of a 
	triangle. Accordingly calculates and displays the area of a triangle using the 
	formula (base* height)/2, and handles any input errors such as non-numeric inputs 
	or negative values for base or height. Additionally, include error messages for 
	invalid input and provide the user with the option to input another set of values or 
	exit the program.
 */
 
 import java.util.*;
 
 class p08
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 while(true)
		 {
			 try
			 {
				System.out.print("Enter the base : ");
				double base = s.nextDouble();
		 
				System.out.print("Enter the height : ");
				double height = s.nextDouble();
		 
				if(base <= 0 || height <=0)
				{
					System.out.println("Negetive values is not allowed !");
					continue; // go return one while loop and ask again
				}
		 
				double trc = (base*height)/2;
				System.out.println("Triangle is : "+ trc); 
			}
			catch(Exception e)
			{
				System.out.println("Error : this is invalide input ! plz enter valide values.");
				s.next(); // clear invalid input exception
				continue;//go return one while loop and ask again
			}
			 
			// Ask user if they want to try again
			System.out.print("Do you want to calculate again? (yes/no): ");
			String choice = s.next().toLowerCase();
			
			if (!choice.equals("yes")) 
			{
				System.out.println("Program exited.");
				break; // Exit loop
			}
		 }
		 
	 }
 }