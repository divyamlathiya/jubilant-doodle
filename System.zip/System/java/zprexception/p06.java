//6. userexception
/* (A) Write a Java code that handles the custom exception like when a user gives input 
	as Floating point number then it raises exception with appropriate message.
 */
 
 import java.util.*;
 class userex extends Exception
 {
	 public userex(String msg)
	 {
		 super(msg);
	 }
 }
 class p06
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 try
		 {
			System.out.print("Enter number : ");
			String n = s.nextLine();
		 
			// Check if input contains a decimal point
			if(n.contains("."))
				{
					throw new userex("Nuber is float, who is not allowed");// call userex class constructor with userexaption. 
				}
				
			// extra part
			int num = Integer.parseInt(n);//convert string to integer
			System.out.println("this is integer number : "+ num);
		 }
		 catch(userex e)// here userex is class name 
		 {
			 System.out.println(e.getMessage());//getMessage method is use for print custom error from above if condition
		 }
		 //extra
		 catch(Exception e)
		 {
			System.out.println(e) ;
		 }
		 finally//allways execute this part in program
		 {
			 System.out.println("Succsess !");
		 }
	 }
 }