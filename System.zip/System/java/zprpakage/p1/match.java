/* 12. package
(A) Write a java program to create a player history that can be display in the 
	following form. Player name and team name is stored in Player class. Score 
	of test match and One Day match in the other class say Run class number of 
	One Day match and number of test match must be in Match class and finally 
	calculate the average. The packagel contains Player, Run and Match classes, 
	Where package2 contain main() class.
 */
package p1;//create package p1

public class match
{
	public int numodi; // if we want access this out-side of package public is important
	public int numtest; // if we want access this out-side of package public is important
	
	public match(int nd,int nt)
	{
		numodi = nd;
		numtest = nt;
	}
	
	public void show()
	{
		System.out.println("Total Num Of One Day Match : "+numodi);
		System.out.println("Total Num Of Test match : "+numtest);
	}
}