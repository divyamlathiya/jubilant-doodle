/* 12. package
(A) Write a java program to create a player history that can be display in the 
	following form. Player name and team name is stored in Player class. Score 
	of test match and One Day match in the other class say Run class number of 
	One Day match and number of test match must be in Match class and finally 
	calculate the average. The packagel contains Player, Run and Match classes, 
	Where package2 contain main() class.
 */
package p1;//create package p1

public class player
{
	String pname;
	String pteam;
	
	public player(String pn,String pt)
	{
		pname = pn;
		pteam = pt;
	}
	
	public void show()
	{
		System.out.println("Player name is : "+ pname);
		System.out.println("Player team is : "+ pteam);
	}
}
