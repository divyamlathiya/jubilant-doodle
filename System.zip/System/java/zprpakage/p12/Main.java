/* 12. package
(A) Write a java program to create a player history that can be display in the 
	following form. Player name and team name is stored in Player class. Score 
	of test match and One Day match in the other class say Run class number of 
	One Day match and number of test match must be in Match class and finally 
	calculate the average. The packagel contains Player, Run and Match classes, 
	Where package2 contain main() class.
 */
 package p12;// create package p2
 
 import p1.*;//import p1 with all classes of his
 
 import java.util.*;
 
 class Main
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 //enter player class data
		 System.out.print("Enter Player Name : ");
		 String name = s.nextLine();

		 System.out.print("Enter Team Name : ");
		 String team = s.nextLine();
		 
		 
		 //enter run class data
		 System.out.print("Enter Score Of One Day Matchs(odi) : ");
		 int sodi = s.nextInt();

		 System.out.print("Enter Score Of Test Matchs(odi) : ");
		 int stest = s.nextInt();
	
		 
		 //enter match class data
		 System.out.print("Enter Total No. Of One Day Matchs(odi) : ");
		 int nodi = s.nextInt();

		 System.out.print("Enter Total No. Test Matchs(odi) : ");
		 int ntest = s.nextInt();
		 
		 player p = new player(name,team);
		 run r = new run(sodi,stest);
		 match m = new match(nodi,ntest);
		 
		 System.out.println();
		 
		 System.out.println("------History------");
		 p.show();
		 r.show();
		 m.show();
		 
		 double avgodi = (double) r.scoreodi/m.numodi;//(double) use for integer valuse calculation output tack in double
		 double avgtest = (double) r.scoretest/m.numtest;
		 
		 System.out.println("Avrege of odi : "+avgodi);
		 System.out.println("Avrege of test : "+avgtest);
		 
		 double avgfull = (double)(r.scoreodi + r.scoretest)/(m.numodi+m.numtest);
		 
		 //diff diff style to convert integers sum value in double
		 
		 //double avgfull = (r.getScoreOdi() + r.getScoreTest()) * 1.0 / (m.getNumOdi() + m.getNumTest());
		 //double avgfull = (Double.valueOf(r.scoreodi + r.scoretest)) / (m.numodi + m.numtest);
		 
		 
		 
		 System.out.println("Avrege of all matches : "+avgfull);
	 }
 }