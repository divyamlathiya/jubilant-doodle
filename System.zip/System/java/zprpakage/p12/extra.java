// anoter method to this qustion package p12.

//package 1
package p1;

class player {
    protected String pname;
    protected String pteam;

    public player(String pn, String pt) {
        pname = pn;
        pteam = pt;
    }

    public void showPlayer() {
        System.out.println("Player Name: " + pname);
        System.out.println("Team Name: " + pteam);
    }
}

class run extends player {
    protected int scoreodi;
    protected int scoretest;

    public run(String pn, String pt, int so, int st) {
        super(pn, pt);// from his perent class object(parameter) using super keyword
        scoreodi = so;
        scoretest = st;
    }

    public void showRun() {
        System.out.println("ODI Score: " + scoreodi);
        System.out.println("Test Score: " + scoretest);
    }
}

public class match extends run {
    protected int numodi;
    protected int numtest;

    public match(String pn, String pt, int so, int st, int no, int nt) {
        super(pn, pt, so, st);//from his perent class object(parameter) using super keyword
        numodi = no;
        numtest = nt;
    }

    public void showMatch() {
        System.out.println("ODI Matches: " + numodi);
        System.out.println("Test Matches: " + numtest);
    }

    public void showAverage() {
        double avgodi = (double) scoreodi / numodi;
        double avgtest = (double) scoretest / numtest;
        double avgall = (double)(scoreodi + scoretest) / (numodi + numtest);

        System.out.println("Avg ODI Score: " + avgodi);
        System.out.println("Avg Test Score: " + avgtest);
        System.out.println("Overall Avg Score: " + avgall);
    }
}


//package 2
package p2;

import java.util.Scanner;
import p1.match; // import match class (which extends all)

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter Player Name: ");
        String name = s.nextLine();

        System.out.print("Enter Team Name: ");
        String team = s.nextLine();

        System.out.print("Enter ODI Score: ");
        int sodi = s.nextInt();

        System.out.print("Enter Test Score: ");
        int stest = s.nextInt();

        System.out.print("Enter ODI Matches: ");
        int nodi = s.nextInt();

        System.out.print("Enter Test Matches: ");
        int ntest = s.nextInt();

        match m = new match(name, team, sodi, stest, nodi, ntest);// only need last child class object

        System.out.println("\n--- Player History ---");
        m.showPlayer();
        m.showRun();
        m.showMatch();
        m.showAverage();
    }
}


//one other styale

//first file of p1.
package p1;

public class player {
    public String pname;
    public String pteam;

    public player(String pn, String pt) {
        pname = pn;
        pteam = pt;
    }

    public void showPlayer() {
        System.out.println("Player Name: " + pname);
        System.out.println("Team Name: " + pteam);
    }
}

//second file of p1.
package p1;

public class run {
    public int scoreodi;
    public int scoretest;

    public run(int so, int st) {
        scoreodi = so;
        scoretest = st;
    }

    public void showRun() {
        System.out.println("ODI Score: " + scoreodi);
        System.out.println("Test Score: " + scoretest);
    }
}

//third file of p1.
package p1;

public class match {
    public int numodi;
    public int numtest;

    public match(int no, int nt) {
        numodi = no;
        numtest = nt;
    }

    public void showMatch() {
        System.out.println("ODI Matches: " + numodi);
        System.out.println("Test Matches: " + numtest);
    }

    public void showAverage(run r)//run r is object creating of run class to r. 
	{
        double avgodi = (double) r.scoreodi / numodi;
        double avgtest = (double) r.scoretest / numtest;
        double avgall = (double)(r.scoreodi + r.scoretest) / (numodi + numtest);

        System.out.println("Avg ODI Score: " + avgodi);
        System.out.println("Avg Test Score: " + avgtest);
        System.out.println("Overall Avg Score: " + avgall);
    }
}

//first file of p2.(main)
package p2;

import p1.*;

public class Main {
    public static void main(String[] args) {
        player p = new player("Rohit Sharma", "India");
        run r = new run(5000, 7000);
        match m = new match(130, 90);

        p.showPlayer();
        r.showRun();
        m.showMatch();
        m.showAverage(r);
    }
}
