//5. thread
/* (A) Write an application that creates and start three threads, each thread is 
	instantiated from the same class. It executes a loop with 5 iterations. 
	First thread display "BEST", second thread display "OF" and last thread display "LUCK".
	All threads sleep for 1000 ms. The application waits for all threads to complete and 
	display a message..
 */
 
 class bol extends Thread
 {
	 String str;
	 
	 public bol(String str)
	 {
		this.str = str; //here this.str use for bol class str variable and simple str is constructor str. 
	 }
	 
	 public void run()
	 {
		 for(int i=0 ; i<5 ;i++)
		 {
			try
			{
				System.out.println(str);
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				System.out.println(e);
			} 
		 }
		
	 }
 }
 
 class p05
 {
	 public static void main(String [] args)
	 {
		bol b1 = new bol("BEST");
		bol b2 = new bol("OF");
		bol b3 = new bol("LUCK");
		
		b1.start();
		b2.start();
		b3.start();
		
		try
		{
			b1.join();
			b2.join();
			b3.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		System.out.println("Thread is complited............................");
	 }
 }
 