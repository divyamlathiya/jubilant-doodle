//7. dwd cmdargs
/* (A) Write a java program that accepts string from command line and display each 
	character in capital at the delay of one second.
 */
 
import java.util.*;

public class p07
{
	public static void main(String [] args)
	{
		if(args.length == 0)
		{
			System.out.println("Plz! enter args in command line.");
		}
		else
		{
			String input = args[0].toUpperCase();// tack string from args and transfer in upper case.
			
			for(char ch : input.toCharArray())// transfer input string in character array
			// this array use for looping one by one character in ch
			{
				System.out.println(ch+" ");
				try
				{
					Thread.sleep(1000);
				}
				catch(InterruptedException e)
				{
					System.out.println(e);
				}
			}
		}
	}
}

/* //for print strings one by one

public class p07
{
	public static void main(String [] args)
	{
		if(args.length == 0)
		{
			System.out.println("Plz! enter args in command line.");
		}
		else
		{
			String []input = args;// args store in input array, actualy args is in array formate automatically
			
			for(String ch : input)
			// this array use for looping one by one string in ch from input array
			{
				System.out.print(ch + " ");
				try
				{
					Thread.sleep(1000);
				}
				catch(InterruptedException e)
				{
					System.out.println(e);
				}
			}
		}
	}
} */


/* // 7. dwd cmdargs using Thread class
class CharPrinter extends Thread {
    private String text;

    CharPrinter(String text) {
        this.text = text.toUpperCase(); // Convert to uppercase
    }

    public void run() {
        for (char ch : text.toCharArray()) {
            System.out.print(ch + " ");
            try {
                Thread.sleep(1000); // Delay of 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class dwd {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please enter a string as a command-line argument.");
            return;
        }

        CharPrinter cp = new CharPrinter(args[0]);
        cp.start(); // Start the thread
    }
}
 */

//<-- extra -->

/* // 7. dwd cmdargs using Thread class (multiple args)
class CharPrinter extends Thread {
    private String[] words;

    CharPrinter(String[] words) {
        this.words = words;
    }

    public void run() {
        for (String word : words) {
            word = word.toUpperCase();
            for (char ch : word.toCharArray()) {
                System.out.print(ch + " ");
                try {
                    Thread.sleep(1000); // Delay of 1 second
                } catch (InterruptedException e) {
                    System.out.println(e);
                }
            }
            System.out.print("  "); // Space between words
        }
    }
}

public class dwd {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please enter one or more strings as command-line arguments.");
            return;
        }

        CharPrinter cp = new CharPrinter(args);
        cp.start(); // Start the thread
    }
}
 */

/* // we can conver string in to array
String str = "java is fun";
String[] wordArray = str.split(" ");

for (String word : wordArray) {
    System.out.println(word);
}


// we can conver unstructured space string in array
public class Example {
    public static void main(String[] args) {
        String str = "hello    java is   language";

        // Use regex \\s+ to split by one or more spaces
        String[] words = str.split("\\s+");

        // Print the array
        for (String word : words) {
            System.out.println(word);
        }
    }
}
 */