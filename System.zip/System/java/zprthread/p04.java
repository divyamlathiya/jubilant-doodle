//4. cmdargs
/* (A) Write a Java program to display string with capital letters which are inputted 
	through command line. Display those string(s) which starts with "B". */
	
/* public class p04
{
	public static void main(String [] args)
	{
		if(args.length==0)
		{
			System.out.println("plz enter the argument in commandline.");
			return;
		}
		String []str = args;
		
		for(String s : str)
		{
			if(s.startsWith("b")||s.startsWith("B"))
			{
				System.out.println(s.toUpperCase());
			}
		}
	}
}
 */
 
 // user ask for args if not give args in command line
import java.util.*;

public class p04
{
		public static void main(String [] args)
		{
			String [] words; //declaration of array
			if(args.length==0)
			{
				Scanner s = new Scanner(System.in);
				
				System.out.print("Enter number of args you want to insert : ");
				int n = s.nextInt();
				
				s.nextLine();// use for new line
				
				words = new String[n];// mack fix size of array
				
				for(int i=0;i<n;i++)
				{
					//String str=s.nextLine();
					//words[i] = str;
					
					// same same above two line in one
					
					words[i] = s.nextLine();
				}
				
			}
			else
			{
				words = args;// use args strings for words array 
			}
			
			/* for(String y : words)
			{
				if(y.startsWith("b")||y.startsWith("B"))
				{
					System.out.println(y.toUpperCase());
				}
			} */
			
			for(int i=0;i<words.length;i++)
			{
				if(words[i].startsWith("B")||words[i].startsWith("b"))
				{
					System.out.println(words[i].toUpperCase());
				}
			}
			
			//we can also write like this above for loop
			
			/* for(int i=0;i<words.length;i++)
			{
				String sg=words[i];
				if(sg.startsWith("B")||sg.startsWith("b"))
				{
					System.out.println(sg.toUpperCase());
				}
			} */ 
		}
}