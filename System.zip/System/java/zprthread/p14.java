//14. thread
/* (A) Write an application that execute two Threads. One thread display "BCA" every 1000 
	milliseconds and the order displays "MCA" every 3000 milliseconds. 
	Create the threads by extending the thread class.
 */
 
class bca extends Thread
{
	public void run()
	{
	try
	{
		int i=0;
		while(i<=10)
		{
			System.out.println("BCA");
			Thread.sleep(1000);
			i=i+1;
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
}

class mca extends Thread
{
	public void run()
	{
	try
	{
		int i=0;
		while(i<=10)
		{
			System.out.println("MCA");
			Thread.sleep(3000);
			i=i+1;
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
}

class p14
{
	public static void main(String [] args)
	{
		bca b = new bca();
		mca m = new mca();
		
		b.start();
		m.start();
		
		/* //for waiting thread execution complite
		 try
		{
			b.join();
			m.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		// this optional statment for last complate message.
		System.out.println("Thread is complate ..."); */
	}
}