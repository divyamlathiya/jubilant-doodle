//2. student
/* (A) Create STUDENT class having data members roll no and name. Create 5 objects of 
	STUDENT class and take input from the user and print all students' data in ascending 
	order of name with interval of 1 second.
 */
 
 import java.util.*;
 
 class std
 {
	 int rollno;
	 String name;	 
 }
 
 class p02
 {
	 public static void main(String [] args)
	 {
		 int n;
		 Scanner s = new Scanner(System.in);
		 
		 System.out.print("Enter total number of data you want to add in array : ");
		 n=s.nextInt();
		 
		 std student[] = new std[n];// std class member access by student array and this is also creation of student array
		 
		 for(int i=0 ; i<n ; i++)
		 {
			 student[i] = new std();// new object for std class
			 
			 System.out.print("enter roll no of student : ");
			 student[i].rollno = s.nextInt();
			 
			 s.nextLine(); // go on next line for ask next inout like name
			 
			 System.out.print("enter name of student : ");
			 student[i].name = s.nextLine();
			 
			 System.out.println();// for new line
			 
		 }
		 
		 for(int i=0;i<n-1;i++)
		 {
			 for(int j = i+1 ; j<n ; j++)
			 {
				 if(student[i].name.compareToIgnoreCase(student[j].name)>0)// compare name using function and set in assanding order
				 {
					std temp = student[i];
					student[i] = student[j];
					student[j] = temp;
				 }
			 }
		 }
		 
		 for(int i=0;i<n;i++)
		 {
			 System.out.println("roll no is : "+student[i].rollno);
			 System.out.println("name is : "+student[i].name);
			 System.out.println();
			 try
			 {
				 Thread.sleep(1000);//thread class not use and set interval
			 }
			 catch(InterruptedException e)
			 {
				 System.out.println(e);
			 }
		 }
	}
 }