/* 15. linklist
(A) Write a java program to. create and display Singly linked list and perform 
	following task:
			 1. Insert node at specific position.
			 2. Delete node from specific position
add by me :- 3. update node from specific position
*/
 
//10. singlylinklist
/* (A) Write a java program that creates Singly Link List to perform create,
	   insert, delete and display node using menu driven program.
 */
 
 import java.util.*;
 
 class Node
 {
	 int data;
	 Node next;
	 
	 public Node(int d)
	 {
		 data = d;
		 next = null;
	 } 
 }
 
 
 class slist
 {
	 Node head;
	 
	 public void insert(int data,int pos)
	 {
		 Node newnode = new Node(data);
		 
		 if(pos == 1)
		 {
			 newnode.next = head;
			 head = newnode;
			 return;
		 }
		 
		 Node temp = head;//use for without iritet head to access head data by  temp
		 
		 for(int i=1 ; temp != null && i < pos-1 ; i++)
		 {
			 temp = temp.next;
		 }
		 
		 if(temp == null)
		 {
			 System.out.println("this is wrong position for insert...");
			 return;
		 }
		 
		 newnode.next = temp.next;
		 temp.next = newnode;
	 }
	 
	 // this is use for insert at end without using position

	/* void insert(int data) 
	{
		Node newNode = new Node(data);
		
		if (head == null) 
		{
			head = newNode;
			return;
		}
		
		Node temp = head;
		
		while (temp.next != null) 
		{
			temp = temp.next;
		}
		temp.next = newNode;
	} */

	 public void delete(int pos)
	 {
		 if(head == null)
		 {
			 System.out.println("this list is empty...");
			 return;
		 }
		 
		 if(pos == 1)
		 {
			 head = head.next;
			 return;
		 }
		 
		 Node temp = head;
		 
		 for(int i=1 ; temp != null && i <pos-1 ; i++)
		 {
			 temp = temp.next;
		 }
		 
		 if(temp == null || temp.next == null)
		 {
			 System.out.println("list is empty....");
			 return;
		 }
		 
		 temp.next = temp.next.next; 
	 }
	 
	 public void update(int oldvalue,int newvalue)
	 {
		 if(head == null)
		 {
			 System.out.println("list is empty...");
			 return;
		 }
		 
		 Node temp = head;
		 
		 boolean found = false;
		 
		 while(temp != null)
		 {
			 if(temp.data == oldvalue)
			 {
				 temp.data = newvalue;
				 
				 found = true;
				 
				 System.out.println("record is updated...");
				 
				 break;
			 }
			 temp = temp.next;
		 }
		 
		 if(!found)
		 {
			 System.out.println("data is not found by given you....");
			 return;
		 }
	 }
	 
	 public void display()
	 {
		 if(head == null)
		 {
			 System.out.println("list is empty...");
			 return;
		 }
		 
		 Node temp = head;
		 
		 System.out.print("link list is : ");
		 
		 while(temp != null)
		 {
			 System.out.print(temp.data + "-->");
			 
			 temp = temp.next;
		 }
		 
		 System.out.println("NULL");
	 }
 }
 
 
class p15
{
	public static void main(String [] args)
	{
		 Scanner s = new Scanner(System.in);
		 
		 slist s1 = new slist();
		 
		 int data,position,newnum,oldnum;
		 
		 while(true)
		 {
		 System.out.println(" 1.insert \n 2.delete \n 3.update \n 4.display \n 5.exit");
		 
		 System.out.println("Enter you choice : ");
		 int choice = s.nextInt();
		 
		 switch(choice)
		 {
			 case 1:
			 
				System.out.print("Enter data : ");
				data = s.nextInt();
				
				System.out.print("Enter position : ");
				position = s.nextInt();
				
				s1.insert(data,position);
				
				break;
				
			 case 2:
			 
				System.out.print("Enter position : ");
				position = s.nextInt();
				
				s1.delete(position);
				
				break;
				
			 case 3:
			 
				System.out.print("Enter oldnum from list : ");
				oldnum = s.nextInt();
				
				System.out.print("Enter newnum for update : ");
				newnum = s.nextInt();
				
				s1.update(oldnum,newnum);
				
				break;
				
			 case 4:
			 
				s1.display();
				break;
				
			 case 5:
			 
				System.out.println("Exit program..");
				return;
				
			 default:
			 
				System.out.println("invalid choice!");
				break;
		 }
		 }
	}
}

// extra circular link list

/* import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class CircularLinkedList {
    Node head = null;
    Node tail = null;
    Scanner sc = new Scanner(System.in);

    // Insert at end
    void insert() {
        System.out.print("Enter data to insert: ");
        int data = sc.nextInt();
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
            newNode.next = head;
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head;
        }
        System.out.println("Node inserted.");
    }

    // Delete node by value
    void delete() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        System.out.print("Enter value to delete: ");
        int value = sc.nextInt();

        Node current = head;
        Node prev = null;

        do {
            if (current.data == value) {
                if (current == head && current == tail) { // only one node
                    head = tail = null;
                } else if (current == head) {
                    head = head.next;
                    tail.next = head;
                } else if (current == tail) {
                    prev.next = head;
                    tail = prev;
                } else {
                    prev.next = current.next;
                }
                System.out.println("Node deleted.");
                return;
            }
            prev = current;
            current = current.next;
        } while (current != head);

        System.out.println("Node not found.");
    }

    // Update node
    void update() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        System.out.print("Enter value to update: ");
        int oldValue = sc.nextInt();
        System.out.print("Enter new value: ");
        int newValue = sc.nextInt();

        Node current = head;
        boolean found = false;

        do {
            if (current.data == oldValue) {
                current.data = newValue;
                found = true;
                break;
            }
            current = current.next;
        } while (current != head);

        if (found) {
            System.out.println("Node updated.");
        } else {
            System.out.println("Node not found.");
        }
    }

    // Display the list
    void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        System.out.print("List: ");
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    // Menu
    public static void main(String[] args) {
        CircularLinkedList cl = new CircularLinkedList();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Update");
            System.out.println("4. Display");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: cl.insert(); break;
                case 2: cl.delete(); break;
                case 3: cl.update(); break;
                case 4: cl.display(); break;
                case 5: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice!");
            }
        } while (choice != 5);
    }
}
 */