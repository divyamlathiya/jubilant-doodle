/* 16. employee
(A) Write a java program to create EMPLOYEE class with name, age and salary data members.
	Take input (data) from user and create minimum 5 objects of employee class.
	Display all employees' data in ascending order of salary.
 */
 
 import java.util.*;
 
 class emp
 {
	 String name;
	 int age;
	 double sal;
	 
	 public emp(String n, int a, double s)
	 {
		 name = n;
		 age = a;
		 sal = s;
	 }
	 
	 public void show()
	 {
		System.out.println("Name : "+ name +"\n"+"Age : "+age+"\n"+"Salary : "+sal+"\n"); 
	 }
 }
 class p16
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 System.out.println("Enter number of record : ");
		 int n1 = s.nextInt();
		 
		 emp employ[] = new emp[n1];
		 
		 for(int i=0;i<n1;i++)
		 {
			 s.nextLine();
			 
			 System.out.print("Enter the name : ");
			 String name = s.nextLine();
			 
			 System.out.print("Enter the age : ");
			 int age = s.nextInt();
			 
			 s.nextLine();
			 
			 System.out.print("Enter the Salary : ");
			 double sal = s.nextDouble();
			 
			 System.out.println();
			 
			 employ[i]=new emp(name,age,sal);
			 
		 }
		 
		 for(int i=0 ; i<n1-1 ;i++)
		 {
			 for(int j=i+1 ; j<n1 ; j++)
			 {
				 if(employ[i].sal > employ[j].sal)
				 {
					 emp t = employ[i];
					 employ[i] = employ[j];
					 employ[j] = t;
				 }
			 }
		 }
		 
		 for(int i=0 ; i<n1 ; i++)
		 {
			employ[i].show(); 
		 }
	 }
 }