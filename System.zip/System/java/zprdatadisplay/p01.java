//1. employee
/* (A) Create class EMPLOYEE in java with id, name and salary as data- members. 
	Again create 5 different employee objects by taking input from user. 
	Display all the information of an employee which is having maximum salary.
 */
 
 import java.util.*;
 
 class emp
 {
	int id;
	String name;
	double sal;
 }
 
 class p01
 {
	 public static void main(String [] args)
	 {
		 Scanner s = new Scanner(System.in);
		 
		 System.out.print("enter number of data you want add in array : ");
		 int n = s.nextInt();
		 
		 emp emp1[] = new emp[n];
		 
		 for(int i=0;i<n;i++)
		 {
			 emp1[i] = new emp();
			 
			 System.out.print("Enter id : ");
			 emp1[i].id = s.nextInt();
			 
			 s.nextLine();
			 
			 System.out.print("Enter name : ");
			 emp1[i].name = s.nextLine();
			 
			 
			 System.out.print("Enter salary : ");
			 emp1[i].sal = s.nextDouble();
			 
			 System.out.println();
		 }
		 
		 double max = emp1[0].sal;
		 for(int i=0;i<n;i++)
		 {
			if(emp1[i].sal > max)
			{
				max=emp1[i].sal;
			}
		 }
		 
		 for(int i=0;i<n;i++)
		 {
			 if(emp1[i].sal == max)
			 {
				 System.out.println("Emp id : "+ emp1[i].id);
				 System.out.println("Emp name : "+ emp1[i].name);
				 System.out.println("Emp salary : "+ emp1[i].sal);
			 }
		 }
	 }
 }